@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title AOSP Flasher v7 - By Mayank Droid

python -c "import sys; assert sys.version_info[0] >= 3" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    python "%~dp0main.py"
    if %ERRORLEVEL% NEQ 0 pause
    exit /b 0
)

py -3 -c "import sys; assert sys.version_info[0] >= 3" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    py -3 "%~dp0main.py"
    if %ERRORLEVEL% NEQ 0 pause
    exit /b 0
)

py -c "import sys; assert sys.version_info[0] >= 3" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    py "%~dp0main.py"
    if %ERRORLEVEL% NEQ 0 pause
    exit /b 0
)

for %%P in (
    "%LocalAppData%\Programs\Python\Python314\python.exe"
    "%LocalAppData%\Programs\Python\Python313\python.exe"
    "%LocalAppData%\Programs\Python\Python312\python.exe"
    "%LocalAppData%\Programs\Python\Python311\python.exe"
    "%LocalAppData%\Programs\Python\Python310\python.exe"
    "%ProgramFiles%\Python314\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python311\python.exe"
    "%ProgramFiles%\Python310\python.exe"
    "C:\Python314\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
) do (
    if exist "%%~P" (
        "%%~P" "%~dp0main.py"
        if %ERRORLEVEL% NEQ 0 pause
        exit /b 0
    )
)

echo [ERROR] Python 3.10+ not found. Please install Python from https://www.python.org/downloads/
pause
exit /b 1
