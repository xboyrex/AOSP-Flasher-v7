<div align="center">

<img src="assets/logo.png" alt="AOSP Flasher v7 Logo" width="110" height="110" />

# ⚡ AOSP Flasher v7
### **High-Contrast AMOLED + Cyber Yellow Command Center for Android Custom ROMs & Kernels**
**Developed by Mayank Droid (`@MayankDroid7`)**

[![Platform](https://img.shields.io/badge/Platform-Windows%2010%20%7C%2011-FACC15?style=for-the-badge&logo=windows&logoColor=black)](https://github.com/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-FACC15?style=for-the-badge&logo=python&logoColor=black)](https://www.python.org/)
[![Theme](https://img.shields.io/badge/UI%20Theme-AMOLED%20%2B%20Cyber%20Yellow-050507?style=for-the-badge&labelColor=FACC15)](https://github.com/)
[![License](https://img.shields.io/badge/Edition-Pro%20v7.0-22C55E?style=for-the-badge)](https://mayank-droid.pages.dev)

---

**AOSP Flasher v7** is an ultra-fast, lightweight, zero-bloat Windows desktop utility engineered for flashing **AOSP Custom ROMs**, **Custom Kernels (AnyKernel3 / KernelSU / SukiSU)**, and **Custom Recoveries (OrangeFox / TWRP)** with automated multi-core `payload.bin` stream extraction, unbuffered ADB Sideload, and real-time hardware telemetry.

</div>

---

## 🌟 What Can AOSP Flasher v7 Do? (Key Capabilities)

### 1. 🚀 Automated AOSP Custom ROM Flasher
- **0ms In-Place Multi-Core Payload Extraction**: Directly extracts essential boot partitions (`boot`, `init_boot`, `vendor_boot`, `dtbo`, `recovery`) from `payload.bin` inside `.zip` ROM packages without wasting time or disk space extracting 5GB+ archives.
- **Quick Partition Presets**:
  - **All (Recommended)**: Automatically selects and flashes all required boot & recovery images before sideloading.
  - **Skip Fastboot Stage**: Skips Fastboot flashing and jumps straight into Recovery ADB Sideload mode.
- **Automated Recovery Transition**: Flashes Fastboot partitions, automatically reboots the device into Recovery, and displays the exact on-screen Wipe/Format Data instructions.
- **Calibrated AOSP 47% Sideload Engine**: Streams the ROM via unbuffered `adb sideload` with real-time progress normalization (where AOSP's standard `~47%` completion mark maps smoothly to `100% ROM Installed!`).
- **Transfer Lock & Sleep Blocker**: Automatically pauses background USB polling and blocks Windows Sleep/Hibernation during active transfers so 5GB+ ROMs never drop connection.

### 2. ⚡ Dedicated Kernel & Root Lab (KSU / SukiSU / AnyKernel3)
- **1-Click Custom Kernel Sideload**: Flash AnyKernel3, KernelSU (`KSU`), and `SukiSU` `.zip` packages directly via Recovery ADB Sideload.
- **Direct Partition Image Flashing**: Supports flashing `.img` files (`boot.img`, `recovery.img`, `init_boot.img`, `vendor_boot.img`, `dtbo.img`) in Fastboot mode.
- **Built-in KMI & Compatibility Checklist**: Step-by-step interactive checklist and safety guide to prevent KMI mismatches.

### 3. 🛠️ Fastboot Wipe, Repair & Slot Utilities
- **Erase FRP**: Clears Google Factory Reset Protection lock partition in Fastboot mode.
- **Wipe Metadata**: Resets filesystem encryption states when switching between different AOSP ROMs.
- **Format Userdata**: Performs a complete factory reset and wipes internal storage cleanly.
- **Active Slot Switcher (`Slot A` / `Slot B`)**: Instant 1-click A/B partition slot switching (`fastboot --set-active=a|b`).
- **WOF Wake**: Hardware wake ping for stuck Fastboot/ADB USB interfaces.

### 4. 📱 Real-Time Device Telemetry & iOS Phone Mockup
- **Parallel Multi-Threaded USB Detection (<50ms warm latency)**: Detects **ADB**, **Unauthorized**, **Fastboot**, **Fastbootd**, **Recovery**, and **ADB Sideload** states in real time.
- **100% Real Battery Telemetry**: Reads live battery percentage via ADB `dumpsys`/`sysfs`, Recovery `/sys/class/power_supply/battery/capacity`, and Fastboot `battery-voltage` (mV).
- **Live iOS Device Mockup**: Visual connection indicator with model name, codename, active slot, and USB serial ID.

### 5. 🧹 1-Click In-Place WinMemoryCleaner (NTAPI Engine)
- Directly purges 8 Windows memory areas (`Working Set`, `System File Cache`, `Modified Page List`, `Standby List`, `Low-Priority Standby`, `Combined Page List`, `Registry Cache`) via native `ntdll.dll` / `kernel32.dll` syscalls without opening any popup windows—freeing gigabytes of RAM prior to flashing large ROMs.

### 6. 💻 Real-Time Diagnostic Telemetry Console
- Strictly read-only, syntax-highlighted monospace console matching exact AOSP sideload output (`serving: '...' (~47%)`, `Total xfer: 1.00x`).
- Includes 1-click **Copy Logs**, **Clear Logs**, and **Safety Protocol & Sideload Notes**.

---

## 🎨 Design System: AMOLED + Cyber Yellow

| Surface / Token | HEX Code | Role |
| :--- | :--- | :--- |
| **AMOLED Root Background** | `#050507` | Ultra-deep high-contrast background |
| **Sidebar Surface** | `#0C0D10` | 3-Zone Bento navigation dock |
| **Technical Card Surface** | `#13151A` | Main workflow & telemetry cards |
| **Recessed Console / Input** | `#090A0D` | Input bars & diagnostic terminal stream |
| **Primary Cyber Yellow** | `#FACC15` | High-contrast buttons, active states, progress arc |
| **Solar Yellow Hover** | `#FDE047` | Interactive hover highlight |
| **Emerald Success** | `#22C55E` | Connected state & 100% completion |
| **Coral Danger** | `#EF4444` | Safe abort & destructive Fastboot warnings |

---

## 📋 Standard Automated Flashing Workflow

```text
[21:51:35] » 🚀 ROM Flasher Pro v6.0 Cyber-Command Engine Initialized.
[21:51:35] » ⚡ Multi-Core Payload Engine Ready (4 Logical Cores Detected).
[21:52:16] » 📦 Loaded ROM Package: Lunaris-AOSP-onyx-Community-3.13-GMS-2026110118_1.zip (4.44 GB)
[21:53:52] » 🟢 [CONNECTED] Mode: FASTBOOT | 📱 Model: onyx
[21:54:12] » 🚀 INITIATING V6 AUTOMATED ROM FLASH: Lunaris-AOSP-onyx-Community-3.13-GMS-2026110118_1.zip
[21:54:12] » 🔒 [LOCK] USB Polling Paused & Windows Sleep Blocked for uninterrupted transfer.
[21:54:13] » 📦 Extracting partitions: boot, init_boot, vendor_boot, dtbo, recovery
[21:54:19] » ⚡ Flashing boot.img...
[21:54:22] » ⚡ Flashing init_boot.img...
[21:54:22] » ⚡ Flashing vendor_boot.img...
[21:54:26] » ⚡ Flashing dtbo.img...
[21:54:27] » ⚡ Flashing recovery.img...
[21:54:30] » ✅ Fastboot partitions flashed! Rebooting device into Recovery...
=======================================================
⚠️ ACTION REQUIRED ON PHONE SCREEN:
  1. Tap 'Wipe' -> 'Format Data' -> type 'yes'
  2. Go back -> Tap 'Apply Update' -> 'Apply from ADB'
=======================================================
[21:54:30] » ⏳ Auto-detecting Recovery ADB Sideload connection...
[21:54:56] » 🟢 [CONNECTED] Mode: SIDELOAD | 📱 Model: 25053PC47G
[21:54:56] » ⚡ Streaming ROM via Unbuffered ADB Sideload: Lunaris-AOSP-onyx-Community-3.13-GMS-2026110118_1.zip
[21:55:08] » ⚡ serving: 'C:/Users/aman/Downloads/Lunaris-AOSP-onyx-Community-3.13-GMS-2026110118_1.zip'  (~0%)
...
[22:02:12] » ⚡ serving: 'C:/Users/aman/Downloads/Lunaris-AOSP-onyx-Community-3.13-GMS-2026110118_1.zip'  (~47%)
[22:02:12] » ⚡ Total xfer: 1.00x
=======================================================
✅ AUTOMATED ROM FLASH SEQUENCE COMPLETED SUCCESSFULLY!
=======================================================
```

---

## 🚀 How to Run & Build Standalone EXE

### 1. Run Directly from Source (`run.bat`)
Double-click **`run.bat`** (or run `python main.py`).
- Launches instantaneously at 0ms without unnecessary startup delays.

### 2. Build Single-File Portable EXE (`build.bat`)
1. Place your `adb.exe`, `fastboot.exe`, `payload-dumper-go.exe`, `AdbWinApi.dll`, and `AdbWinUsbApi.dll` inside the **`adb\`** folder (if not present, `build.bat` automatically downloads official Google Platform-Tools).
2. Double-click **`build.bat`**.
3. PyInstaller merges the `adb\` folder, `assets\`, `core\`, and custom `assets\icon.ico` directly into a single standalone executable:
   - **`AOSP_Flasher_v7_By_Mayank_Droid.exe`**
   - Also creates a desktop shortcut (**`AOSP Flasher v7.lnk`**) with your custom launcher icon.

### 3. Push to GitHub from Termux (`push_to_github_termux.sh`)
If you are managing this repository from **Termux** on Android:
```bash
chmod +x push_to_github_termux.sh
./push_to_github_termux.sh
```
*(Or on Windows, double-click **`push_to_github.bat`**).*

---

## ⚠️ Disclaimer

> **WARNING**: Flashing custom ROMs, custom kernels, and recoveries, or executing destructive Fastboot commands (`Erase FRP`, `Wipe Metadata`, `Format Userdata`) carries inherent risks and may void your warranty or result in data loss.
> - Always back up your personal data before flashing.
> - Ensure your bootloader is unlocked and that the selected ROM/Kernel package is built specifically for your exact device codename and Android KMI version.
> - The developer (**Mayank Droid**) is not responsible for bricked devices, corrupted partitions, or lost data resulting from improper use.

---

## 🌐 Official Links — Mayank Droid

- 🌍 **Mayank Droid Hub**: [https://mayank-droid.pages.dev](https://mayank-droid.pages.dev)
- 🔓 **Mi Unlock Service**: [https://mi-unlock.pages.dev](https://mi-unlock.pages.dev)
- 🤖 **Onyx Services**: [https://onyx-services.pages.dev](https://onyx-services.pages.dev)
- 🎌 **Otaku Hub Pro**: [https://otaku-hub-pro.pages.dev](https://otaku-hub-pro.pages.dev)
- 💼 **Portfolio HBO**: [https://portfolio-hbo.pages.dev](https://portfolio-hbo.pages.dev)
- 📢 **Telegram**: [@MayankDroid7](https://t.me/MayankDroid7) | [@RoranoaxZORO](https://t.me/RoranoaxZORO)
- ▶️ **YouTube**: [@mayankdroid](https://youtube.com/@mayankdroid)
