"""
ADB Toolkit | Developed by Mayank Droid
Native Windows Memory Cleaner Engine (Ported 1:1 from IgorMundstein/WinMemoryCleaner)
Implements all 8 documented Windows NTAPI & Win32 memory optimization areas:
1. Working Set (SystemMemoryListInformation=80, MemoryEmptyWorkingSets=2 + EmptyWorkingSet)
2. System File Cache (SystemFileCacheInformation=21 + SetSystemFileCacheSize)
3. Modified Page List (SystemMemoryListInformation=80, MemoryFlushModifiedList=3)
4. Standby List (SystemMemoryListInformation=80, MemoryPurgeStandbyList=4)
5. Standby List Low Priority (SystemMemoryListInformation=80, MemoryPurgeLowPriorityStandbyList=5)
6. Combined Page List (SystemCombinePhysicalMemoryInformation=130)
7. Registry Cache (SystemRegistryReconciliationInformation=155)
8. Modified File Cache (Volume DeviceIoControl FSCTL_RESET_WRITE_ORDER / FSCTL_DISCARD_VOLUME_CACHE + FlushFileBuffers)
"""
import os
import sys
import gc
import time
import shutil
import ctypes
import tempfile
import subprocess
from enum import IntFlag
from typing import Dict, List, Any, Callable, Optional


class MemoryAreas(IntFlag):
    NONE = 0
    COMBINED_PAGE_LIST = 1
    MODIFIED_FILE_CACHE = 2
    MODIFIED_PAGE_LIST = 4
    REGISTRY_CACHE = 8
    STANDBY_LIST = 16
    STANDBY_LIST_LOW_PRIORITY = 32
    SYSTEM_FILE_CACHE = 64
    WORKING_SET = 128

    DEFAULT_ALL = (
        WORKING_SET
        | SYSTEM_FILE_CACHE
        | MODIFIED_FILE_CACHE
        | REGISTRY_CACHE
        | MODIFIED_PAGE_LIST
        | COMBINED_PAGE_LIST
        | STANDBY_LIST_LOW_PRIORITY
        | STANDBY_LIST
    )


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class LUID(ctypes.Structure):
    _fields_ = [
        ("LowPart", ctypes.c_ulong),
        ("HighPart", ctypes.c_long),
    ]


class TOKEN_PRIVILEGES(ctypes.Structure):
    _fields_ = [
        ("PrivilegeCount", ctypes.c_ulong),
        ("Luid", LUID),
        ("Attributes", ctypes.c_ulong),
    ]


class MEMORY_COMBINE_INFORMATION_EX(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("Handle", ctypes.c_void_p),
        ("PagesCombined", ctypes.c_size_t),
        ("Flags", ctypes.c_longlong),
    ]


class SYSTEM_FILECACHE_INFORMATION_64(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("CurrentSize", ctypes.c_longlong),
        ("PeakSize", ctypes.c_longlong),
        ("PageFaultCount", ctypes.c_longlong),
        ("MinimumWorkingSet", ctypes.c_longlong),
        ("MaximumWorkingSet", ctypes.c_longlong),
        ("CurrentSizeIncludingTransitionInPages", ctypes.c_longlong),
        ("PeakSizeIncludingTransitionInPages", ctypes.c_longlong),
        ("TransitionRePurposeCount", ctypes.c_longlong),
        ("Flags", ctypes.c_longlong),
    ]


class RAMCleanerEngine:
    SystemFileCacheInformation = 21
    SystemMemoryListInformation = 80
    SystemCombinePhysicalMemoryInformation = 130
    SystemRegistryReconciliationInformation = 155

    MemoryEmptyWorkingSets = 2
    MemoryFlushModifiedList = 3
    MemoryPurgeStandbyList = 4
    MemoryPurgeLowPriorityStandbyList = 5

    FSCTL_DISCARD_VOLUME_CACHE = 589828
    FSCTL_RESET_WRITE_ORDER = 589832
    FILE_FLAG_NO_BUFFERING = 0x20000000

    SeDebugPrivilege = "SeDebugPrivilege"
    SeIncreaseQuotaPrivilege = "SeIncreaseQuotaPrivilege"
    SeProfSingleProcessPrivilege = "SeProfileSingleProcessPrivilege"
    SE_PRIVILEGE_ENABLED = 0x00000002
    TOKEN_ADJUST_PRIVILEGES = 0x0020
    TOKEN_QUERY = 0x0008

    def __init__(self, log_callback: Optional[Callable[[str], None]] = None):
        self.log_cb = log_callback or (lambda msg: None)
        self.is_windows = sys.platform.startswith("win")
        self.selected_areas: MemoryAreas = MemoryAreas.DEFAULT_ALL
        self.process_exclusion_list = {
            "adb", "adb.exe", "fastboot", "fastboot.exe", "payload-dumper-go", "payload-dumper-go.exe"
        }
        self.last_freed_mb = 0.0
        self.last_clean_timestamp = 0.0
        self.last_area_results: List[Dict[str, Any]] = []

    def _log(self, msg: str):
        try:
            self.log_cb(str(msg))
        except Exception:
            pass

    def get_memory_stats(self) -> Dict[str, float]:
        if self.is_windows:
            try:
                stat = MEMORYSTATUSEX()
                stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
                total_mb = stat.ullTotalPhys / (1024 * 1024)
                avail_mb = stat.ullAvailPhys / (1024 * 1024)
                used_mb = max(0.0, total_mb - avail_mb)
                v_total_mb = stat.ullTotalPageFile / (1024 * 1024)
                v_avail_mb = stat.ullAvailPageFile / (1024 * 1024)
                return {
                    "total_mb": round(total_mb, 1),
                    "used_mb": round(used_mb, 1),
                    "avail_mb": round(avail_mb, 1),
                    "percent": float(stat.dwMemoryLoad),
                    "virtual_total_mb": round(v_total_mb, 1),
                    "virtual_avail_mb": round(v_avail_mb, 1),
                }
            except Exception:
                pass
        try:
            import psutil
            vm = psutil.virtual_memory()
            return {
                "total_mb": round(vm.total / (1024 * 1024), 1),
                "used_mb": round(vm.used / (1024 * 1024), 1),
                "avail_mb": round(vm.available / (1024 * 1024), 1),
                "percent": round(vm.percent, 1),
                "virtual_total_mb": round(vm.total / (1024 * 1024), 1),
                "virtual_avail_mb": round(vm.available / (1024 * 1024), 1),
            }
        except Exception:
            return {
                "total_mb": 0.0,
                "used_mb": 0.0,
                "avail_mb": 0.0,
                "percent": 0.0,
                "virtual_total_mb": 0.0,
                "virtual_avail_mb": 0.0,
            }

    def _set_increase_privilege(self, privilege_name: str) -> bool:
        if not self.is_windows:
            return True
        try:
            advapi32 = ctypes.windll.advapi32
            kernel32 = ctypes.windll.kernel32
            h_token = ctypes.c_void_p()
            if not advapi32.OpenProcessToken(
                kernel32.GetCurrentProcess(),
                self.TOKEN_ADJUST_PRIVILEGES | self.TOKEN_QUERY,
                ctypes.byref(h_token),
            ):
                return False
            try:
                luid = LUID()
                if not advapi32.LookupPrivilegeValueW(None, privilege_name, ctypes.byref(luid)):
                    return False
                tp = TOKEN_PRIVILEGES()
                tp.PrivilegeCount = 1
                tp.Luid = luid
                tp.Attributes = self.SE_PRIVILEGE_ENABLED
                res = advapi32.AdjustTokenPrivileges(h_token, False, ctypes.byref(tp), 0, None, None)
                return bool(res)
            finally:
                kernel32.CloseHandle(h_token)
        except Exception:
            return False

    def optimize_working_set(self) -> bool:
        if not self.is_windows:
            return True
        ok = False
        if self._set_increase_privilege(self.SeProfSingleProcessPrivilege):
            try:
                cmd = ctypes.c_int(self.MemoryEmptyWorkingSets)
                status = ctypes.windll.ntdll.NtSetSystemInformation(
                    self.SystemMemoryListInformation,
                    ctypes.byref(cmd),
                    ctypes.sizeof(cmd),
                )
                if status == 0:
                    ok = True
            except Exception:
                pass

        self._set_increase_privilege(self.SeDebugPrivilege)
        try:
            kernel32 = ctypes.windll.kernel32
            psapi = getattr(ctypes.windll, "psapi", None)
            arr = (ctypes.c_ulong * 2048)()
            cb = ctypes.sizeof(arr)
            bytes_ret = ctypes.c_ulong()
            if psapi and psapi.EnumProcesses(ctypes.byref(arr), cb, ctypes.byref(bytes_ret)):
                count = bytes_ret.value // ctypes.sizeof(ctypes.c_ulong)
                for i in range(count):
                    pid = arr[i]
                    if pid in (0, 4):
                        continue
                    h_proc = kernel32.OpenProcess(0x0400 | 0x0100, False, pid)
                    if h_proc:
                        try:
                            if psapi.EmptyWorkingSet(h_proc):
                                ok = True
                            kernel32.SetProcessWorkingSetSizeEx(
                                h_proc, ctypes.c_size_t(-1), ctypes.c_size_t(-1), 0
                            )
                        except Exception:
                            pass
                        finally:
                            kernel32.CloseHandle(h_proc)
        except Exception:
            pass
        return ok

    def optimize_system_file_cache(self) -> bool:
        if not self.is_windows:
            return True
        self._set_increase_privilege(self.SeIncreaseQuotaPrivilege)
        ok = False
        try:
            info = SYSTEM_FILECACHE_INFORMATION_64()
            info.MinimumWorkingSet = -1
            info.MaximumWorkingSet = -1
            status = ctypes.windll.ntdll.NtSetSystemInformation(
                self.SystemFileCacheInformation,
                ctypes.byref(info),
                ctypes.sizeof(info),
            )
            if status == 0:
                ok = True
        except Exception:
            pass

        try:
            minus_one = ctypes.c_size_t(-1)
            if ctypes.windll.kernel32.SetSystemFileCacheSize(minus_one, minus_one, 0):
                ok = True
        except Exception:
            pass
        return ok

    def optimize_modified_page_list(self) -> bool:
        if not self.is_windows:
            return True
        if not self._set_increase_privilege(self.SeProfSingleProcessPrivilege):
            return False
        try:
            cmd = ctypes.c_int(self.MemoryFlushModifiedList)
            status = ctypes.windll.ntdll.NtSetSystemInformation(
                self.SystemMemoryListInformation,
                ctypes.byref(cmd),
                ctypes.sizeof(cmd),
            )
            return status == 0
        except Exception:
            return False

    def optimize_standby_list(self, low_priority: bool = False) -> bool:
        if not self.is_windows:
            return True
        if not self._set_increase_privilege(self.SeProfSingleProcessPrivilege):
            return False
        try:
            val = self.MemoryPurgeLowPriorityStandbyList if low_priority else self.MemoryPurgeStandbyList
            cmd = ctypes.c_int(val)
            status = ctypes.windll.ntdll.NtSetSystemInformation(
                self.SystemMemoryListInformation,
                ctypes.byref(cmd),
                ctypes.sizeof(cmd),
            )
            return status == 0
        except Exception:
            return False

    def optimize_combined_page_list(self) -> bool:
        if not self.is_windows:
            return True
        if not self._set_increase_privilege(self.SeProfSingleProcessPrivilege):
            return False
        try:
            info = MEMORY_COMBINE_INFORMATION_EX()
            status = ctypes.windll.ntdll.NtSetSystemInformation(
                self.SystemCombinePhysicalMemoryInformation,
                ctypes.byref(info),
                ctypes.sizeof(info),
            )
            return status == 0
        except Exception:
            return False

    def optimize_registry_cache(self) -> bool:
        if not self.is_windows:
            return True
        try:
            status = ctypes.windll.ntdll.NtSetSystemInformation(
                self.SystemRegistryReconciliationInformation,
                None,
                0,
            )
            return status == 0
        except Exception:
            return False

    def optimize_modified_file_cache(self) -> bool:
        if not self.is_windows:
            return True
        kernel32 = ctypes.windll.kernel32
        GENERIC_READ_WRITE = 0x80000000 | 0x40000000
        FILE_SHARE_READ_WRITE = 0x00000001 | 0x00000002
        OPEN_EXISTING = 3
        INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
        flushed_any = False

        for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            drive_root = f"{letter}:\\"
            if not os.path.exists(drive_root):
                continue
            try:
                if kernel32.GetDriveTypeW(drive_root) != 3:
                    continue
                vol_path = f"\\\\.\\{letter}:"
                h_vol = kernel32.CreateFileW(
                    vol_path,
                    GENERIC_READ_WRITE,
                    FILE_SHARE_READ_WRITE,
                    None,
                    OPEN_EXISTING,
                    self.FILE_FLAG_NO_BUFFERING,
                    None,
                )
                if not h_vol or h_vol == INVALID_HANDLE_VALUE:
                    continue
                try:
                    bytes_ret = ctypes.c_ulong()
                    dummy_buf = ctypes.c_byte(0)
                    kernel32.DeviceIoControl(
                        h_vol,
                        self.FSCTL_RESET_WRITE_ORDER,
                        ctypes.byref(dummy_buf),
                        1,
                        None,
                        0,
                        ctypes.byref(bytes_ret),
                        None,
                    )
                    kernel32.DeviceIoControl(
                        h_vol,
                        self.FSCTL_DISCARD_VOLUME_CACHE,
                        None,
                        0,
                        None,
                        0,
                        ctypes.byref(bytes_ret),
                        None,
                    )
                    if kernel32.FlushFileBuffers(h_vol):
                        flushed_any = True
                finally:
                    kernel32.CloseHandle(h_vol)
            except Exception:
                pass
        return flushed_any

    def _clean_stale_temp_caches(self) -> int:
        removed_bytes = 0
        temp_root = tempfile.gettempdir()
        prefixes = ("rom_flasher_extract_", "aosp_v7_cache_", "miflash_temp_", "payload_dump_")
        try:
            for item in os.listdir(temp_root):
                if item.startswith(prefixes):
                    full_p = os.path.join(temp_root, item)
                    try:
                        if os.path.isdir(full_p) and (time.time() - os.path.getmtime(full_p)) > 86400:
                            for root, _, files in os.walk(full_p):
                                for f in files:
                                    fp = os.path.join(root, f)
                                    if os.path.exists(fp):
                                        removed_bytes += os.path.getsize(fp)
                            shutil.rmtree(full_p, ignore_errors=True)
                    except Exception:
                        pass
        except Exception:
            pass
        return removed_bytes

    def kill_conflicting_adb_zombies(self, kill_adb: bool = False):
        if not self.is_windows:
            return
        bloat_daemons = ["Shuame.exe", "KingRoot.exe", "360MobileLoader.exe", "HiSuite.exe"]
        if kill_adb:
            bloat_daemons.extend(["adb.exe", "fastboot.exe"])
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        for proc_name in bloat_daemons:
            try:
                subprocess.run(
                    ["taskkill", "/F", "/IM", proc_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    startupinfo=si,
                    creationflags=0x08000000,
                    timeout=1.5,
                )
            except Exception:
                pass

    def boost_system_memory(
        self,
        startup_mode: bool = False,
        kill_bloat: bool = True,
        areas: Optional[MemoryAreas] = None,
        progress_callback: Optional[Callable[[int, str], None]] = None,
    ) -> Dict[str, Any]:
        active_areas = areas if areas is not None else self.selected_areas
        before = self.get_memory_stats()
        t_start = time.perf_counter()

        gc.collect()
        cache_bytes = self._clean_stale_temp_caches()
        if kill_bloat:
            self.kill_conflicting_adb_zombies(kill_adb=False)

        # Optimal Windows NT Memory Transition Pipeline:
        # 1. Empty Working Sets first (pushes pages into Modified & Standby lists)
        # 2. Flush Modified File Cache & Registry Cache
        # 3. Trim System File Cache
        # 4. Flush Modified Page List (converts dirty pages into Standby pages)
        # 5. Combine identical physical pages (Kernel Page Combining)
        # 6. Purge Low-Priority Standby List + Full Standby List (converts Standby into Free RAM!)
        area_steps = [
            (MemoryAreas.WORKING_SET, "Working Set", self.optimize_working_set),
            (MemoryAreas.MODIFIED_FILE_CACHE, "Modified File Cache", self.optimize_modified_file_cache),
            (MemoryAreas.SYSTEM_FILE_CACHE, "System File Cache", self.optimize_system_file_cache),
            (MemoryAreas.REGISTRY_CACHE, "Registry Cache", self.optimize_registry_cache),
            (MemoryAreas.MODIFIED_PAGE_LIST, "Modified Page List", self.optimize_modified_page_list),
            (MemoryAreas.COMBINED_PAGE_LIST, "Combined Page List", self.optimize_combined_page_list),
            (
                MemoryAreas.STANDBY_LIST_LOW_PRIORITY,
                "Standby List (Priority 0)",
                lambda: self.optimize_standby_list(low_priority=True),
            ),
            (
                MemoryAreas.STANDBY_LIST,
                "Standby List (Full Purge)",
                lambda: self.optimize_standby_list(low_priority=False),
            ),
        ]

        results: List[Dict[str, Any]] = []
        step_num = 0
        for flag, name, func in area_steps:
            if active_areas & flag:
                step_num += 1
                if progress_callback:
                    try:
                        progress_callback(step_num, name)
                    except Exception:
                        pass
                s0 = time.perf_counter()
                ok = func()
                dur = round(time.perf_counter() - s0, 2)
                results.append({"name": name, "ok": ok, "duration_sec": dur})

        # Compact C Runtime & Win32 Process Heaps + Second quick sweep of Modified -> Standby
        if self.is_windows:
            try:
                ctypes.cdll.msvcrt._heapmin()
            except Exception:
                pass
            try:
                h_heap = ctypes.windll.kernel32.GetProcessHeap()
                if h_heap:
                    ctypes.windll.kernel32.HeapCompact(ctypes.c_void_p(h_heap), 0)
            except Exception:
                pass
            self.optimize_modified_page_list()
            self.optimize_standby_list(low_priority=False)

        gc.collect()
        time.sleep(0.06)
        after = self.get_memory_stats()
        total_dur = round(time.perf_counter() - t_start, 2)

        # 100% Real Physical RAM Freed (strictly measured from GlobalMemoryStatusEx / psutil!)
        raw_freed = round(max(0.0, after["avail_mb"] - before["avail_mb"]), 1)

        self.last_freed_mb = raw_freed
        self.last_clean_timestamp = time.time()
        self.last_area_results = results

        # Clean, concise single-line log so console remains crystal clear and readable!
        if startup_mode:
            self._log(f"Initial Memory Optimized: {raw_freed:.1f} MB reclaimed | Available: {after['avail_mb']/1024.0:.1f} GB ({100.0 - after['percent']:.0f}% Free)")
        else:
            self._log(f"8 Caches Purged in {total_dur}s -> +{raw_freed:.1f} MB Freed | Available RAM: {after['avail_mb']/1024.0:.1f} GB ({100.0 - after['percent']:.0f}% Free)")
        return {
            "before": before,
            "after": after,
            "freed_mb": self.last_freed_mb,
            "areas_cleaned": results,
            "trimmed_processes": len(results),
            "duration_sec": total_dur,
            "cache_cleaned_mb": round(cache_bytes / (1024 * 1024), 2),
        }

    @staticmethod
    def parse_cli_areas(argv: List[str]) -> MemoryAreas:
        mapping = {
            "/combinedpagelist": MemoryAreas.COMBINED_PAGE_LIST,
            "/modifiedfilecache": MemoryAreas.MODIFIED_FILE_CACHE,
            "/modifiedpagelist": MemoryAreas.MODIFIED_PAGE_LIST,
            "/registrycache": MemoryAreas.REGISTRY_CACHE,
            "/standbylist": MemoryAreas.STANDBY_LIST,
            "/standbylistlowpriority": MemoryAreas.STANDBY_LIST_LOW_PRIORITY,
            "/systemfilecache": MemoryAreas.SYSTEM_FILE_CACHE,
            "/workingset": MemoryAreas.WORKING_SET,
        }
        areas = MemoryAreas.NONE
        for arg in argv:
            key = arg.strip().lower().replace("--", "/").replace("-", "/")
            if key in mapping:
                areas |= mapping[key]
        return areas if areas != MemoryAreas.NONE else MemoryAreas.DEFAULT_ALL
