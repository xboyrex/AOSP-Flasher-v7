"""
ADB Toolkit | Developed by Mayank Droid
Core Flashing Backend:
- Smart Device Detection (ADB / Unauthorized / Fastboot / Fastbootd / Sideload / Recovery)
- AOSP & Custom ROM Automated Flashing (payload-dumper-go + Fastboot + ADB Sideload)
- Official Xiaomi MiFlash HyperOS Engine (flash_all.bat / flash_all_except_storage.bat / flash_all_lock.bat + Recovery Sideload + ARB Guard)
- Kernel & Recovery Dedicated Flasher (.zip AnyKernel3 Sideload & .img Direct/Temp Boot)
- Fastboot Destructive Erase & Slot/Vbmeta Utilities
"""
import os
import re
import sys
import time
import shutil
import tarfile
import zipfile
import tempfile
import threading
import subprocess
from typing import Dict, List, Any, Callable, Optional, Tuple

from .turbo_engine import TurboEngine
from .driver_manager import DriverAndEnvManager


class DeviceState:
    DISCONNECTED = "Disconnected"
    UNAUTHORIZED = "Allow USB Debugging on Phone!"
    ADB = "ADB Connected"
    FASTBOOT = "Fastboot Mode"
    FASTBOOTD = "Fastbootd Mode"
    SIDELOAD = "ADB Sideload"
    RECOVERY = "Recovery Mode"


class FlasherBackend:
    def __init__(
        self,
        base_dir: str,
        turbo: TurboEngine,
        driver_mgr: DriverAndEnvManager,
        log_callback: Optional[Callable[[str], None]] = None,
        progress_callback: Optional[Callable[[float, str], None]] = None,
        step_callback: Optional[Callable[[int, str, str], None]] = None,
    ):
        self.base_dir = base_dir
        self.turbo = turbo
        self.driver_mgr = driver_mgr
        self.log_cb = log_callback or (lambda msg: None)
        self.progress_cb = progress_callback or (lambda pct, label: None)
        self.step_cb = step_callback or (lambda idx, state, text: None)
        self.is_windows = sys.platform.startswith("win")

        self.is_flashing: bool = False
        self.is_sideload_locked: bool = False
        self.abort_requested: bool = False
        self._active_proc: Optional[subprocess.Popen] = None

        self._prev_logged_state: str = ""
        self.preextracted_dir: str = ""
        self.preextracted_rom: str = ""
        self.preextracted_imgs: Dict[str, str] = {}
        self._preextract_event = threading.Event()
        self._preextract_event.set()
        self._preextract_cleanup_requested = False

        # All large extracted partition images live in one app-owned session folder.
        # The folder is removed after a flash or normal application shutdown.
        self._temp_root = os.path.join(tempfile.gettempdir(), "AOSPFlasher_v7")
        os.makedirs(self._temp_root, exist_ok=True)
        self._session_root = tempfile.mkdtemp(
            prefix=f"session_{os.getpid()}_", dir=self._temp_root
        )
        self._cleanup_orphaned_temp_sessions()
        self.cached_device_info: Dict[str, str] = {
            "state": DeviceState.DISCONNECTED,
            "serial": "None",
            "model": "No Device",
            "codename": "-",
            "battery": "Unknown",
            "slot": "-",
            "unlocked": "-",
            "arb": "-",
        }
        self._device_poll_lock = threading.Lock()

    def log(self, msg: str):
        timestamp = time.strftime("%H:%M:%S")
        try:
            self.log_cb(f"[{timestamp}] {msg}")
        except Exception:
            pass

    def set_progress(self, pct: float, status_text: str):
        pct_clamped = max(0.0, min(100.0, float(pct)))
        try:
            self.progress_cb(pct_clamped, status_text)
        except Exception:
            pass

    def set_step(self, step_idx: int, status: str, label: str = ""):
        try:
            self.step_cb(step_idx, status, label)
        except Exception:
            pass

    def _run_short_cmd(self, cmd: List[str], timeout: float = 3.5) -> Tuple[int, str, str]:
        bin_dir = os.path.dirname(os.path.abspath(cmd[0])) if (cmd and os.path.isabs(cmd[0])) else self.driver_mgr.adb_dir
        kwargs: Dict[str, Any] = {
            "capture_output": True,
            "text": True,
            "timeout": timeout,
            "encoding": "utf-8",
            "errors": "replace",
            "cwd": bin_dir if os.path.isdir(bin_dir) else self.base_dir,
        }
        if self.is_windows:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            kwargs["startupinfo"] = si
            kwargs["creationflags"] = 0x08000000
        try:
            res = subprocess.run(cmd, **kwargs)
            return res.returncode, (res.stdout or "").strip(), (res.stderr or "").strip()
        except Exception as e:
            return -1, "", str(e)

    def _stream_command(
        self,
        cmd: List[str],
        cwd: Optional[str] = None,
        parse_sideload_pct: bool = False,
        base_pct: float = 0.0,
        span_pct: float = 100.0,
        status_label: str = "Executing...",
        quiet_stdout: bool = False,
    ) -> int:
        if self.abort_requested:
            return -99

        kwargs: Dict[str, Any] = {
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "text": True,
            "bufsize": 1,
            "encoding": "utf-8",
            "errors": "replace",
            "cwd": cwd or self.base_dir,
        }
        if self.is_windows:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            kwargs["startupinfo"] = si
            kwargs["creationflags"] = self.turbo.get_subprocess_creation_flags()

        try:
            self.last_command_error = ""
            self._active_proc = subprocess.Popen(cmd, **kwargs)
            pct_regex = re.compile(r"(?:~|)(\d{1,3})%")
            ansi_regex = re.compile(r"\[[0-9;]*[a-zA-Z]")
            fatal_err_regex = re.compile(
                r"(FAILED \([^)]*\)|fastboot: error:.*|adb: error:.*|error: no devices.*|error: device unauthorized.*|error: cannot load.*)",
                re.IGNORECASE,
            )
            assert self._active_proc.stdout is not None
            for raw_line in self._active_proc.stdout:
                if self.abort_requested and not self.is_sideload_locked:
                    try:
                        self._active_proc.terminate()
                    except Exception:
                        pass
                    self.log("Operation safely aborted by user.")
                    return -99

                line = ansi_regex.sub("", raw_line).strip()
                if not line or line in ("…", "...") or line.startswith("[4A") or line.startswith("[5A"):
                    continue

                m_err = fatal_err_regex.search(line)
                if m_err:
                    self.last_command_error = m_err.group(1).strip()

                if parse_sideload_pct:
                    if "Total xfer:" in line:
                        self.log(f"⚡ {line}")
                        self.set_progress(100.0, "Total xfer: 1.00x")
                    elif "serving:" in line:
                        self.log(f"⚡ {line}")
                        m = pct_regex.search(line)
                        if m:
                            sub_pct = float(m.group(1))
                            # AOSP 47% Rule: 47% equals 100% full transfer
                            ratio = min(1.0, sub_pct / 47.0)
                            mapped = base_pct + ratio * span_pct
                            self.set_progress(mapped, f"{status_label} ({sub_pct:.0f}%)")
                    elif m_err:
                        self.log(f"❌ {line}")
                else:
                    if not quiet_stdout:
                        self.log(line)
                    elif m_err:
                        self.log(f"❌ {line}")

            self._active_proc.wait()
            rc = self._active_proc.returncode
            self._active_proc = None
            if rc == 0 and self.last_command_error and not parse_sideload_pct:
                return -10
            return rc
        except FileNotFoundError:
            self.log(f"ERROR: Binary not found: {cmd[0]}")
            self._active_proc = None
            return -2
        except Exception as e:
            self.log(f"ERROR: {e}")
            self._active_proc = None
            return -1

    def poll_device_state(self, force: bool = False) -> Dict[str, str]:
        # Coalesce timer-driven and manual refresh requests into one USB probe.
        acquired = self._device_poll_lock.acquire(timeout=5.2) if force else self._device_poll_lock.acquire(blocking=False)
        if not acquired:
            return dict(self.cached_device_info)
        try:
            return self._poll_device_state_impl(force=force)
        finally:
            self._device_poll_lock.release()

    def _poll_device_state_impl(self, force: bool = False) -> Dict[str, str]:
        """
        100% Real-Time, Reality-Based Parallel Device Detection (<50ms warm latency):
        - Queries `adb devices -l` and `fastboot devices` concurrently in parallel threads.
        - Reads REAL battery level in ADB (`dumpsys battery` + `/sys/class/power_supply/battery/capacity`),
          REAL battery level in Recovery Mode (`/sys/class/power_supply/battery/capacity`),
          REAL battery voltage/status in Fastboot (`getvar battery-voltage`),
          REAL active slot (`ro.boot.slot_suffix` / `getvar current-slot`),
          REAL ARB index (`getvar anti` / `ro.boot.anti`), and REAL Fastbootd userspace state!
        """
        if self.turbo.active_transfer_lock and not force:
            return dict(self.cached_device_info)

        if not hasattr(self, "_fb_meta_cache"):
            self._fb_meta_cache: Dict[str, Dict[str, Any]] = {}
        if not hasattr(self, "_adb_meta_cache"):
            self._adb_meta_cache: Dict[str, Dict[str, Any]] = {}
        if not hasattr(self, "_last_unauth_serial"):
            self._last_unauth_serial: str = ""
        if not hasattr(self, "_last_known_telemetry"):
            self._last_known_telemetry: Dict[str, str] = {}

        if force:
            self._fb_meta_cache.clear()
            self._adb_meta_cache.clear()

        adb_bin = self.driver_mgr.resolve_binary("adb")
        fb_bin = self.driver_mgr.resolve_binary("fastboot")

        adb_res: List[Tuple[int, str, str]] = [(-1, "", "")]
        fb_res: List[Tuple[int, str, str]] = [(-1, "", "")]

        adb_timeout = 4.5 if not getattr(self, "_adb_daemon_warm", False) else 1.6

        def _probe_adb():
            adb_res[0] = self._run_short_cmd([adb_bin, "devices", "-l"], timeout=adb_timeout)
            if adb_res[0][0] == 0:
                self._adb_daemon_warm = True

        def _probe_fb():
            fb_res[0] = self._run_short_cmd([fb_bin, "devices"], timeout=1.2)

        t_a = threading.Thread(target=_probe_adb, daemon=True)
        t_f = threading.Thread(target=_probe_fb, daemon=True)
        t_a.start()
        t_f.start()
        t_a.join(timeout=adb_timeout + 0.3)
        t_f.join(timeout=1.4)

        rc, out, _ = adb_res[0]
        if rc == 0 and out:
            lines = [ln.strip() for ln in out.splitlines()[1:] if ln.strip() and not ln.startswith("*")]
            if lines:
                parts = lines[0].split()
                serial = parts[0]
                raw_mode = parts[1].lower() if len(parts) > 1 else "device"
                model_match = re.search(r"model:(\S+)", lines[0])
                dev_match = re.search(r"device:(\S+)", lines[0])
                model = model_match.group(1) if model_match else serial
                codename = dev_match.group(1) if dev_match else "-"

                if raw_mode in ("unauthorized", "offline", "authorizing", "no"):
                    if force or self._last_unauth_serial != f"{serial}:{raw_mode}":
                        self._last_unauth_serial = f"{serial}:{raw_mode}"
                        try:
                            self.driver_mgr.trigger_usb_debugging_auth_prompt(full_reconnect=True, target_serial=serial)
                        except Exception:
                            if raw_mode == "offline":
                                self._run_short_cmd([adb_bin, "reconnect", "offline"], timeout=2.0)
                            elif force:
                                self._run_short_cmd([adb_bin, "reconnect"], timeout=2.0)
                    info = {
                        "state": DeviceState.UNAUTHORIZED,
                        "serial": serial,
                        "model": "Allow USB Debugging on Phone",
                        "codename": codename,
                        "battery": "Locked",
                        "slot": "-",
                        "unlocked": "-",
                        "arb": "-",
                    }
                    self.cached_device_info = info
                    return info

                self._last_unauth_serial = ""

                if raw_mode == "sideload":
                    # In Sideload mode, minadbd blocks shell commands; use real USB descriptor model/codename
                    # and preserve any real battery/slot/arb read right before entering sideload!
                    info = {
                        "state": DeviceState.SIDELOAD,
                        "serial": serial,
                        "model": model,
                        "codename": codename,
                        "battery": self._last_known_telemetry.get("battery", "Sideload"),
                        "slot": self._last_known_telemetry.get("slot", "-"),
                        "unlocked": "Unlocked",
                        "arb": self._last_known_telemetry.get("arb", "-"),
                    }
                    self.cached_device_info = info
                    return info
                elif raw_mode == "recovery":
                    now_t = time.time()
                    cached_r = self._adb_meta_cache.get(f"rec:{serial}")
                    if not cached_r or force or (now_t - cached_r.get("ts", 0.0) > 6.0):
                        # Combined 1-shot shell query for real battery %, slot, codename, and ARB in Recovery!
                        _, sh_out, _ = self._run_short_cmd(
                            [
                                adb_bin, "-s", serial, "shell",
                                "cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo -; "
                                "getprop ro.boot.slot_suffix 2>/dev/null; "
                                "getprop ro.product.device 2>/dev/null; "
                                "getprop ro.boot.anti 2>/dev/null"
                            ],
                            timeout=1.5,
                        )
                        sh_lines = [x.strip() for x in sh_out.splitlines()]
                        bat_raw = sh_lines[0] if len(sh_lines) > 0 else "-"
                        bat_str = f"{bat_raw}%" if bat_raw.isdigit() else "Recovery"
                        slot_raw = (sh_lines[1] if len(sh_lines) > 1 else "").replace("_", "").upper() or "-"
                        dev_raw = (sh_lines[2] if len(sh_lines) > 2 else "") or codename
                        arb_raw = (sh_lines[3] if len(sh_lines) > 3 else "") or self._last_known_telemetry.get("arb", "-")
                        cached_r = {
                            "bat": bat_str,
                            "slot": slot_raw,
                            "codename": dev_raw if dev_raw else codename,
                            "arb": arb_raw if arb_raw else "-",
                            "ts": now_t,
                        }
                        self._adb_meta_cache[f"rec:{serial}"] = cached_r
                        if bat_raw.isdigit():
                            self._last_known_telemetry["battery"] = bat_str
                        if slot_raw in ("A", "B"):
                            self._last_known_telemetry["slot"] = slot_raw
                    info = {
                        "state": DeviceState.RECOVERY,
                        "serial": serial,
                        "model": model,
                        "codename": cached_r["codename"],
                        "battery": cached_r["bat"],
                        "slot": cached_r["slot"],
                        "unlocked": "Unlocked",
                        "arb": cached_r["arb"],
                    }
                    self.cached_device_info = info
                    return info
                elif raw_mode == "device":
                    now_t = time.time()
                    cached_a = self._adb_meta_cache.get(f"adb:{serial}")
                    if not cached_a or force or (now_t - cached_a.get("ts", 0.0) > 6.0):
                        # Single fast combined shell call for real battery %, slot, codename, model, and ARB
                        _, sh_out, _ = self._run_short_cmd(
                            [
                                adb_bin, "-s", serial, "shell",
                                "cat /sys/class/power_supply/battery/capacity 2>/dev/null || dumpsys battery 2>/dev/null | grep -m1 level; "
                                "echo '---SEP---'; "
                                "getprop ro.boot.slot_suffix; "
                                "echo '---SEP---'; "
                                "getprop ro.product.device; "
                                "echo '---SEP---'; "
                                "getprop ro.boot.vbmeta.device_state; "
                                "echo '---SEP---'; "
                                "getprop ro.boot.anti"
                            ],
                            timeout=1.6,
                        )
                        segs = [s.strip() for s in sh_out.split("---SEP---")]
                        bat_seg = segs[0] if len(segs) > 0 else ""
                        bat_lvl = "Unknown"
                        if bat_seg.isdigit():
                            bat_lvl = f"{bat_seg}%"
                        else:
                            m_bat = re.search(r"level:\s*(\d+)", bat_seg)
                            if m_bat:
                                bat_lvl = f"{m_bat.group(1)}%"
                        slot_clean = (segs[1] if len(segs) > 1 else "").replace("_", "").upper() or "-"
                        dev_clean = (segs[2] if len(segs) > 2 else "") or codename
                        lock_clean = (segs[3] if len(segs) > 3 else "").capitalize() or "Unlocked"
                        arb_clean = (segs[4] if len(segs) > 4 else "") or self._last_known_telemetry.get("arb", "-")

                        cached_a = {
                            "bat": bat_lvl,
                            "slot": slot_clean,
                            "codename": dev_clean,
                            "unlocked": lock_clean,
                            "arb": arb_clean if arb_clean else "-",
                            "ts": now_t,
                        }
                        self._adb_meta_cache[f"adb:{serial}"] = cached_a
                        if bat_lvl != "Unknown":
                            self._last_known_telemetry["battery"] = bat_lvl
                        if slot_clean in ("A", "B"):
                            self._last_known_telemetry["slot"] = slot_clean
                    info = {
                        "state": DeviceState.ADB,
                        "serial": serial,
                        "model": model,
                        "codename": cached_a["codename"],
                        "battery": cached_a["bat"],
                        "slot": cached_a["slot"],
                        "unlocked": cached_a["unlocked"],
                        "arb": cached_a["arb"],
                    }
                    self.cached_device_info = info
                    return info

        rc_fb, out_fb, _ = fb_res[0]
        if rc_fb == 0 and out_fb:
            fb_lines = [
                ln.strip() for ln in out_fb.splitlines()
                if ln.strip()
                and not ln.lower().startswith(("waiting", "fastboot:"))
                and len(ln.split()) >= 1
            ]
            if fb_lines:
                serial = fb_lines[0].split()[0]
                line_low = fb_lines[0].lower()
                now_t = time.time()
                cache_key = f"{serial}:{line_low}"
                meta = self._fb_meta_cache.get(cache_key)

                if not meta or force or (now_t - meta.get("ts", 0.0) > 8.0):
                    rc_all, all_out, all_err = self._run_short_cmd([fb_bin, "-s", serial, "getvar", "all"], timeout=0.9)
                    blob = (all_out + "\n" + all_err)

                    def _ext(text: str, key: str) -> str:
                        m = re.search(rf"{key}:\s*(\S+)", text, re.IGNORECASE)
                        return m.group(1) if m else "-"

                    codename = _ext(blob, "product")
                    if codename == "-":
                        _, p_o, p_e = self._run_short_cmd([fb_bin, "-s", serial, "getvar", "product"], timeout=0.6)
                        codename = _ext(p_o + "\n" + p_e, "product")
                    arb_val = _ext(blob, "anti")
                    if arb_val == "-":
                        _, a_o, a_e = self._run_short_cmd([fb_bin, "-s", serial, "getvar", "anti"], timeout=0.6)
                        arb_val = _ext(a_o + "\n" + a_e, "anti")
                    slot_val = _ext(blob, "current-slot").replace("_", "").upper()
                    if slot_val not in ("A", "B"):
                        _, s_o, s_e = self._run_short_cmd([fb_bin, "-s", serial, "getvar", "current-slot"], timeout=0.6)
                        slot_val = _ext(s_o + "\n" + s_e, "current-slot").replace("_", "").upper()
                    userspace_val = _ext(blob, "is-userspace").lower()
                    unlocked_val = _ext(blob, "unlocked").lower()
                    bat_volt = _ext(blob, "battery-voltage")
                    is_fastbootd = (userspace_val == "yes") or ("fastbootd" in line_low)

                    # Compute real battery display from bootloader battery-voltage if reported, or last known real %
                    bat_disp = self._last_known_telemetry.get("battery", "Fastbootd" if is_fastbootd else "Fastboot")
                    m_mv = re.match(r"^(\d{4})", bat_volt)
                    if m_mv:
                        mv = int(m_mv.group(1))
                        if 3200 <= mv <= 4550:
                            est_pct = max(1, min(100, int((mv - 3300) * 100 / 1050)))
                            bat_disp = f"{est_pct}% ({mv/1000:.2f}V)"

                    if slot_val in ("A", "B"):
                        self._last_known_telemetry["slot"] = slot_val
                    if arb_val != "-":
                        self._last_known_telemetry["arb"] = arb_val

                    meta = {
                        "codename": codename,
                        "arb": arb_val,
                        "slot": slot_val if slot_val in ("A", "B") else "-",
                        "unlocked": "Unlocked" if unlocked_val in ("yes", "true", "-") else "Locked",
                        "battery": bat_disp,
                        "is_fastbootd": is_fastbootd,
                        "ts": now_t,
                    }
                    if codename != "-":
                        self._fb_meta_cache[cache_key] = meta

                is_fastbootd = bool(meta["is_fastbootd"])
                codename = meta["codename"]
                info = {
                    "state": DeviceState.FASTBOOTD if is_fastbootd else DeviceState.FASTBOOT,
                    "serial": serial,
                    "model": codename if codename != "-" else serial,
                    "codename": codename,
                    "battery": meta["battery"],
                    "slot": meta["slot"],
                    "unlocked": meta["unlocked"],
                    "arb": meta["arb"],
                }
                self.cached_device_info = info
                return info

        self._last_unauth_serial = ""
        info = {
            "state": DeviceState.DISCONNECTED,
            "serial": "None",
            "model": "No Device",
            "codename": "-",
            "battery": "Unknown",
            "slot": "-",
            "unlocked": "-",
            "arb": "-",
        }
        if getattr(self, "_prev_logged_state", None) is not None:
            prev = self._prev_logged_state
            curr = info.get("state", DeviceState.DISCONNECTED)
            if curr != prev:
                self._prev_logged_state = curr
                if curr == DeviceState.DISCONNECTED and prev not in ("", DeviceState.DISCONNECTED):
                    self.log("❌ [Device Disconnected] USB connection lost. Waiting for device...")
                elif curr in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                    self.log(f"🟢 [CONNECTED] Mode: FASTBOOT | 📱 Model: {info.get('model', 'Unknown')}")
                elif curr == DeviceState.ADB:
                    self.log(f"🟢 [CONNECTED] Mode: ADB | 📱 Model: {info.get('model', 'Unknown')}")
                elif curr == DeviceState.SIDELOAD:
                    self.log(f"🟢 [CONNECTED] Mode: SIDELOAD | 📱 Model: {info.get('model', 'Unknown')}")
                elif curr == DeviceState.RECOVERY:
                    self.log(f"🟢 [CONNECTED] Mode: RECOVERY | 📱 Model: {info.get('model', 'Unknown')}")
        self.cached_device_info = info
        return info

    def _ensure_sideload_mode(self, run_ofox_pre_hook: bool = True) -> bool:
        """
        Ultra-Fast Transition Helper (Fastboot / Recovery / ADB -> ADB Sideload):
        - If device is ALREADY in `DeviceState.SIDELOAD` (`ADB Sideload (25053PC47G)`),
          returns `True` in 0ms without sending any reboot commands!
        - If device is in `Fastboot` / `Fastbootd`, sends `fastboot reboot recovery` and polls
          every 0.25s until Recovery or Sideload appears.
        - If device lands in `Recovery`, runs OrangeFox `onyx` pre-flash hook and triggers
          `twrp sideload` / `adb reboot sideload`, then polls every 0.25s until Sideload is ready!
        """
        adb_bin = self.driver_mgr.resolve_binary("adb")
        fb_bin = self.driver_mgr.resolve_binary("fastboot")

        cur_st = self.poll_device_state(force=True)["state"]
        if cur_st == DeviceState.SIDELOAD:
            pass
            return True

        if cur_st in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
            pass
            self._run_short_cmd([fb_bin, "reboot", "recovery"], timeout=3.0)
            for _ in range(140):  # 140 * 0.25s = 35s max
                if self.abort_requested:
                    raise RuntimeError("Cancelled.")
                st_now = self.poll_device_state(force=True)["state"]
                if st_now == DeviceState.SIDELOAD:
                    return True
                if st_now == DeviceState.RECOVERY:
                    cur_st = DeviceState.RECOVERY
                    break
                time.sleep(0.25)

        if cur_st == DeviceState.RECOVERY:
            if run_ofox_pre_hook:
                self.run_onyx_ofox_pre_flash_hook()
            pass
            self._run_short_cmd([adb_bin, "shell", "twrp sideload 2>/dev/null"], timeout=2.5)
            time.sleep(0.4)
            if self.poll_device_state(force=True)["state"] != DeviceState.SIDELOAD:
                self._run_short_cmd([adb_bin, "reboot", "sideload"], timeout=3.0)
        elif cur_st == DeviceState.ADB:
            pass
            self._run_short_cmd([adb_bin, "reboot", "sideload"], timeout=3.0)

        for _ in range(360):  # 360 * 0.25s = 90s max
            if self.abort_requested:
                raise RuntimeError("Cancelled.")
            st_now = self.poll_device_state(force=True)["state"]
            if st_now == DeviceState.SIDELOAD:
                return True
            if st_now == DeviceState.RECOVERY and _ % 16 == 8:
                if run_ofox_pre_hook:
                    self.run_onyx_ofox_pre_flash_hook()
                self._run_short_cmd([adb_bin, "shell", "twrp sideload 2>/dev/null"], timeout=2.0)
            time.sleep(0.25)

        return False

    def request_abort(self) -> Tuple[bool, str]:
        if not self.is_flashing:
            return False, "No active flash running."
        if self.is_sideload_locked:
            msg = "Cannot abort during active ADB Sideload transfer (Anti-Brick Lock)."
            self.log(f"⚠️ {msg}")
            return False, msg

        self.abort_requested = True
        if self._active_proc:
            try:
                self._active_proc.terminate()
            except Exception:
                pass
        return True, "Flashing safely aborted."

    def _cleanup_orphaned_temp_sessions(self):
        """Remove only app-owned sessions whose owning process is no longer running."""
        try:
            for entry in os.scandir(self._temp_root):
                if not entry.is_dir(follow_symlinks=False) or not entry.name.startswith("session_"):
                    continue
                try:
                    pid_text = entry.name.split("_", 2)[1]
                    owner_pid = int(pid_text)
                    if owner_pid == os.getpid():
                        continue
                    try:
                        os.kill(owner_pid, 0)
                        owner_alive = True
                    except PermissionError:
                        owner_alive = True
                    except ProcessLookupError:
                        owner_alive = False
                    except OSError:
                        owner_alive = True
                    if not owner_alive:
                        shutil.rmtree(entry.path, ignore_errors=True)
                except (ValueError, OSError):
                    continue
        except OSError:
            pass

    def _new_temp_dir(self, prefix: str) -> str:
        os.makedirs(self._session_root, exist_ok=True)
        return tempfile.mkdtemp(prefix=prefix, dir=self._session_root)

    def _request_preextract_cleanup(self):
        """Defer deletion if the background extractor is still writing files."""
        self._preextract_cleanup_requested = True
        if self._preextract_event.is_set():
            path = self.preextracted_dir
            if path and os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
            self.preextracted_dir = ""
            self.preextracted_rom = ""
            self.preextracted_imgs = {}
            self._preextract_cleanup_requested = False

    def preextract_rom_in_background(self, rom_path: str):
        """
        Silently pre-extracts boot, init_boot, vendor_boot, dtbo, recovery in the background
        immediately when the user selects a ROM .zip so flashing starts at 0ms!
        """
        if not rom_path or not os.path.isfile(rom_path):
            return
        ext = os.path.splitext(rom_path)[1].lower()
        if ext not in (".zip", ".bin"):
            return

        # Mark the task pending before starting the worker so a flash/close action
        # cannot race ahead and miss a not-yet-scheduled extraction thread.
        if not self._preextract_event.is_set():
            self.log("Previous ROM pre-extraction is still running; skipping duplicate pre-extraction.")
            return
        self._preextract_event.clear()

        def _bg():
            try:
                if self.preextracted_dir and os.path.isdir(self.preextracted_dir):
                    shutil.rmtree(self.preextracted_dir, ignore_errors=True)
                self._preextract_cleanup_requested = False
                t_dir = self._new_temp_dir("preextract_")
                self.preextracted_dir = t_dir
                self.preextracted_rom = rom_path
                pd_bin = self.driver_mgr.resolve_binary("payload-dumper-go")
                from .turbo_engine import extract_partitions_from_rom_zip
                imgs = extract_partitions_from_rom_zip(
                    rom_zip_path=rom_path,
                    target_partitions=["boot", "init_boot", "vendor_boot", "dtbo", "recovery"],
                    out_dir=t_dir,
                    pd_bin=pd_bin,
                    turbo_args_fn=self.turbo.get_payload_dumper_args,
                    stream_cmd_fn=None,
                    log_cb=self.log,
                    progress_cb=None,
                )
                self.preextracted_imgs = imgs
            except Exception:
                self.preextracted_imgs = {}
            finally:
                self._preextract_event.set()
                if self._preextract_cleanup_requested:
                    self._request_preextract_cleanup()

        threading.Thread(target=_bg, daemon=True).start()

    def cleanup_on_exit(self):
        self.turbo.release_transfer_lock()
        self._request_preextract_cleanup()
        session = getattr(self, "_session_root", "")
        if session and os.path.isdir(session):
            shutil.rmtree(session, ignore_errors=True)

    def reboot_device(self, target: str = "system", on_done: Optional[Callable[[bool, str], None]] = None):
        if self.is_flashing or self.is_sideload_locked:
            return

        def _worker():
            # Use cached state first if connected, otherwise do a fast poll
            info = self.poll_device_state(force=True)
            state = info.get("state", DeviceState.DISCONNECTED)
            if state == DeviceState.DISCONNECTED:
                self.log("❌ No USB device connected to reboot.")
                if on_done:
                    on_done(False, "No USB device connected.")
                return

            adb_bin = self.driver_mgr.resolve_binary("adb")
            fb_bin = self.driver_mgr.resolve_binary("fastboot")

            if state in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                if target == "bootloader":
                    cmd = [fb_bin, "reboot-bootloader"]
                elif target == "recovery":
                    cmd = [fb_bin, "reboot", "recovery"]
                elif target == "fastboot":
                    cmd = [fb_bin, "reboot", "fastboot"]
                elif target == "edl":
                    cmd = [fb_bin, "oem", "edl"]
                else:
                    cmd = [fb_bin, "reboot"]
            else:
                if target == "bootloader":
                    cmd = [adb_bin, "reboot", "bootloader"]
                elif target == "recovery":
                    cmd = [adb_bin, "reboot", "recovery"]
                elif target == "sideload":
                    cmd = [adb_bin, "reboot", "sideload"]
                elif target == "fastboot":
                    cmd = [adb_bin, "reboot", "fastboot"]
                elif target == "edl":
                    cmd = [adb_bin, "reboot", "edl"]
                else:
                    cmd = [adb_bin, "reboot"]

            self.log(f"⚡ Rebooting device ({state}) -> {target.upper()}...")
            rc, out, err = self._run_short_cmd(cmd, timeout=6.0)
            if rc != 0 and state in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD) and target == "recovery":
                # Fallback for bootloaders that use fastboot oem reboot-recovery
                rc, out, err = self._run_short_cmd([fb_bin, "oem", "reboot-recovery"], timeout=5.0)
            if rc == 0:
                self.log(f"✅ Device reboot command ({target}) completed.")
            else:
                self.log(f"❌ Reboot failed: {err or out or f'exit code {rc}'}")
            if on_done:
                on_done(rc == 0, f"Rebooted to {target}")

        threading.Thread(target=_worker, daemon=True).start()

    def start_aosp_rom_flash(
        self,
        rom_path: str,
        selected_partitions: List[str],
        disable_vbmeta_verity: bool = True,
        auto_sideload_zip: bool = True,
        on_finish: Optional[Callable[[bool, str], None]] = None,
    ):
        if self.is_flashing:
            return

        def _worker():
            self.is_flashing = True
            self.abort_requested = False
            self.is_sideload_locked = False
            self.turbo.acquire_transfer_lock()
            temp_dir = self._new_temp_dir("flash_extract_")

            try:
                self.set_progress(2.0, "Starting...")
                for i in range(4):
                    self.set_step(i, "pending", "")

                fb_bin = self.driver_mgr.resolve_binary("fastboot")
                adb_bin = self.driver_mgr.resolve_binary("adb")
                pd_bin = self.driver_mgr.resolve_binary("payload-dumper-go")

                ext = os.path.splitext(rom_path)[1].lower()
                extracted_imgs: Dict[str, str] = {}

                self.set_step(0, "active", "Gathering Images")
                self.set_progress(10.0, "Gathering Images")
                rom_name = os.path.basename(rom_path)
                self.log(f"🚀 INITIATING V6 AUTOMATED ROM FLASH: {rom_name}")
                self.log("🔒 [LOCK] USB Polling Paused & Windows Sleep Blocked for uninterrupted transfer.")
                self.log(f"📦 Extracting partitions: {', '.join(selected_partitions) if selected_partitions else 'all default partitions'}")

                initial_state = self.poll_device_state(force=True)["state"]

                if os.path.isdir(rom_path):
                    for p_name, p_img in self.scan_rom_folder(rom_path):
                        if not selected_partitions or p_name in selected_partitions or p_name in ("super", "system", "vendor", "product"):
                            extracted_imgs[p_name] = p_img
                elif ext == ".img":
                    part_target = selected_partitions[0] if selected_partitions else "recovery"
                    extracted_imgs[part_target] = rom_path
                elif ext in (".zip", ".bin"):


                    # If Skip Fastboot Stage selected or device is already in Recovery/Sideload, skip Fastboot pre-extraction!
                    if not selected_partitions:
                        self.log("⚡ [SKIP FASTBOOT] Skip Fastboot Stage enabled -> Proceeding directly to Recovery ADB Sideload!")
                    elif ext == ".zip" and initial_state in (DeviceState.RECOVERY, DeviceState.SIDELOAD):
                        self.log(f"[RECOVERY] Device is already in {initial_state} -> Skipping Fastboot pre-flash and proceeding directly to Recovery Sideload!")
                    else:
                        # Wait up to 8s if background pre-extraction is finishing right now
                        self._preextract_event.wait(timeout=45.0)
                        if self.preextracted_rom == rom_path and self.preextracted_imgs:
                            for p in selected_partitions:
                                if p in self.preextracted_imgs and os.path.isfile(self.preextracted_imgs[p]):
                                    extracted_imgs[p] = self.preextracted_imgs[p]
                        still_needed = [p for p in selected_partitions if p not in extracted_imgs]
                        if still_needed:
                            from .turbo_engine import extract_partitions_from_rom_zip
                            newly_ext = extract_partitions_from_rom_zip(
                                rom_zip_path=rom_path,
                                target_partitions=still_needed,
                                out_dir=temp_dir,
                                pd_bin=pd_bin,
                                turbo_args_fn=self.turbo.get_payload_dumper_args,
                                stream_cmd_fn=None,
                                log_cb=self.log,
                                progress_cb=self.set_progress,
                            )
                            extracted_imgs.update(newly_ext)
                        # Enforce exact user order: boot, init_boot, vendor_boot, dtbo, recovery
                        ordered_imgs: Dict[str, str] = {}
                        for p in selected_partitions:
                            if p in extracted_imgs:
                                ordered_imgs[p] = extracted_imgs[p]
                        extracted_imgs = ordered_imgs

                if selected_partitions and ext in (".zip", ".bin") and initial_state not in (DeviceState.RECOVERY, DeviceState.SIDELOAD):
                    missing_selected = [part for part in selected_partitions if part not in extracted_imgs]
                    if missing_selected:
                        available = ", ".join(sorted(extracted_imgs)) if extracted_imgs else "none"
                        missing_text = ", ".join(missing_selected)
                        raise RuntimeError(
                            "ROM extraction incomplete. Missing selected partition(s): "
                            f"{missing_text}. Extracted: {available}. "
                            "Check the ROM type (full OTA vs incremental OTA), payload.bin integrity, "
                            "and selected partition list. Uncheck partitions not included in this ROM."
                        )

                self.set_step(0, "done", "Gathering Images")
                self.set_step(1, "active", "Flash Fastboot")

                if extracted_imgs:
                    # Ensure device is in Fastboot/Fastbootd mode before running fastboot flash!
                    cur_st = self.poll_device_state(force=True)["state"]
                    if cur_st not in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                        self.log(f"[FASTBOOT] Transitioning device from {cur_st} to Fastboot Mode...")
                        self._run_short_cmd([adb_bin, "reboot", "bootloader"], timeout=3.0)
                        for _ in range(30):
                            if self.abort_requested:
                                raise RuntimeError("Aborted by user.")
                            if self.poll_device_state(force=True)["state"] in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                                break
                            time.sleep(1.0)

                    total_imgs = len(extracted_imgs)
                    for idx, (part, img_file) in enumerate(extracted_imgs.items()):
                        if self.abort_requested:
                            raise RuntimeError("Aborted by user.")
                        pct_now = 30.0 + ((idx + 1) / total_imgs) * 25.0
                        self.set_progress(pct_now, f"Flashing {part}")
                        if part in ("vbmeta", "vbmeta_system", "vbmeta_vendor") and disable_vbmeta_verity:
                            cmd = [fb_bin, "--disable-verity", "--disable-verification", "flash", part, img_file]
                        else:
                            if part in self.ONYX_LOGICAL_PARTITIONS:
                                if self.poll_device_state(force=True)["state"] != DeviceState.FASTBOOTD:
                                    self.log(f"[PORT-ROM / DYNAMIC] Switching to Fastbootd mode for logical partition '{part}'...")
                                    self._stream_command([fb_bin, "reboot", "fastboot"], status_label="Entering Fastbootd")
                                    time.sleep(4.0)
                                # Clear stale Virtual A/B COW partitions so logical partition resize never fails
                                for sfx in ("_a", "_b"):
                                    self._run_short_cmd([fb_bin, "delete-logical-partition", f"{part}{sfx}-cow"], timeout=1.5)
                            cmd = [fb_bin, "flash", part, img_file]
                        self.log(f"⚡ Flashing {part}.img...")
                        rc = self._stream_command(cmd, status_label=f"Flashing {part}", quiet_stdout=True)
                        if part == "recovery" and rc != 0:
                            rc_a = self._stream_command([fb_bin, "flash", "recovery_a", img_file], status_label="Flashing recovery_a", quiet_stdout=True)
                            rc_b = self._stream_command([fb_bin, "flash", "recovery_b", img_file], status_label="Flashing recovery_b", quiet_stdout=True)
                            if rc_a == 0 or rc_b == 0:
                                rc = 0
                        if rc != 0:
                            raise RuntimeError(f"Failed flashing '{part}' (exit code {rc}).")

                self.set_step(1, "done", "Flash Fastboot")
                if extracted_imgs:
                    # All selected fastboot images have been flashed. They are no
                    # longer needed for the later ADB sideload stage; release disk
                    # space before waiting for the user to switch recovery modes.
                    if temp_dir and os.path.isdir(temp_dir):
                        shutil.rmtree(temp_dir, ignore_errors=True)
                        self.log("[STORAGE] Fastboot image cache released after successful partition flashing.")
                    temp_dir = ""
                    self.log("✅ Fastboot partitions flashed! Rebooting device into Recovery...")
                    self.log("=======================================================")
                    self.log("⚠️ ACTION REQUIRED ON PHONE SCREEN:")
                    self.log("  1. Tap 'Wipe' -> 'Format Data' -> type 'yes'")
                    self.log("  2. Go back -> Tap 'Apply Update' -> 'Apply from ADB'")
                    self.log("=======================================================")
                    self.log("⏳ Auto-detecting Recovery ADB Sideload connection...")

                if ext in (".img", ".bin") or os.path.isdir(rom_path) or not auto_sideload_zip:
                    self.set_step(2, "done", "Wait Sideload")
                    self.set_step(3, "done", "Flash Sideload")
                    self.set_progress(100.0, "Completed")
                    if on_finish:
                        on_finish(True, "Fastboot partition image(s) flashed successfully!")
                    return

                self.set_step(2, "active", "Wait Sideload")
                self.set_progress(58.0, "Waiting Sideload")
                if not self._ensure_sideload_mode(run_ofox_pre_hook=True):
                    raise RuntimeError("Timed out waiting for ADB Sideload mode.")

                self.set_step(2, "done", "Wait Sideload")
                self.is_sideload_locked = True
                dev_st = self.poll_device_state(force=True)
                self.log(f"🟢 [CONNECTED] Mode: SIDELOAD | 📱 Model: {dev_st.get('model', 'Android Device')}")
                self.log(f"⚡ Streaming ROM via Unbuffered ADB Sideload: {os.path.basename(rom_path)}")
                self.set_step(3, "active", "Flash Sideload")
                self.set_progress(62.0, "Sideloading")

                rc_side = self._stream_command(
                    [adb_bin, "sideload", rom_path],
                    parse_sideload_pct=True,
                    base_pct=62.0,
                    span_pct=38.0,
                    status_label="Sideloading",
                )
                if rc_side not in (0, 1):
                    raise RuntimeError(f"ADB Sideload exited with code {rc_side}.")

                # Wait briefly for device to return from Sideload to Recovery shell and restore OrangeFox!
                self.run_onyx_ofox_post_flash_hook(wait_for_recovery=True)
                self.set_step(3, "done", "Flash Sideload")
                self.set_progress(100.0, "100% ROM Installed!")
                self.log("=======================================================")
                self.log("✅ AUTOMATED ROM FLASH SEQUENCE COMPLETED SUCCESSFULLY!")
                self.log("=======================================================")
                if on_finish:
                    on_finish(True, "ROM flashed successfully!")

            except Exception as e:
                self.log(f"ERROR: {e}")
                self.set_progress(0.0, "Waiting")
                if on_finish:
                    on_finish(False, str(e))
            finally:
                self.is_sideload_locked = False
                self.is_flashing = False
                self.turbo.release_transfer_lock()
                shutil.rmtree(temp_dir, ignore_errors=True)
                self._request_preextract_cleanup()

        threading.Thread(target=_worker, daemon=True).start()

    def start_kernel_or_recovery_flash(
        self,
        file_path: str,
        target_partition: str = "boot",
        action_mode: str = "auto",
        on_finish: Optional[Callable[[bool, str], None]] = None,
    ):
        if self.is_flashing:
            return

        def _worker():
            self.is_flashing = True
            self.abort_requested = False
            self.is_sideload_locked = False
            self.turbo.acquire_transfer_lock()

            try:
                for i in range(4):
                    self.set_step(i, "pending", "")

                ext = os.path.splitext(file_path)[1].lower()
                adb_bin = self.driver_mgr.resolve_binary("adb")
                fb_bin = self.driver_mgr.resolve_binary("fastboot")
                effective_mode = "sideload_zip" if (action_mode == "auto" and ext == ".zip") else "fastboot_flash"

                self.set_step(0, "done", "Verify Package")
                self.set_step(1, "active", "Prepare Mode")

                if effective_mode == "fastboot_flash":
                    cur_st = self.poll_device_state(force=True)["state"]
                    if cur_st not in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                        self.log(f"[KERNEL/REC] Transitioning device from {cur_st} to Fastboot Mode...")
                        self._run_short_cmd([adb_bin, "reboot", "bootloader"], timeout=3.0)
                        for _ in range(30):
                            if self.abort_requested:
                                raise RuntimeError("Cancelled.")
                            if self.poll_device_state(force=True)["state"] in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                                break
                            time.sleep(1.0)
                    self.set_progress(40.0, f"Flashing {target_partition}")
                    self.set_step(1, "done", "Prepare Mode")
                    self.set_step(2, "active", f"Flash {target_partition}")
                    if target_partition == "recovery":
                        # Per onyx OF_AB_DEVICE_WITH_RECOVERY_PARTITION=1: flash recovery_a and recovery_b, fallback to recovery
                        rc_a = self._stream_command([fb_bin, "flash", "recovery_a", file_path], status_label="Flashing recovery_a")
                        rc_b = self._stream_command([fb_bin, "flash", "recovery_b", file_path], status_label="Flashing recovery_b")
                        if rc_a == 0 or rc_b == 0:
                            rc = 0
                        else:
                            rc = self._stream_command([fb_bin, "flash", "recovery", file_path], status_label="Flashing recovery")
                    else:
                        rc = self._stream_command([fb_bin, "flash", target_partition, file_path], status_label=f"Flashing {target_partition}")
                    if rc != 0:
                        raise RuntimeError(f"Fastboot flash failed ({rc}).")
                    self.set_step(2, "done", f"Flash {target_partition}")
                    self.set_step(3, "done", "Complete")
                    self.set_progress(100.0, "Complete")
                    if on_finish:
                        on_finish(True, f"Flashed {target_partition} successfully!")
                    return

                if not self._ensure_sideload_mode(run_ofox_pre_hook=False):
                    raise RuntimeError("Device did not enter Sideload mode.")

                self.set_step(1, "done", "Prepare Mode")
                self.is_sideload_locked = True
                self.set_step(2, "active", "Flash Kernel")
                rc = self._stream_command(
                    [adb_bin, "sideload", file_path],
                    parse_sideload_pct=True,
                    base_pct=40.0,
                    span_pct=58.0,
                    status_label="Flashing Kernel",
                )
                if rc not in (0, 1):
                    raise RuntimeError(f"Kernel sideload failed ({rc}).")

                self.set_step(2, "done", "Flash Kernel")
                self.set_step(3, "done", "Complete")
                self.set_progress(100.0, "Complete")
                if on_finish:
                    on_finish(True, "Kernel flashed via Sideload!")

            except Exception as e:
                self.log(f"ERROR: {e}")
                self.set_progress(0.0, "Waiting")
                if on_finish:
                    on_finish(False, str(e))
            finally:
                self.is_sideload_locked = False
                self.is_flashing = False
                self.turbo.release_transfer_lock()
                self._request_preextract_cleanup()
        threading.Thread(target=_worker, daemon=True).start()

    def execute_fastboot_utility(
        self,
        action: str,
        extra_arg: str = "",
        on_done: Optional[Callable[[bool, str], None]] = None,
        on_finish: Optional[Callable[[bool, str], None]] = None,
    ):
        cb = on_finish or on_done
        if self.is_flashing:
            return

        def _worker():
            fb_bin = self.driver_mgr.resolve_binary("fastboot")
            adb_bin = self.driver_mgr.resolve_binary("adb")
            st = self.poll_device_state(force=True)["state"]

            # Support Erase / Format in Recovery Mode (OrangeFox / TWRP) as well as Fastboot Mode!
            if st == DeviceState.RECOVERY:
                if action == "erase_frp":
                    cmds = [[adb_bin, "shell", "dd if=/dev/zero of=/dev/block/bootdevice/by-name/frp bs=1M 2>/dev/null; dd if=/dev/zero of=/dev/block/bootdevice/by-name/config bs=1M 2>/dev/null"]]
                elif action == "erase_metadata":
                    cmds = [[adb_bin, "shell", "umount /metadata 2>/dev/null; rm -rf /metadata/ota 2>/dev/null; twrp wipe metadata 2>/dev/null"]]
                elif action == "erase_userdata":
                    cmds = [[adb_bin, "shell", "twrp format data 2>/dev/null; twrp wipe metadata 2>/dev/null; twrp wipe cache 2>/dev/null"]]
                else:
                    cmds = [[fb_bin, action]]
            else:
                if action == "erase_frp":
                    cmds = [[fb_bin, "erase", "frp"], [fb_bin, "erase", "config"]]
                elif action == "erase_metadata":
                    cmds = [[fb_bin, "erase", "metadata"]]
                elif action == "erase_userdata":
                    # Per onyx vendorsetup.sh (OF_WIPE_METADATA_AFTER_DATAFORMAT=1, OF_FORCE_DATA_FORMAT_F2FS=1) & recovery.fstab (/cache = rescue)
                    cmds = [
                        [fb_bin, "-w"],
                        [fb_bin, "erase", "userdata"],
                        [fb_bin, "erase", "metadata"],
                        [fb_bin, "erase", "rescue"],
                    ]
                else:
                    cmds = [[fb_bin, action]]

            last_rc = 0
            for c in cmds:
                rc = self._stream_command(c, status_label=action)
                if rc != 0:
                    last_rc = rc
            if on_done:
                on_done(last_rc == 0, f"{action.replace('_', ' ').title()} finished.")

        threading.Thread(target=_worker, daemon=True).start()


    # =========================================================================
    # ADBKIT + QUICKADB ENHANCEMENTS (16-Partition Folder Scan, Slot A/B, WOF)
    # =========================================================================
    ADBKIT_PRIORITY_PARTITIONS = [
        "preloader", "vbmeta", "vbmeta_system", "vbmeta_vendor", "dtbo",
        "boot", "init_boot", "vendor_boot", "recovery", "super",
        "system", "system_ext", "product", "vendor", "vendor_dlkm",
        "system_dlkm", "odm", "cust", "userdata"
    ]
    ONYX_LOGICAL_PARTITIONS = {
        "system", "system_ext", "product", "vendor", "vendor_dlkm", "system_dlkm", "odm"
    }
    ONYX_DEVICE_PROFILE = {
        "codename": "onyx",
        "model_number": "25053PC47G",
        "marketing_name": "POCO F7 / Redmi Turbo 4 Pro",
        "board_platform": "sun",
        "soc": "xiaomi_sm8750 (Snapdragon 8s Gen 4 / Adreno 830)",
        "kmi": "android15-6.6",
        "kernel_release": "6.6.77-android15",
        "boot_header_version": 4,
        "page_size": 4096,
        "ramdisk_compression": "lz4",
        "super_size_bytes": 11811160064,
        "qti_dynamic_partitions_size": 11806965760,
        "recovery_partition_size": 104857600,
        "usb_vid_xiaomi": "0x2717",
        "usb_vid_google": "0x18D1",
    }

    def scan_rom_folder(self, folder_path: str) -> List[Tuple[str, str]]:
        """Scans an extracted ROM folder and orders .img files by ADBKit's 16-partition priority."""
        if not folder_path or not os.path.isdir(folder_path):
            return []
        found: Dict[str, str] = {}
        for root, _, files in os.walk(folder_path):
            for f in files:
                if f.lower().endswith(".img"):
                    part = os.path.splitext(f)[0].lower()
                    if part not in found:
                        found[part] = os.path.join(root, f)
        ordered: List[Tuple[str, str]] = []
        used = set()
        for p in self.ADBKIT_PRIORITY_PARTITIONS:
            if p in found:
                ordered.append((p, found[p]))
                used.add(p)
        for p in sorted(found.keys()):
            if p not in used:
                ordered.append((p, found[p]))
        return ordered

    def set_active_slot(self, slot: str, on_done: Optional[Callable[[bool, str], None]] = None, on_finish: Optional[Callable[[bool, str], None]] = None):
        cb = on_finish or on_done
        """Switches active A/B slot in Fastboot mode (fastboot --set-active=a|b)."""
        s = slot.strip().lower().replace("_", "")
        if s not in ("a", "b") or self.is_flashing:
            return

        def _worker():
            fb_bin = self.driver_mgr.resolve_binary("fastboot")
            rc = self._stream_command([fb_bin, f"--set-active={s}"], status_label=f"Set Slot {s.upper()}")
            if rc != 0:
                rc = self._stream_command([fb_bin, "set_active", s], status_label=f"Set Slot {s.upper()}")
            self.poll_device_state(force=True)
            if on_done:
                on_done(rc == 0, f"Active Slot set to Slot {s.upper()}" if rc == 0 else f"Failed setting Slot {s.upper()}")

        threading.Thread(target=_worker, daemon=True).start()

    def wake_on_fastboot_or_adb(self, on_done: Optional[Callable[[bool, str], None]] = None):
        """
        Ported from ADBKit internal/adb/wof.go:
        - If in Fastboot mode: runs `fastboot continue` to wake & resume system boot.
        - If in ADB mode: sets `stay_on_while_plugged_in = 7` and wakes/unlocks screen (`keyevent 224 + 82`).
        """
        def _worker():
            st = self.poll_device_state(force=True)["state"]
            adb_bin = self.driver_mgr.resolve_binary("adb")
            fb_bin = self.driver_mgr.resolve_binary("fastboot")
            if st in (DeviceState.FASTBOOT, DeviceState.FASTBOOTD):
                rc = self._stream_command([fb_bin, "continue"], status_label="Fastboot Continue (WOF)")
                msg = "Resumed system boot from Fastboot (WOF)!" if rc == 0 else "Fastboot continue returned non-zero."
                if cb:
                    cb(rc == 0, msg)
            else:
                self._run_short_cmd([adb_bin, "shell", "settings", "put", "global", "stay_on_while_plugged_in", "7"], timeout=2.0)
                rc, _, _ = self._run_short_cmd([adb_bin, "shell", "input keyevent 224 && input keyevent 82 && wm dismiss-keyguard"], timeout=2.5)
                msg = "WOF: Screen Woken, Unlocked & Stay-Awake (Charge=7) Enabled!"
                self.log(msg)
                if cb:
                    cb(rc == 0, msg)

        threading.Thread(target=_worker, daemon=True).start()


    def run_onyx_ofox_pre_flash_hook(self):
        """
        Executes OrangeFox onyx pre_rom_flash.sh logic when device is in Recovery mode:
        1. Resets SPL date (`resetprop ro.build.version.security_patch 2023-12-31`) to prevent anti-rollback block on Port/MIUI/HyperOS ROMs.
        2. Wipes stale `/metadata/ota` directory so virtual A/B never blocks ROM installation.
        3. Backs up active `recovery_${slot}` to `/tmp/fox_backup.img` before ROM overwrites recovery.
        """
        adb_bin = self.driver_mgr.resolve_binary("adb")
        st = self.poll_device_state(force=True)["state"]
        if st != DeviceState.RECOVERY:
            return
        self.log("[OFOX-ONYX] Running pre_rom_flash.sh hook (SPL anti-rollback bypass + /metadata/ota cleanup + OrangeFox backup)...")
        pre_cmd = (
            "write /sys/class/usb_role/a600000.dwc3-role-switch/role device 2>/dev/null; "
            "write /sys/class/usb_role/a600000.ssusb-role-switch/role device 2>/dev/null; "
            "echo 'recovery,magiskboot,Updater,updater,update_engine_sideload' > /proc/sys/walt/sched_lib_name 2>/dev/null; "
            "echo 255 > /proc/sys/walt/sched_lib_mask_force 2>/dev/null; "
            "echo 0 > /sys/fs/selinux/enforce 2>/dev/null; "
            "resetprop ro.build.version.security_patch 2023-12-31 2>/dev/null; "
            "mount /metadata 2>/dev/null; rm -rf /metadata/ota 2>/dev/null; "
            "slot=$(getprop ro.boot.slot_suffix); "
            "if [ -n \"$slot\" ] && [ -e \"/dev/block/bootdevice/by-name/recovery${slot}\" ]; then "
            "dd if=\"/dev/block/bootdevice/by-name/recovery${slot}\" of=/tmp/fox_backup.img bs=1M 2>/dev/null; sync; "
            "fi"
        )
        self._run_short_cmd([adb_bin, "shell", pre_cmd], timeout=8.0)

    def run_onyx_ofox_post_flash_hook(self, wait_for_recovery: bool = False):
        """
        Executes OrangeFox onyx post_rom_flash_completion.sh logic:
        Restores `/tmp/fox_backup.img` to both `recovery_a` and `recovery_b` so OrangeFox survives ROM flashing!
        """
        adb_bin = self.driver_mgr.resolve_binary("adb")
        st = self.poll_device_state(force=True)["state"]
        if wait_for_recovery and st != DeviceState.RECOVERY:
            for _ in range(12):
                time.sleep(1.0)
                st = self.poll_device_state(force=True)["state"]
                if st == DeviceState.RECOVERY:
                    break
        if st != DeviceState.RECOVERY:
            return
        self.log("[OFOX-ONYX] Running post_rom_flash_completion.sh hook (Restoring OrangeFox to recovery_a & recovery_b)...")
        post_cmd = (
            "if [ -s /tmp/fox_backup.img ]; then "
            "for s in _a _b; do "
            "if [ -e \"/dev/block/bootdevice/by-name/recovery${s}\" ]; then "
            "dd if=/tmp/fox_backup.img of=\"/dev/block/bootdevice/by-name/recovery${s}\" bs=1M 2>/dev/null; sync; "
            "fi; done; fi"
        )
        self._run_short_cmd([adb_bin, "shell", post_cmd], timeout=10.0)
