"""
ADB Toolkit | Developed by Mayank Droid
Silent Driver, Platform-Tools, Google USB Driver & Proactive ADB RSA Authorization Manager
"""
import os
import sys
import ssl
import shutil
import zipfile
import urllib.request
import subprocess
import threading
from typing import Dict, Any, Callable, Optional, List


OFFICIAL_LINKS = {
    "google_platform_tools_zip": "https://dl.google.com/android/repository/platform-tools-latest-windows.zip",
    "google_usb_driver_zip": "https://dl.google.com/android/repository/usb_driver_r13-windows.zip",
    "google_usb_driver": "https://developer.android.com/studio/run/win-usb",
    "xiaomi_miflash_driver": "https://miuirom.org/updates/mi-flash-pro",
    "qualcomm_qdloader_driver": "https://qcomdriver.com/",
    "mediatek_usb_driver": "https://mtkdriver.com/",
    "universal_adb_driver": "https://adb.clockworkmod.com/",
    "mayank_droid_hub": "https://mayank-droid.pages.dev",
    "mi_unlock_service": "https://mi-unlock.pages.dev",
    "onyx_services": "https://onyx-services.pages.dev",
    "otaku_hub_pro": "https://otaku-hub-pro.pages.dev",
    "portfolio_hbo": "https://portfolio-hbo.pages.dev",
    "telegram_zoro": "https://t.me/RoranoaxZORO",
    "telegram_mayank": "https://t.me/MayankDroid7",
    "telegram_onyx": "https://t.me/OnyxHub7",
    "youtube_mayank": "https://youtube.com/@mayankdroid",
    "instagram_mayank": "https://www.instagram.com/mayank.droid/",
}


class DriverAndEnvManager:
    def __init__(self, base_dir: str, log_callback: Optional[Callable[[str], None]] = None):
        self.base_dir = base_dir
        self.adb_dir = os.path.join(base_dir, "adb")
        self.drivers_dir = os.path.join(base_dir, "drivers")
        os.makedirs(self.adb_dir, exist_ok=True)
        os.makedirs(self.drivers_dir, exist_ok=True)
        self.log_cb = log_callback or (lambda msg: None)
        self.is_windows = sys.platform.startswith("win")
        self.status: Dict[str, Any] = {
            "adb_ready": False,
            "fastboot_ready": False,
            "payload_dumper_ready": False,
            "path_configured": False,
            "usb_drivers_detected": False,
            "adb_path": "",
            "fastboot_path": "",
            "payload_dumper_path": "",
            "summary_message": "Everything is fine, you can check out.",
        }
        self._ensure_android_key_dir()
        self._sync_existing_pc_platform_tools()
        self._inject_local_adb_into_path()

    def _log(self, msg: str):
        try:
            self.log_cb(str(msg))
        except Exception:
            # Logging must never interrupt device detection or flashing.
            pass

    def _ensure_android_key_dir(self):
        """
        Ensures `%USERPROFILE%\\.android` exists and `ANDROID_USER_HOME` / `HOME` are set
        so `adb.exe` always generates `adbkey` & `adbkey.pub` and sends the RSA
        'Allow USB debugging?' authorization prompt to connected phones!
        """
        try:
            home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
            if home and os.path.isdir(home):
                os.environ.setdefault("HOME", home)
                android_dir = os.path.join(home, ".android")
                os.makedirs(android_dir, exist_ok=True)
        except Exception:
            pass

    def _get_adbkit_windows_sdk_dirs(self) -> List[str]:
        """Ported from ADBKit internal/binary/lookup_windows.go + bundled PyInstaller _MEIPASS + common user folders."""
        dirs = []
        if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
            meipass = getattr(sys, "_MEIPASS")
            dirs.append(os.path.join(meipass, "adb"))
            dirs.append(meipass)
        if getattr(sys, "frozen", False):
            exe_dir = os.path.dirname(os.path.abspath(sys.executable))
            dirs.append(os.path.join(exe_dir, "adb"))
            dirs.append(exe_dir)
        dirs.extend([
            self.adb_dir,
            os.path.join(self.adb_dir, "platform-tools"),
            os.path.join(os.getcwd(), "adb"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "adb"),
        ])
        local_app = os.environ.get("LOCALAPPDATA", "")
        if local_app:
            dirs.append(os.path.join(local_app, "Android", "Sdk", "platform-tools"))
        user_prof = os.environ.get("USERPROFILE", "")
        if user_prof:
            dirs.append(os.path.join(user_prof, "AppData", "Local", "Android", "Sdk", "platform-tools"))
            for sub in ("Downloads", "Desktop", "Documents", "Pictures"):
                sub_dir = os.path.join(user_prof, sub)
                dirs.append(os.path.join(sub_dir, "AOSP_Flasher_v7", "adb"))
                dirs.append(os.path.join(sub_dir, "ADB_Toolkit_By_Mayank_Droid", "adb"))
                dirs.append(os.path.join(sub_dir, "ROM_Flasher_Pro_By_Mayank_Droid", "adb"))
                dirs.append(os.path.join(sub_dir, "platform-tools"))
                dirs.append(os.path.join(sub_dir, "adb"))
                if os.path.isdir(sub_dir):
                    try:
                        for entry in os.listdir(sub_dir):
                            entry_p = os.path.join(sub_dir, entry)
                            if os.path.isdir(entry_p):
                                cand_a = os.path.join(entry_p, "adb")
                                if os.path.isdir(cand_a):
                                    dirs.append(cand_a)
                                if os.path.isfile(os.path.join(entry_p, "payload-dumper-go.exe")) or os.path.isfile(os.path.join(entry_p, "adb.exe")):
                                    dirs.append(entry_p)
                    except Exception:
                        pass
        for env_k in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
            ev = os.environ.get(env_k, "")
            if ev:
                dirs.append(os.path.join(ev, "platform-tools"))
        dirs.extend([r"C:\Android\sdk\platform-tools", r"C:\platform-tools", r"C:\adb"])
        return dirs

    def _sync_existing_pc_platform_tools(self):
        """
        If `adb.exe`, `fastboot.exe`, `AdbWinApi.dll`, `AdbWinUsbApi.dll` already exist in another
        folder on the user's PC, immediately copies them into `self.adb_dir` so ADB & Fastboot
        work at 0ms startup without waiting for any internet download!
        Also synchronizes `adb/` and `adb/platform-tools/` so both directory structures are complete.
        """
        if not self.is_windows:
            return
        
        pt_subdir = os.path.join(self.adb_dir, "platform-tools")
        os.makedirs(pt_subdir, exist_ok=True)

        wanted_files = (
            "adb.exe",
            "fastboot.exe",
            "AdbWinApi.dll",
            "AdbWinUsbApi.dll",
            "libwinpthread-1.dll",
            "sqlite3.exe",
            "mke2fs.exe",
            "mke2fs.conf",
            "make_f2fs.exe",
            "make_f2fs_casefold.exe",
            "etc1tool.exe",
            "hprof-conv.exe",
            "payload-dumper-go.exe",
            "source.properties",
            "NOTICE.txt",
        )

        # Cross-sync between self.adb_dir root and self.adb_dir/platform-tools
        for wf in wanted_files:
            r_file = os.path.join(self.adb_dir, wf)
            pt_file = os.path.join(pt_subdir, wf)
            if os.path.isfile(r_file) and not os.path.isfile(pt_file):
                try:
                    shutil.copy2(r_file, pt_file)
                except Exception:
                    pass
            elif os.path.isfile(pt_file) and not os.path.isfile(r_file):
                try:
                    shutil.copy2(pt_file, r_file)
                except Exception:
                    pass

        local_adb = os.path.join(self.adb_dir, "adb.exe")
        local_fb = os.path.join(self.adb_dir, "fastboot.exe")
        local_pd = os.path.join(self.adb_dir, "payload-dumper-go.exe")
        if os.path.isfile(local_adb) and os.path.isfile(local_fb) and os.path.isfile(local_pd):
            return

        for cand_dir in self._get_adbkit_windows_sdk_dirs():
            if not cand_dir or os.path.abspath(cand_dir) in (os.path.abspath(self.adb_dir), os.path.abspath(pt_subdir)):
                continue
            cand_adb = os.path.join(cand_dir, "adb.exe")
            if os.path.isfile(cand_adb) and os.path.getsize(cand_adb) > 10000:
                for wf in wanted_files:
                    src_f = os.path.join(cand_dir, wf)
                    dst_f = os.path.join(self.adb_dir, wf)
                    dst_pt = os.path.join(pt_subdir, wf)
                    if os.path.isfile(src_f):
                        if not os.path.isfile(dst_f):
                            try:
                                shutil.copy2(src_f, dst_f)
                            except Exception:
                                pass
                        if not os.path.isfile(dst_pt):
                            try:
                                shutil.copy2(src_f, dst_pt)
                            except Exception:
                                pass
                if os.path.isfile(local_adb) and os.path.isfile(local_fb) and os.path.isfile(local_pd):
                    break

    def _inject_local_adb_into_path(self):
        current_path = os.environ.get("PATH", "")
        for p in self._get_adbkit_windows_sdk_dirs():
            if os.path.isdir(p) and p not in current_path:
                current_path = p + os.pathsep + current_path
        os.environ["PATH"] = current_path
        self.status["path_configured"] = True

    def resolve_binary(self, name: str) -> str:
        exe_name = f"{name}.exe" if self.is_windows and not name.endswith(".exe") else name
        for d in self._get_adbkit_windows_sdk_dirs():
            cand = os.path.join(d, exe_name)
            if os.path.isfile(cand) and os.path.getsize(cand) > 10000:
                return cand
        found = shutil.which(exe_name) or shutil.which(name)
        return found or os.path.join(self.adb_dir, exe_name)

    def kill_all_background_tools(self):
        """
        Initialize the local ADB server without terminating existing ADB/Fastboot
        transports. Killing adb.exe or fastboot.exe here can disconnect a device
        or interrupt a user-owned transfer.
        """
        adb_bin = self.resolve_binary("adb")
        if os.path.isfile(adb_bin):
            try:
                kwargs = {
                    "capture_output": True,
                    "timeout": 3.0,
                    "cwd": os.path.dirname(os.path.abspath(adb_bin)),
                }
                if self.is_windows:
                    si = subprocess.STARTUPINFO()
                    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    kwargs["startupinfo"] = si
                    kwargs["creationflags"] = 0x08000000
                subprocess.run([adb_bin, "start-server"], **kwargs)
                self._log("ADB server ready; existing device transports were preserved.")
            except Exception as exc:
                self._log(f"ADB server initialization deferred: {exc}")
        else:
            self._log("ADB binary not found yet; device scan will retry after Platform-Tools setup.")

    def trigger_usb_debugging_auth_prompt(self, full_reconnect: bool = False, target_serial: str = ""):
        """
        Forces the Windows ADB server to send the RSA public key (`adbkey.pub`) to any connected
        Android phone so the 'Allow USB debugging? Always allow from this computer' prompt
        immediately pops up on the phone screen!
        Sends an active test ping to wake up modern Android authorization dialogs.
        """
        adb_bin = self.resolve_binary("adb")
        if not os.path.isfile(adb_bin) and not shutil.which(adb_bin):
            return
        self._ensure_android_key_dir()
        adb_cwd = os.path.dirname(os.path.abspath(adb_bin)) if os.path.isabs(adb_bin) else self.adb_dir
        kwargs: Dict[str, Any] = {
            "stdout": subprocess.PIPE,
            "stderr": subprocess.PIPE,
            "text": True,
            "timeout": 5.0,
            "cwd": adb_cwd if os.path.isdir(adb_cwd) else self.adb_dir,
        }
        if self.is_windows:
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            kwargs["startupinfo"] = si
            kwargs["creationflags"] = 0x08000000
        try:
            subprocess.run([adb_bin, "start-server"], **kwargs)
            if target_serial:
                subprocess.run([adb_bin, "-s", target_serial, "reconnect", "offline"], **kwargs)
                if full_reconnect:
                    subprocess.run([adb_bin, "-s", target_serial, "reconnect"], **kwargs)
                # Actively ping shell to trigger Android OS authorization modal on phone screen!
                try:
                    subprocess.Popen([adb_bin, "-s", target_serial, "shell", "echo ping"], **kwargs)
                except Exception:
                    pass
            else:
                subprocess.run([adb_bin, "reconnect", "offline"], **kwargs)
                if full_reconnect:
                    subprocess.run([adb_bin, "reconnect"], **kwargs)
                try:
                    subprocess.Popen([adb_bin, "shell", "echo ping"], **kwargs)
                except Exception:
                    pass
            subprocess.run([adb_bin, "devices", "-l"], **kwargs)
        except Exception:
            pass

    def _start_adb_daemon_and_trigger_auth(self, adb_bin: str):
        self.trigger_usb_debugging_auth_prompt(full_reconnect=True)
        self._log("ADB Server initialized & USB Debugging RSA authorization handshake triggered.")

    def _download_zip(self, url: str, dest_zip: str, label: str, progress_cb: Optional[Callable[[float, str], None]] = None) -> bool:
        self._log(f"Downloading {label} from {url}...")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        try:
            ctx = ssl.create_default_context()
            resp = urllib.request.urlopen(req, context=ctx, timeout=45)
        except Exception:
            resp = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=45)

        with resp, open(dest_zip, "wb") as out_f:
            total = int(resp.headers.get("Content-Length", 0) or 0)
            done = 0
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                out_f.write(chunk)
                done += len(chunk)
                if total > 0 and progress_cb:
                    pct = min(100.0, (done / total) * 100.0)
                    progress_cb(pct, f"{label} ({int(pct)}%)")
        return os.path.isfile(dest_zip) and os.path.getsize(dest_zip) > 10000

    def auto_download_platform_tools_if_missing(
        self,
        force: bool = False,
        progress_cb: Optional[Callable[[float, str], None]] = None,
        on_complete: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        def _worker():
            self._ensure_android_key_dir()
            self._sync_existing_pc_platform_tools()
            self._inject_local_adb_into_path()

            local_adb = os.path.join(self.adb_dir, "adb.exe")
            local_fb = os.path.join(self.adb_dir, "fastboot.exe")
            adb_exists = os.path.isfile(local_adb) and os.path.getsize(local_adb) > 10000
            fb_exists = os.path.isfile(local_fb) and os.path.getsize(local_fb) > 10000

            # If already present locally, immediately start ADB server & trigger RSA prompt before anything else!
            if adb_exists:
                self._start_adb_daemon_and_trigger_auth(local_adb)

            if force or not (adb_exists and fb_exists):
                zip_target = os.path.join(self.adb_dir, "platform-tools.zip")
                try:
                    if self._download_zip(OFFICIAL_LINKS["google_platform_tools_zip"], zip_target, "Platform-Tools", progress_cb):
                        with zipfile.ZipFile(zip_target, "r") as zf:
                            for member in zf.infolist():
                                if member.is_dir():
                                    continue
                                bname = os.path.basename(member.filename)
                                if not bname or bname.lower() == "payload-dumper-go.exe":
                                    continue
                                with zf.open(member) as s_in, open(os.path.join(self.adb_dir, bname), "wb") as s_out:
                                    shutil.copyfileobj(s_in, s_out)
                        try:
                            os.remove(zip_target)
                        except OSError:
                            pass
                        self._log("✔ Installed Official Google Platform-Tools (adb.exe, fastboot.exe, AdbWinApi.dll, AdbWinUsbApi.dll) into adb/")
                except Exception as e:
                    self._log(f"Platform-Tools download note: {e}")

            inf_path = os.path.join(self.drivers_dir, "usb_driver", "android_winusb.inf")
            if force or not os.path.isfile(inf_path):
                drv_zip = os.path.join(self.drivers_dir, "usb_driver.zip")
                try:
                    if self._download_zip(OFFICIAL_LINKS["google_usb_driver_zip"], drv_zip, "Google USB Driver", progress_cb):
                        with zipfile.ZipFile(drv_zip, "r") as zf:
                            zf.extractall(self.drivers_dir)
                        try:
                            os.remove(drv_zip)
                        except OSError:
                            pass
                        self._log(f"✔ Extracted Official Google USB Driver: {inf_path}")
                        # Automatically install Google USB Driver via pnputil into Windows Driver Store!
                        self.install_google_usb_driver_pnputil()
                except Exception as e:
                    self._log(f"USB Driver download note: {e}")

            self._inject_local_adb_into_path()
            adb_bin = self.resolve_binary("adb")
            fb_bin = self.resolve_binary("fastboot")
            pd_bin = self.resolve_binary("payload-dumper-go")
            adb_exists = os.path.isfile(adb_bin)
            fb_exists = os.path.isfile(fb_bin)

            if adb_exists:
                self._start_adb_daemon_and_trigger_auth(adb_bin)

            if progress_cb:
                progress_cb(0.0, "Ready")

            self.status.update({
                "adb_ready": adb_exists,
                "fastboot_ready": fb_exists,
                "payload_dumper_ready": os.path.isfile(pd_bin),
                "path_configured": True,
                "usb_drivers_detected": os.path.isfile(inf_path),
                "adb_path": adb_bin,
                "fastboot_path": fb_bin,
                "payload_dumper_path": pd_bin,
                "summary_message": "Everything is fine, you can check out.",
            })
            if on_complete:
                try:
                    on_complete(self.status)
                except Exception:
                    pass

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        return t

    def is_admin_elevated(self) -> bool:
        """Checks if current process has full Administrator privileges in Windows."""
        if not self.is_windows:
            return True
        try:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except Exception:
            return False

    def request_admin_elevation(self) -> bool:
        """Spawns an elevated instance of the current application with UAC prompt."""
        if not self.is_windows:
            return False
        try:
            import ctypes
            script_path = os.path.abspath(sys.argv[0])
            params = f'"{script_path}"'
            rc = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, params, os.path.dirname(script_path), 1
            )
            return int(rc) > 32
        except Exception:
            return False

    def install_google_usb_driver_pnputil(self) -> bool:
        inf_path = os.path.join(self.drivers_dir, "usb_driver", "android_winusb.inf")
        if not os.path.isfile(inf_path) or not self.is_windows:
            return False
        try:
            proc = subprocess.run(
                ["pnputil", "/add-driver", inf_path, "/install"],
                capture_output=True,
                text=True,
                creationflags=0x08000000,
            )
            self._log((proc.stdout or proc.stderr or "Google USB Driver installed via pnputil.").strip())
            return proc.returncode in (0, 259, 3010)
        except Exception as e:
            self._log(f"pnputil driver install note: {e}")
            return False
