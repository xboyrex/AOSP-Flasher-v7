"""
ADB Toolkit | Developed by Mayank Droid
Turbo Mode Engine & Maximum Windows / USB / Subprocess / Android I/O Optimizer
"""
import os
import sys
import ctypes
import subprocess
import shutil
from typing import Any, Dict, List, Callable, Optional


class PROCESS_POWER_THROTTLING_STATE(ctypes.Structure):
    _fields_ = [
        ("Version", ctypes.c_ulong),
        ("ControlMask", ctypes.c_ulong),
        ("StateMask", ctypes.c_ulong),
    ]


class TurboEngine:
    """
    Maximum Turbo Mode Tweaks for ROM Extraction & Flashing:
    1. 1.0ms High-Resolution Windows Kernel Timer (`winmm.timeBeginPeriod(1)`) for ultra-low USB & pipe latency
    2. Process & Thread Priority Elevation (`HIGH_PRIORITY_CLASS` + `THREAD_PRIORITY_HIGHEST`)
    3. Windows 11 EcoQoS / Power Throttling Disabler (`SetProcessInformation(ProcessPowerThrottling=4)`)
    4. Windows GUI Ghosting Disabler (`user32.DisableProcessWindowsGhosting()`)
    5. Process Working Set Lock & Dynamic Priority Boost (`SetProcessPriorityBoost`)
    6. Execution State Lock (`ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED | ES_AWAYMODE_REQUIRED`)
    7. Multi-Core Concurrency Unlock (`payload-dumper-go -c <max_threads>`) & `FASTBOOT_SPARSE_LIMIT=512M`
    8. Active Transfer USB Polling Lock (dedicates 100% USB controller bandwidth during active flashes)
    9. Windows 11 DWM Native Rounded Corners (`DwmSetWindowAttribute(33)`)
    """

    ABOVE_NORMAL_PRIORITY_CLASS = 0x00008000
    NORMAL_PRIORITY_CLASS = 0x00000020
    THREAD_PRIORITY_HIGHEST = 2
    THREAD_PRIORITY_NORMAL = 0
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001
    ES_DISPLAY_REQUIRED = 0x00000002
    ES_AWAYMODE_REQUIRED = 0x00000040
    ProcessPowerThrottling = 4
    PROCESS_POWER_THROTTLING_CURRENT_VERSION = 1
    PROCESS_POWER_THROTTLING_EXECUTION_SPEED = 0x1

    def __init__(self, log_callback: Optional[Callable[[str], None]] = None):
        self.log_cb = log_callback or (lambda msg: None)
        self.is_windows = sys.platform.startswith("win")
        self.enabled: bool = True
        # Cap worker fan-out to keep the desktop responsive on high-core systems.
        self.cpu_cores: int = min(8, max(2, os.cpu_count() or 4))
        self.active_transfer_lock: bool = False
        self._timer_1ms_active: bool = False

    def _log(self, msg: str):
        try:
            self.log_cb(str(msg))
        except Exception:
            # Logging must never interrupt device detection or flashing.
            pass

    def set_turbo_mode(self, enabled: bool) -> Dict[str, str]:
        self.enabled = bool(enabled)
        if self.enabled:
            self._apply_all_windows_turbo_tweaks(high=True)
            os.environ.pop("ADB_TRACE", None)
            os.environ["FASTBOOT_SPARSE_LIMIT"] = "512M"
            self._log(
                f"Turbo Mode ON: low-latency timer, up to {self.cpu_cores} I/O workers, above-normal process priority and bounded sparse handling."
            )
        else:
            self._apply_all_windows_turbo_tweaks(high=False)
            os.environ.pop("FASTBOOT_SPARSE_LIMIT", None)
            self._log("Turbo Mode OFF (Standard Windows scheduling & timer profile restored).")
        return self.get_status_summary()

    def _apply_all_windows_turbo_tweaks(self, high: bool = True):
        if not self.is_windows:
            return
        try:
            kernel32 = ctypes.windll.kernel32
            h_proc = kernel32.GetCurrentProcess()
            h_thread = kernel32.GetCurrentThread()

            # 1. Prevent Windows "Not Responding" ghosting
            try:
                ctypes.windll.user32.DisableProcessWindowsGhosting()
            except Exception:
                pass

            # 2. 1.0ms High-Resolution Windows Kernel Timer (winmm.dll)
            try:
                winmm = ctypes.windll.winmm
                if high and not self._timer_1ms_active:
                    if winmm.timeBeginPeriod(1) == 0:
                        self._timer_1ms_active = True
                elif not high and self._timer_1ms_active:
                    winmm.timeEndPeriod(1)
                    self._timer_1ms_active = False
            except Exception:
                pass

            # 3. Process & Thread Priority Class + Dynamic Boost
            # Above-normal is enough for responsiveness without starving system services.
            prio = self.ABOVE_NORMAL_PRIORITY_CLASS if high else self.NORMAL_PRIORITY_CLASS
            kernel32.SetPriorityClass(h_proc, prio)
            kernel32.SetThreadPriority(h_thread, self.THREAD_PRIORITY_NORMAL)
            kernel32.SetProcessPriorityBoost(h_proc, False if high else True)

            # 4. Disable Windows 11 EcoQoS / Execution Speed Throttling (force P-cores & max boost clock)
            try:
                p_state = PROCESS_POWER_THROTTLING_STATE()
                p_state.Version = self.PROCESS_POWER_THROTTLING_CURRENT_VERSION
                p_state.ControlMask = self.PROCESS_POWER_THROTTLING_EXECUTION_SPEED
                p_state.StateMask = 0 if high else self.PROCESS_POWER_THROTTLING_EXECUTION_SPEED
                kernel32.SetProcessInformation(
                    h_proc,
                    self.ProcessPowerThrottling,
                    ctypes.byref(p_state),
                    ctypes.sizeof(p_state),
                )
            except Exception:
                pass
        except Exception:
            pass

    def apply_dwm_rounded_corners(self, hwnd: int):
        """Uses DwmSetWindowAttribute (Attribute 33 = WindowCornerPreferenceRound=2)."""
        if not self.is_windows or not hwnd:
            return
        try:
            val = ctypes.c_int(2)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                ctypes.c_void_p(hwnd),
                33,
                ctypes.byref(val),
                ctypes.sizeof(val),
            )
        except Exception:
            pass

    def acquire_transfer_lock(self):
        self.active_transfer_lock = True
        if self.is_windows:
            try:
                ctypes.windll.kernel32.SetThreadExecutionState(
                    self.ES_CONTINUOUS | self.ES_SYSTEM_REQUIRED
                )
            except Exception:
                pass
        self._log("Active transfer guard enabled; background device polling is paused and Windows sleep is inhibited.")

    def release_transfer_lock(self):
        self.active_transfer_lock = False
        if self.is_windows:
            try:
                ctypes.windll.kernel32.SetThreadExecutionState(self.ES_CONTINUOUS)
            except Exception:
                pass

    def get_payload_dumper_args(self, payload_path: str, out_dir: str, partitions: Optional[List[str]] = None) -> List[str]:
        workers = str(min(8, self.cpu_cores) if self.enabled else max(2, min(4, self.cpu_cores // 2)))
        args = ["-c", workers, "-o", out_dir]
        if partitions:
            args.extend(["-p", ",".join(partitions)])
        args.append(payload_path)
        return args

    def get_subprocess_creation_flags(self) -> int:
        if not self.is_windows:
            return 0
        CREATE_NO_WINDOW = 0x08000000
        if self.enabled:
            return CREATE_NO_WINDOW | self.ABOVE_NORMAL_PRIORITY_CLASS
        return CREATE_NO_WINDOW

    def get_status_summary(self) -> Dict[str, str]:
        return {
            "state": "ENABLED" if self.enabled else "STANDARD",
            "threads": f"{self.cpu_cores} Threads" if self.enabled else f"{max(2, self.cpu_cores // 2)} Threads",
            "priority": "ABOVE_NORMAL + low-latency timer" if self.enabled else "NORMAL_PRIORITY",
            "usb_lock": "ACTIVE" if self.active_transfer_lock else "READY",
        }


# =============================================================================
# BUILT-IN PURE-PYTHON ANDROID OTA payload.bin (CrAU v2) EXTRACTOR
# =============================================================================
import io
import bz2
import lzma
import struct
import zipfile
from typing import Tuple, BinaryIO

# Numeric values from Android update_engine InstallOperation.Type.
OP_REPLACE = 0
OP_REPLACE_BZ = 1
OP_MOVE = 2
OP_BSDIFF = 3
OP_SOURCE_COPY = 4
OP_SOURCE_BSDIFF = 5
OP_ZERO = 6
OP_DISCARD = 7
OP_REPLACE_XZ = 8
OP_PUFFDIFF = 9
OP_BROTLI_BSDIFF = 10
OP_ZUCCHINI = 11
OP_LZ4DIFF_BSDIFF = 12
OP_LZ4DIFF_PUFFDIFF = 13
OP_REPLACE_ZSTD = 14


def _read_varint(buf: bytes, pos: int) -> Tuple[int, int]:
    result = 0
    shift = 0
    length = len(buf)
    while pos < length:
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            return result, pos
        shift += 7
        if shift >= 70:
            raise ValueError("Corrupted protobuf varint in payload.bin manifest.")
    raise ValueError("Unexpected EOF while reading protobuf varint.")


def _iter_protobuf_fields(buf: bytes):
    pos = 0
    length = len(buf)
    while pos < length:
        tag, pos = _read_varint(buf, pos)
        field_num = tag >> 3
        wire_type = tag & 0x07
        if wire_type == 0:
            val, pos = _read_varint(buf, pos)
            yield field_num, wire_type, val
        elif wire_type == 1:
            val = buf[pos : pos + 8]
            pos += 8
            yield field_num, wire_type, val
        elif wire_type == 2:
            sub_len, pos = _read_varint(buf, pos)
            val = buf[pos : pos + sub_len]
            pos += sub_len
            yield field_num, wire_type, val
        elif wire_type == 5:
            val = buf[pos : pos + 4]
            pos += 4
            yield field_num, wire_type, val
        else:
            raise ValueError(f"Unsupported protobuf wire_type={wire_type} at field={field_num}")


def _parse_extent(buf: bytes) -> Tuple[int, int]:
    start_block = 0
    num_blocks = 0
    for fnum, wtype, val in _iter_protobuf_fields(buf):
        if fnum == 1 and wtype == 0:
            start_block = val
        elif fnum == 2 and wtype == 0:
            num_blocks = val
    return start_block, num_blocks


def _parse_install_operation(buf: bytes) -> Dict[str, object]:
    op_type = 0
    data_offset = 0
    data_length = 0
    dst_extents: List[Tuple[int, int]] = []
    for fnum, wtype, val in _iter_protobuf_fields(buf):
        if fnum == 1 and wtype == 0:
            op_type = val
        elif fnum == 2 and wtype == 0:
            data_offset = val
        elif fnum == 3 and wtype == 0:
            data_length = val
        elif fnum == 6 and wtype == 2:
            dst_extents.append(_parse_extent(val))
    return {
        "type": op_type,
        "data_offset": data_offset,
        "data_length": data_length,
        "dst_extents": dst_extents,
    }


def _parse_partition_info(buf: bytes) -> int:
    size = 0
    for fnum, wtype, val in _iter_protobuf_fields(buf):
        if fnum == 1 and wtype == 0:
            size = val
    return size


def _parse_partition_update(buf: bytes) -> Dict[str, object]:
    """Parse PartitionUpdate fields from Android update_metadata.proto."""
    part_name = ""
    part_size = 0
    operations: List[Dict[str, object]] = []
    for fnum, wtype, val in _iter_protobuf_fields(buf):
        if fnum == 1 and wtype == 2:       # partition_name
            part_name = val.decode("utf-8", errors="strict")
        elif fnum == 3 and wtype == 2:     # new_partition_info
            part_size = _parse_partition_info(val)
        elif fnum == 4 and wtype == 2:     # operations
            operations.append(_parse_install_operation(val))
    return {"name": part_name, "size": part_size, "operations": operations}


def parse_payload_manifest(manifest_bytes: bytes) -> Tuple[int, Dict[str, Dict[str, object]]]:
    block_size = 4096
    partitions: Dict[str, Dict[str, object]] = {}
    for fnum, wtype, val in _iter_protobuf_fields(manifest_bytes):
        if fnum == 3 and wtype == 0:
            block_size = int(val)
        elif fnum == 13 and wtype == 2:
            p = _parse_partition_update(val)
            name = str(p["name"])
            if name:
                partitions[name] = p
    return block_size, partitions


def _decompress_operation_data(op_type: int, raw_blob: bytes, expected_len: int) -> bytes:
    if op_type == OP_REPLACE:
        return raw_blob
    if op_type == OP_REPLACE_BZ:
        return bz2.decompress(raw_blob)
    if op_type == OP_REPLACE_XZ:
        return lzma.decompress(raw_blob)
    if op_type == OP_REPLACE_ZSTD:
        try:
            import zstandard  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "This OTA uses ZSTD compression. Install the zstandard package "
                "or provide payload-dumper-go."
            ) from exc
        with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw_blob)) as reader:
            return reader.read()
    if op_type in (OP_ZERO, OP_DISCARD):
        return b"\x00" * expected_len
    raise RuntimeError(
        f"Unsupported OTA operation type {op_type}. This may be an incremental OTA "
        "requiring source-image operations; use a full OTA package."
    )


class _ZipStoredPayloadSlice:
    """
    Zero-Disk-Copy Seekable View into an uncompressed (ZIP_STORED) payload.bin inside a ROM .zip!
    Allows O(1) instant seeking to any partition offset without extracting payload.bin to disk!
    """
    def __init__(self, raw_file: BinaryIO, base_offset: int, length: int):
        self._f = raw_file
        self._base = base_offset
        self._len = length
        self._pos = 0

    def seekable(self) -> bool:
        return True

    def seek(self, offset: int, whence: int = 0) -> int:
        if whence == 0:
            self._pos = max(0, min(self._len, offset))
        elif whence == 1:
            self._pos = max(0, min(self._len, self._pos + offset))
        elif whence == 2:
            self._pos = max(0, min(self._len, self._len + offset))
        self._f.seek(self._base + self._pos)
        return self._pos

    def read(self, size: int = -1) -> bytes:
        if size < 0 or self._pos + size > self._len:
            size = max(0, self._len - self._pos)
        if size == 0:
            return b""
        self._f.seek(self._base + self._pos)
        data = self._f.read(size)
        self._pos += len(data)
        return data


class _PayloadStreamReader:
    def __init__(self, stream: BinaryIO):
        self.stream = stream
        self.pos = 0
        self.is_seekable = False
        try:
            if hasattr(stream, "seekable") and stream.seekable():
                stream.seek(0)
                self.is_seekable = True
        except Exception:
            self.is_seekable = False

    def read_exact_at(self, target_offset: int, length: int) -> bytes:
        if length <= 0:
            return b""
        if self.is_seekable:
            try:
                self.stream.seek(target_offset)
                self.pos = target_offset
                data = self.stream.read(length)
                self.pos += len(data)
                return data
            except Exception:
                self.is_seekable = False

        if target_offset < self.pos:
            raise RuntimeError("Non-seekable stream accessed out of order.")
        to_skip = target_offset - self.pos
        chunk_sz = 1024 * 1024
        while to_skip > 0:
            step = min(chunk_sz, to_skip)
            skipped = self.stream.read(step)
            if not skipped:
                break
            self.pos += len(skipped)
            to_skip -= len(skipped)

        data = self.stream.read(length)
        self.pos += len(data)
        return data


def extract_partitions_from_payload_stream(
    stream: BinaryIO,
    target_partitions: List[str],
    out_dir: str,
    log_cb: Optional[Callable[[str], None]] = None,
    progress_cb: Optional[Callable[[float, str], None]] = None,
) -> Dict[str, str]:
    prog = progress_cb or (lambda p, s: None)

    reader = _PayloadStreamReader(stream)
    header = reader.read_exact_at(0, 24)
    if len(header) < 20 or header[:4] != b"CrAU":
        raise RuntimeError("Invalid payload.bin header (missing CrAU magic bytes).")

    version = struct.unpack(">Q", header[4:12])[0]
    manifest_len = struct.unpack(">Q", header[12:20])[0]
    if version < 2:
        raise RuntimeError(
            f"Unsupported payload.bin version {version}; expected payload v2 or newer."
        )
    if manifest_len <= 0 or manifest_len > 256 * 1024 * 1024:
        raise RuntimeError(f"Invalid payload manifest length: {manifest_len} bytes.")

    metadata_sig_len = struct.unpack(">I", header[20:24])[0]
    manifest_bytes = reader.read_exact_at(24, manifest_len)
    if len(manifest_bytes) != manifest_len:
        raise RuntimeError("payload.bin manifest is truncated or corrupt.")
    data_base_offset = 24 + manifest_len + metadata_sig_len

    block_size, all_parts = parse_payload_manifest(manifest_bytes)
    if block_size <= 0 or block_size > 1024 * 1024:
        raise RuntimeError(f"Invalid payload block size: {block_size}.")

    wanted = [p for p in target_partitions if p in all_parts]
    if not wanted:
        return {}
    # Sort wanted partitions by their starting data_offset so even non-seekable streams read strictly forward
    wanted.sort(
        key=lambda p: min(
            (int(o["data_offset"]) for o in all_parts[p]["operations"] if int(o["data_length"]) > 0),
            default=0,
        )
    )

    os.makedirs(out_dir, exist_ok=True)
    extracted_paths: Dict[str, str] = {}

    total_wanted = len(wanted)
    for idx, part_name in enumerate(wanted):
        pinfo = all_parts[part_name]
        ops: List[Dict[str, object]] = list(pinfo["operations"])  # type: ignore
        part_size = int(pinfo["size"])  # type: ignore
        out_path = os.path.join(out_dir, f"{part_name}.img")

        prog(12.0 + (idx / max(1, total_wanted)) * 18.0, f"Extracting {part_name}.img")

        with open(out_path, "wb") as out_f:
            if part_size > 0:
                out_f.truncate(part_size)

            sorted_ops = sorted(
                ops,
                key=lambda o: int(o["data_offset"]) if int(o["data_length"]) > 0 else -1,
            )
            for op in sorted_ops:
                op_type = int(op["type"])
                d_off = int(op["data_offset"])
                d_len = int(op["data_length"])
                extents: List[Tuple[int, int]] = list(op["dst_extents"])  # type: ignore

                total_dst_bytes = sum(nb * block_size for _, nb in extents)
                if op_type == OP_ZERO or d_len == 0:
                    for start_blk, num_blks in extents:
                        out_f.seek(start_blk * block_size)
                        out_f.write(b"\x00" * (num_blks * block_size))
                    continue

                raw_chunk = reader.read_exact_at(data_base_offset + d_off, d_len)
                decompressed = _decompress_operation_data(op_type, raw_chunk, total_dst_bytes)

                src_pos = 0
                for start_blk, num_blks in extents:
                    byte_count = num_blks * block_size
                    out_f.seek(start_blk * block_size)
                    out_f.write(decompressed[src_pos : src_pos + byte_count])
                    src_pos += byte_count

        if os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
            extracted_paths[part_name] = out_path

    ordered_result: Dict[str, str] = {}
    for p in target_partitions:
        if p in extracted_paths:
            ordered_result[p] = extracted_paths[p]
    return ordered_result


def extract_partitions_from_rom_zip(
    rom_zip_path: str,
    target_partitions: List[str],
    out_dir: str,
    pd_bin: str = "",
    turbo_args_fn: Optional[Callable[[str, str, List[str]], List[str]]] = None,
    stream_cmd_fn: Optional[Callable[..., int]] = None,
    log_cb: Optional[Callable[[str], None]] = None,
    progress_cb: Optional[Callable[[float, str], None]] = None,
) -> Dict[str, str]:
    """Extract selected images from a ROM ZIP or a standalone payload.bin."""
    prog = progress_cb or (lambda p, s: None)
    log = log_cb or (lambda message: None)
    os.makedirs(out_dir, exist_ok=True)
    targets = list(dict.fromkeys(str(p).strip().lower() for p in target_partitions if str(p).strip()))
    extracted: Dict[str, str] = {}

    def collect_dumper_images(parts: List[str]) -> None:
        for root, _, files in os.walk(out_dir):
            for filename in files:
                for part in parts:
                    if filename.lower() == f"{part}.img":
                        candidate = os.path.join(root, filename)
                        try:
                            if os.path.isfile(candidate) and os.path.getsize(candidate) > 0:
                                extracted[part] = candidate
                        except OSError:
                            pass

    def run_dumper(input_path: str, parts: List[str]) -> None:
        if not (pd_bin and os.path.isfile(pd_bin) and turbo_args_fn):
            return
        try:
            args = [pd_bin] + turbo_args_fn(input_path, out_dir, parts)
            kwargs: Dict[str, Any] = {"capture_output": True, "text": True, "check": False}
            if sys.platform.startswith("win"):
                startup = subprocess.STARTUPINFO()
                startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                kwargs["startupinfo"] = startup
                kwargs["creationflags"] = 0x08000000
            result = subprocess.run(args, **kwargs)
            collect_dumper_images(parts)
            if result.returncode:
                detail = (result.stderr or result.stdout or "").strip()
                log(f"payload-dumper-go exit {result.returncode}: {detail[-1000:]}")
        except Exception as exc:
            log(f"payload-dumper-go failed: {exc}")

    def ordered_result() -> Dict[str, str]:
        return {
            part: extracted[part]
            for part in targets
            if part in extracted
            and os.path.isfile(extracted[part])
            and os.path.getsize(extracted[part]) > 0
        }

    if os.path.basename(rom_zip_path).lower() == "payload.bin":
        run_dumper(rom_zip_path, targets)
        missing = [part for part in targets if part not in extracted]
        if missing:
            try:
                with open(rom_zip_path, "rb") as payload_stream:
                    extracted.update(
                        extract_partitions_from_payload_stream(
                            payload_stream, missing, out_dir, log_cb=log, progress_cb=prog
                        )
                    )
            except Exception as exc:
                log(f"Built-in payload extraction failed: {exc}")
        return ordered_result()

    try:
        with zipfile.ZipFile(rom_zip_path, "r") as zf:
            names = zf.namelist()

            # Extract direct images by controlled destination path (avoid archive path traversal).
            for part in targets:
                member = next(
                    (name for name in names if os.path.basename(name).lower() == f"{part}.img"),
                    None,
                )
                if member:
                    destination = os.path.join(out_dir, f"{part}.img")
                    with zf.open(member, "r") as src, open(destination, "wb") as dst:
                        shutil.copyfileobj(src, dst, length=4 * 1024 * 1024)
                    if os.path.getsize(destination) > 0:
                        extracted[part] = destination

            missing = [part for part in targets if part not in extracted]
            payload_member = next(
                (name for name in names if os.path.basename(name).lower() == "payload.bin"),
                None,
            )
            if missing and payload_member:
                # Optional acceleration; never required for correct extraction.
                run_dumper(rom_zip_path, missing)
                missing = [part for part in targets if part not in extracted]

                if missing:
                    try:
                        prog(14.0, "Reading OTA payload...")
                        # ZipExtFile is seekable on supported Python versions. The parser
                        # seeks to operation offsets and avoids writing a multi-GB payload.bin.
                        with zf.open(payload_member, "r") as payload_stream:
                            extracted.update(
                                extract_partitions_from_payload_stream(
                                    payload_stream,
                                    missing,
                                    out_dir,
                                    log_cb=log,
                                    progress_cb=prog,
                                )
                            )
                    except Exception as exc:
                        log(f"Built-in payload extraction failed: {exc}")

                # Compatibility fallback for older external dumpers that only accept
                # a standalone payload.bin. Used only if built-in extraction missed targets.
                missing = [part for part in targets if part not in extracted]
                if missing and pd_bin and os.path.isfile(pd_bin):
                    payload_disk = os.path.join(out_dir, "_payload_input.bin")
                    try:
                        prog(18.0, "Preparing payload for external dumper...")
                        with zf.open(payload_member, "r") as src, open(payload_disk, "wb") as dst:
                            shutil.copyfileobj(src, dst, length=16 * 1024 * 1024)
                        run_dumper(payload_disk, missing)
                    except Exception as exc:
                        log(f"External payload fallback failed: {exc}")
                    finally:
                        try:
                            if os.path.isfile(payload_disk):
                                os.remove(payload_disk)
                        except OSError:
                            pass
            elif missing:
                log("ROM ZIP has no matching standalone images and no payload.bin member.")

    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        log(f"ROM archive read failed: {exc}")
        return {}

    return ordered_result()


def inspect_archive_type(file_path: str) -> str:
    if not file_path or not os.path.isfile(file_path):
        return "unknown"
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".img":
        return "boot_img"
    return "rom_zip"
