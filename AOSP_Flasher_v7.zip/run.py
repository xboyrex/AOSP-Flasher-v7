#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AOSP ROM Flasher Pro Launcher
Developed by Mayank Droid (@MayankDroid7)
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import main

if __name__ == "__main__":
    main.run_app()
