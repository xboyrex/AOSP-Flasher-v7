"""Regression tests for Android OTA payload extraction (stdlib unittest)."""
import os
import struct
import tempfile
import unittest
import zipfile

from core.turbo_engine import (
    extract_partitions_from_payload_stream,
    extract_partitions_from_rom_zip,
    OP_ZERO,
    OP_REPLACE_XZ,
    OP_REPLACE_ZSTD,
    OP_DISCARD,
)


def _varint(value):
    out = bytearray()
    while value > 0x7F:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)


def _varint_field(number, value):
    return _varint(number << 3) + _varint(value)


def _bytes_field(number, value):
    return _varint((number << 3) | 2) + _varint(len(value)) + value


def _minimal_payload(partition=b"boot", image=b"R" * 4096):
    extent = _varint_field(1, 0) + _varint_field(2, len(image) // 4096)
    operation = (
        _varint_field(1, 0)  # REPLACE
        + _varint_field(2, 0)  # data_offset
        + _varint_field(3, len(image))
        + _bytes_field(6, extent)  # dst_extents
    )
    partition_info = _varint_field(1, len(image))
    partition_update = (
        _bytes_field(1, partition)
        + _bytes_field(3, partition_info)  # new_partition_info
        + _bytes_field(4, operation)  # operations
    )
    manifest = _varint_field(3, 4096) + _bytes_field(13, partition_update)
    header = (
        b"CrAU"
        + struct.pack(">Q", 2)
        + struct.pack(">Q", len(manifest))
        + struct.pack(">I", 0)
    )
    return header + manifest + image


class PayloadExtractionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = self.temp.name
        self.payload = _minimal_payload()

    def tearDown(self):
        self.temp.cleanup()

    def test_payload_v2_partition_update_field_numbers(self):
        payload_path = os.path.join(self.root, "payload.bin")
        with open(payload_path, "wb") as handle:
            handle.write(self.payload)
        with open(payload_path, "rb") as handle:
            result = extract_partitions_from_payload_stream(
                handle, ["boot"], os.path.join(self.root, "direct")
            )
        self.assertIn("boot", result)
        with open(result["boot"], "rb") as handle:
            self.assertEqual(handle.read(), b"R" * 4096)

    def test_payload_inside_stored_and_deflated_rom_zip(self):
        for compression in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
            archive = os.path.join(self.root, f"rom-{compression}.zip")
            with zipfile.ZipFile(archive, "w", compression=compression) as handle:
                handle.writestr("payload.bin", self.payload)
            result = extract_partitions_from_rom_zip(
                archive, ["boot"], os.path.join(self.root, f"out-{compression}")
            )
            self.assertIn("boot", result)
            with open(result["boot"], "rb") as image:
                self.assertEqual(image.read(), b"R" * 4096)

    def test_direct_partition_image_inside_zip(self):
        archive = os.path.join(self.root, "images.zip")
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
            handle.writestr("images/boot.img", b"BOOT-IMAGE")
        result = extract_partitions_from_rom_zip(
            archive, ["boot"], os.path.join(self.root, "direct-image")
        )
        self.assertIn("boot", result)
        with open(result["boot"], "rb") as image:
            self.assertEqual(image.read(), b"BOOT-IMAGE")

    def test_android_operation_enum_values(self):
        self.assertEqual(
            (OP_ZERO, OP_DISCARD, OP_REPLACE_XZ, OP_REPLACE_ZSTD),
            (6, 7, 8, 14),
        )


if __name__ == "__main__":
    unittest.main()
