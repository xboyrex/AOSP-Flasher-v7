import tempfile
import unittest
from unittest.mock import Mock

from core.flasher_backend import FlasherBackend, DeviceState
from core.turbo_engine import TurboEngine


class DeviceDetectionTests(unittest.TestCase):
    def make_backend(self, adb_output, fastboot_output=""):
        driver = Mock()
        driver.resolve_binary.side_effect = lambda name: name
        driver.adb_dir = tempfile.gettempdir()
        driver.is_windows = False
        driver._log = Mock()
        turbo = Mock()
        turbo.active_transfer_lock = False

        backend = FlasherBackend(
            base_dir=tempfile.gettempdir(),
            turbo=turbo,
            driver_mgr=driver,
        )

        def run(cmd, timeout=3.5):
            if cmd[0] == "adb" and cmd[1:] == ["devices", "-l"]:
                return 0, adb_output, ""
            if cmd[0] == "fastboot" and cmd[1:] == ["devices"]:
                return 0, fastboot_output, ""
            if cmd[0] == "adb" and "shell" in cmd:
                return 0, "", ""
            return 0, "", ""

        backend._run_short_cmd = run
        return backend

    def test_detects_recovery_sideload_as_distinct_state(self):
        backend = self.make_backend(
            "List of devices attached\nSERIAL123 sideload usb:1 product:onyx model:POCO_F7 device:onyx\n"
        )
        info = backend.poll_device_state(force=True)
        self.assertEqual(info["state"], DeviceState.SIDELOAD)
        self.assertEqual(info["serial"], "SERIAL123")
        self.assertEqual(info["codename"], "onyx")

    def test_detects_unauthorized_adb_state(self):
        backend = self.make_backend(
            "List of devices attached\nSERIAL123 unauthorized usb:1\n"
        )
        info = backend.poll_device_state(force=True)
        self.assertEqual(info["state"], DeviceState.UNAUTHORIZED)

    def test_detects_recovery_mode(self):
        backend = self.make_backend(
            "List of devices attached\nSERIAL789 recovery usb:1 product:onyx model:POCO_F7 device:onyx\n"
        )
        info = backend.poll_device_state(force=True)
        self.assertEqual(info["state"], DeviceState.RECOVERY)

    def test_detects_fastbootd_userspace(self):
        backend = self.make_backend(
            "List of devices attached\n",
            "SERIAL999\tfastboot\n",
        )
        original = backend._run_short_cmd

        def run(cmd, timeout=3.5):
            if cmd[:3] == ["fastboot", "-s", "SERIAL999"] and "getvar" in cmd:
                return 0, "", "is-userspace: yes\nproduct: onyx"
            return original(cmd, timeout)

        backend._run_short_cmd = run
        info = backend.poll_device_state(force=True)
        self.assertEqual(info["state"], DeviceState.FASTBOOTD)

    def test_detects_fastboot_device(self):
        backend = self.make_backend(
            "List of devices attached\n",
            "SERIAL456\tfastboot\n",
        )
        info = backend.poll_device_state(force=True)
        self.assertEqual(info["state"], DeviceState.FASTBOOT)
        self.assertEqual(info["serial"], "SERIAL456")


if __name__ == "__main__":
    unittest.main()
