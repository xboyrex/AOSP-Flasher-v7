import os
import shutil
import tempfile
import unittest

from core.flasher_backend import FlasherBackend


class StorageCleanupTests(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="aosp_storage_test_")
        self.backend = FlasherBackend.__new__(FlasherBackend)
        self.backend._temp_root = os.path.join(self.root, "AOSPFlasher_v7")
        os.makedirs(self.backend._temp_root, exist_ok=True)
        self.backend._session_root = tempfile.mkdtemp(
            prefix=f"session_{os.getpid()}_", dir=self.backend._temp_root
        )
        self.backend.preextracted_dir = ""
        self.backend.preextracted_rom = ""
        self.backend.preextracted_imgs = {}
        import threading
        self.backend._preextract_event = threading.Event()
        self.backend._preextract_event.set()
        self.backend._preextract_cleanup_requested = False

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_temp_directories_are_inside_app_session(self):
        temp_dir = self.backend._new_temp_dir("flash_extract_")
        self.assertTrue(os.path.commonpath([self.backend._session_root, temp_dir]) == self.backend._session_root)

    def test_cleanup_on_exit_removes_app_session(self):
        session = self.backend._session_root
        class Turbo:
            @staticmethod
            def release_transfer_lock():
                pass
        self.backend.turbo = Turbo()
        self.backend.cleanup_on_exit()
        self.assertFalse(os.path.exists(session))

    def test_preextract_cleanup_removes_completed_cache(self):
        cache = self.backend._new_temp_dir("preextract_")
        marker = os.path.join(cache, "boot.img")
        with open(marker, "wb") as handle:
            handle.write(b"image")
        self.backend.preextracted_dir = cache
        self.backend.preextracted_rom = "rom.zip"
        self.backend.preextracted_imgs = {"boot": marker}
        self.backend._request_preextract_cleanup()
        self.assertFalse(os.path.exists(cache))
        self.assertEqual(self.backend.preextracted_dir, "")


if __name__ == "__main__":
    unittest.main()
