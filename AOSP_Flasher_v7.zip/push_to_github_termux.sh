#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# ⚡ AOSP Flasher v7 — Automated GitHub Push Script (For Termux & Linux)
# Developed by Mayank Droid (@MayankDroid7)
# ==============================================================================

set -e

echo "======================================================================"
echo "  ⚡ AOSP FLASHER v7 - AUTOMATED GITHUB REPOSITORY PUSHER"
echo "  Developed by Mayank Droid (@MayankDroid7)"
echo "======================================================================"
echo ""

if ! command -v git >/dev/null 2>&1; then
    echo "[*] Installing git in Termux..."
    pkg update -y && pkg install -y git
fi

PROJECT_DIR="$(pwd)"
git config --global --add safe.directory "$PROJECT_DIR"

GIT_NAME="$(git config --global user.name || true)"
GIT_EMAIL="$(git config --global user.email || true)"

if [ -z "$GIT_NAME" ]; then
    read -p "Enter your GitHub Username (default: MayankDroid): " INPUT_NAME
    GIT_NAME="${INPUT_NAME:-MayankDroid}"
    git config --global user.name "$GIT_NAME"
fi

if [ -z "$GIT_EMAIL" ]; then
    read -p "Enter your GitHub Email: " INPUT_EMAIL
    GIT_EMAIL="${INPUT_EMAIL:-mayankdroid@users.noreply.github.com}"
    git config --global user.email "$GIT_EMAIL"
fi

echo "[✓] Git configured as: $GIT_NAME <$GIT_EMAIL>"
echo ""

read -p "Enter GitHub Repository URL (e.g. https://github.com/username/AOSP-Flasher-v7.git): " REPO_URL
if [ -z "$REPO_URL" ]; then
    echo "[ERROR] Repository URL cannot be empty!"
    exit 1
fi

read -p "Enter Commit Message (default: 'Release: AOSP Flasher v7 - AMOLED Cyber Yellow Edition'): " COMMIT_MSG
COMMIT_MSG="${COMMIT_MSG:-Release: AOSP Flasher v7 - AMOLED Cyber Yellow Edition}"

if [ ! -d ".git" ]; then
    echo "[*] Initializing new Git repository..."
    git init
fi

git branch -M main

cat << 'GITIGNORE' > .gitignore
__pycache__/
*.py[cod]
*$py.class
build/
dist/
*.spec
.DS_Store
GITIGNORE

echo "[*] Staging all project files..."
git add -A

if git diff --cached --quiet; then
    echo "[*] No new changes to commit, proceeding to push..."
else
    git commit -m "$COMMIT_MSG"
fi

if git remote | grep -q "^origin$"; then
    git remote set-url origin "$REPO_URL"
else
    git remote add origin "$REPO_URL"
fi

echo ""
echo "[*] Pushing AOSP Flasher v7 to GitHub (main branch)..."
git push -u origin main --force

echo ""
echo "======================================================================"
echo "  ✅ SUCCESSFULLY PUSHED AOSP FLASHER v7 TO GITHUB!"
echo "  Repository: $REPO_URL"
echo "======================================================================"
