#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AOSP Flasher v7 | Developed by Mayank Droid (@MayankDroid7)
3-Column Bento Architecture with AMOLED + Cyber Yellow High-Contrast Theme:
- Auto ROM Flasher (payload-dumper-go / In-Place Stream Extraction + Fastboot + Recovery Sideload)
- Kernel & Root Lab (AnyKernel3 / KernelSU / SukiSU / Magisk Sideload & Boot/Recovery .img Flash)
- Live Terminal Logs (Real-Time Diagnostic Telemetry Stream + Safety Protocol & Sideload Notes)
- 1-Click In-Place Native WinMemoryCleaner Engine (8 Memory Areas, Zero Popup Window)
- In-Window Drivers & Mayank Droid Official Links Views (Zero Separate OS Popup Windows)
- Fastboot Wipe & Repair Tools (Erase FRP, Wipe Metadata, Format Userdata, Slot A/B, WOF Wake)
- Power & Reboot Menu (System, Bootloader, Recovery, Sideload, Fastbootd, EDL)
"""
import os
import sys
import time
import math
import ctypes
import zipfile
import threading
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox
from typing import Dict, List, Optional


def configure_windows_app_id():
    if not sys.platform.startswith("win"):
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("MayankDroid.AOSPFlasher.V7")
    except Exception:
        pass


configure_windows_app_id()

try:
    import customtkinter as ctk
    from PIL import Image, ImageDraw, ImageTk
except ImportError:
    import subprocess
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "customtkinter", "pillow", "psutil", "--quiet"],
        check=False,
    )
    import customtkinter as ctk
    from PIL import Image, ImageDraw, ImageTk

from core.ram_cleaner import RAMCleanerEngine, MemoryAreas
from core.turbo_engine import TurboEngine
from core.driver_manager import DriverAndEnvManager, OFFICIAL_LINKS
from core.flasher_backend import FlasherBackend, DeviceState


# =============================================================================
# 3. AMOLED + CYBER YELLOW (Bold · High Contrast · Technical Tools)
# =============================================================================
UI = {
    "bg_root": "#050507",          # True AMOLED Black
    "bg_sidebar": "#0C0D10",       # Deep AMOLED Sidebar
    "bg_card": "#13151A",          # Technical Carbon Card
    "bg_recessed": "#090A0D",      # Recessed Input / Terminal
    "bg_pill": "#1D2028",          # Control Pill Surface
    "bg_pill_hover": "#282C37",    # Control Pill Hover
    "border": "#262934",           # Crisp Technical Border
    "border_focus": "#FACC15",     # Cyber Yellow Focus Border
    "blue": "#FACC15",             # Primary Accent: Cyber Yellow (#FACC15)
    "blue_hover": "#FDE047",       # Primary Hover: Bright Solar Yellow (#FDE047)
    "btn_text_on_yellow": "#050507", # High-contrast dark text on yellow buttons
    "green_bg": "#0F291E",
    "green_fg": "#22C55E",
    "amber_bg": "#2B2108",
    "amber_fg": "#FACC15",
    "danger": "#EF4444",
    "text_primary": "#FFFFFF",
    "text_secondary": "#9CA3AF",
    "text_dim": "#6B7280",
}

MODE_CTA_LABELS = {
    "ROM": "▶   START AUTOMATED FLASH",
    "KERNEL": "⚡   FLASH CUSTOM KERNEL",
}


def get_base_dir() -> str:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return getattr(sys, "_MEIPASS")
    return os.path.dirname(os.path.abspath(__file__))


def get_writable_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


class PhosphorVectorEngine:
    """Renders crisp 24x24 vector icons tinted for AMOLED + Cyber Yellow theme."""
    @staticmethod
    def get_icon(name: str, size: int = 20, color: tuple = (250, 204, 21, 255)) -> ctk.CTkImage:
        scale = 4
        S = 24 * scale
        im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        w = int(2.0 * scale)

        if name == "rom":
            pad = int(4.5 * scale)
            d.rounded_rectangle([pad, pad, S - pad, S - pad], radius=int(3 * scale), outline=color, width=w)
            d.rounded_rectangle([pad + 3*scale, pad + 3*scale, S - pad - 3*scale, S - pad - 3*scale], radius=int(1.5 * scale), fill=color)
            for p in [8.5, 12, 15.5]:
                d.line([p * scale, 1.5 * scale, p * scale, 4.5 * scale], fill=color, width=w)
                d.line([p * scale, 19.5 * scale, p * scale, 22.5 * scale], fill=color, width=w)
                d.line([1.5 * scale, p * scale, 4.5 * scale, p * scale], fill=color, width=w)
                d.line([19.5 * scale, p * scale, 22.5 * scale, p * scale], fill=color, width=w)
        elif name == "kernel":
            d.rounded_rectangle([2.5 * scale, 3.5 * scale, 21.5 * scale, 20.5 * scale], radius=int(3 * scale), outline=color, width=w)
            d.line([6 * scale, 9 * scale, 9.5 * scale, 12 * scale], fill=color, width=w)
            d.line([9.5 * scale, 12 * scale, 6 * scale, 15 * scale], fill=color, width=w)
            d.line([11.5 * scale, 15 * scale, 16.5 * scale, 15 * scale], fill=color, width=w)
        elif name == "logs":
            d.rounded_rectangle([2.5 * scale, 4 * scale, 21.5 * scale, 20 * scale], radius=int(3 * scale), outline=color, width=w)
            d.line([2.5 * scale, 8 * scale, 21.5 * scale, 8 * scale], fill=color, width=w)
            d.line([5.5 * scale, 12 * scale, 8.5 * scale, 14.5 * scale], fill=color, width=w)
            d.line([8.5 * scale, 14.5 * scale, 5.5 * scale, 17 * scale], fill=color, width=w)
        elif name == "folder":
            d.line([3 * scale, 6 * scale, 8.5 * scale, 6 * scale], fill=color, width=w)
            d.line([8.5 * scale, 6 * scale, 10.5 * scale, 8.5 * scale], fill=color, width=w)
            d.line([10.5 * scale, 8.5 * scale, 21 * scale, 8.5 * scale], fill=color, width=w)
            d.rounded_rectangle([3 * scale, 8.5 * scale, 21 * scale, 19 * scale], radius=int(2 * scale), outline=color, width=w)
        elif name == "refresh":
            d.arc([4.5 * scale, 4.5 * scale, 19.5 * scale, 19.5 * scale], start=35, end=330, fill=color, width=w)
            d.polygon([(19.5 * scale, 4 * scale), (22.5 * scale, 9 * scale), (16.5 * scale, 8.5 * scale)], fill=color)
        elif name == "ram":
            d.arc([3.5 * scale, 4 * scale, 20.5 * scale, 21 * scale], start=140, end=400, fill=color, width=w)
            d.line([12 * scale, 12.5 * scale, 16.5 * scale, 8 * scale], fill=color, width=w)
        elif name == "driver":
            d.rounded_rectangle([4 * scale, 6 * scale, 20 * scale, 18 * scale], radius=int(2.5 * scale), outline=color, width=w)
            d.line([8 * scale, 12 * scale, 16 * scale, 12 * scale], fill=color, width=w)
        elif name == "trash":
            d.line([4 * scale, 6 * scale, 20 * scale, 6 * scale], fill=color, width=w)
            d.rounded_rectangle([6 * scale, 6 * scale, 18 * scale, 20 * scale], radius=int(2 * scale), outline=color, width=w)
        else:
            d.ellipse([5 * scale, 5 * scale, 19 * scale, 19 * scale], outline=color, width=w)

        smooth = im.resize((size, size), Image.Resampling.LANCZOS)
        return ctk.CTkImage(light_image=smooth, dark_image=smooth, size=(size, size))


class ROMFlasherProApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("Dark")
        try:
            ctk.set_widget_scaling(1.0)
            ctk.set_window_scaling(1.0)
        except Exception:
            pass

        self.asset_root = get_base_dir()
        self.work_root = get_writable_dir()
        self.icons_dir = os.path.join(self.asset_root, "assets", "icons", "png")

        self.title("AOSP Flasher v7 | By xboyrex")
        w, h = 1140, 745
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = max(0, (sw - w) // 2)
        y = max(0, (sh - h) // 2 - 18)
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.minsize(1050, 680)
        self.configure(fg_color=UI["bg_root"])

        self._apply_window_and_taskbar_pfp_icon()
        self.protocol("WM_DELETE_WINDOW", self._on_close_request)
        self.bind_all("<Control-Shift-M>", lambda e: self._on_click_ram_boost())
        self.bind_all("<Control-Shift-m>", lambda e: self._on_click_ram_boost())

        self._icon_cache: Dict[str, ctk.CTkImage] = {}
        self.active_mode: str = "ROM"
        self.last_workflow_mode: str = "ROM"
        self.selected_rom_path: str = ""
        self.selected_kernel_path: str = ""
        self.kernel_part_var = tk.StringVar(value="boot")

        self.target_progress: float = 0.0
        self.display_progress: float = 0.0
        self.progress_subtitle: str = "Standby"
        self._is_ram_cleaning: bool = False
        self._pulse_phase: float = 0.0

        # Smooth Marquee State for bottom info ticker
        self._ticker_full_text = (
            "   •   FRP: Clears Google Factory Reset Protection lock   •   "
            "Metadata: Resets encryption states (Useful when switching ROMs)   •   "
            "Userdata: Performs a full factory reset & wipes internal storage   •   "
            "AOSP 47% Rule: During ADB Sideload, progress naturally finishes around 47% (= 100% full ROM transfer)   "
        )
        self._ticker_offset = 0

        # Core Engines
        self.ram_cleaner = RAMCleanerEngine(log_callback=self.append_log)
        self.turbo_engine = TurboEngine(log_callback=self.append_log)
        self.driver_mgr = DriverAndEnvManager(self.work_root, log_callback=self.append_log)
        self.driver_mgr.kill_all_background_tools()
        self.backend = FlasherBackend(
            base_dir=self.work_root,
            turbo=self.turbo_engine,
            driver_mgr=self.driver_mgr,
            log_callback=self.append_log,
            progress_callback=self._on_backend_progress,
            step_callback=self._on_backend_step,
        )

        # Build UI (Original 3-Zone Bento Layout)
        self._build_3zone_layout()
        self._build_toast_overlay()
        self._update_ring_image(0, "Standby")

        # Exact Startup Logs from New Text Document.txt
        self.append_log("🚀 ROM Flasher Pro v6.0 Cyber-Command Engine Initialized.")
        cpu_count = os.cpu_count() or 4
        self.append_log(f"⚡ Multi-Core Payload Engine Ready ({cpu_count} Logical Cores Detected).")

        self.turbo_engine.set_turbo_mode(True)
        self.after(100, lambda: self.turbo_engine.apply_dwm_rounded_corners(self.winfo_id()))
        self.after(150, self._start_background_startup_tasks)
        self.after(500, self._poll_device_loop)
        pass
        self.after(50, self._step_smooth_animations)

    def _apply_window_and_taskbar_pfp_icon(self):
        ico_path = os.path.join(self.asset_root, "assets", "icon.ico")
        logo_png = os.path.join(self.asset_root, "assets", "logo.png")
        if os.path.isfile(ico_path):
            try:
                self.iconbitmap(default=ico_path)
                self.wm_iconbitmap(ico_path)
            except Exception:
                pass
        if os.path.isfile(logo_png):
            try:
                pil_ic = Image.open(logo_png).convert("RGBA")
                self._tk_icon_256 = ImageTk.PhotoImage(pil_ic.resize((256, 256), Image.Resampling.LANCZOS))
                self._tk_icon_48 = ImageTk.PhotoImage(pil_ic.resize((48, 48), Image.Resampling.LANCZOS))
                self.wm_iconphoto(True, self._tk_icon_256, self._tk_icon_48)
            except Exception:
                pass

    def load_icon(self, name: str, size: int = 20, color: tuple = (250, 204, 21, 255)) -> ctk.CTkImage:
        key = f"{name}_{size}"
        if key in self._icon_cache:
            return self._icon_cache[key]
        png_path = os.path.join(self.icons_dir, f"{name}.png")
        if os.path.isfile(png_path):
            im = Image.open(png_path).convert("RGBA")
            ic = ctk.CTkImage(light_image=im, dark_image=im, size=(size, size))
        else:
            ic = PhosphorVectorEngine.get_icon(name, size, color)
        self._icon_cache[key] = ic
        return ic

    def _load_asset_image(self, filename: str, w: int, h: int) -> ctk.CTkImage:
        p = os.path.join(self.asset_root, "assets", filename)
        if os.path.isfile(p):
            im = Image.open(p).convert("RGBA")
        else:
            im = Image.new("RGBA", (w, h), (19, 21, 26, 255))
        return ctk.CTkImage(light_image=im, dark_image=im, size=(w, h))

    def _render_smooth_progress_ring(self, pct: float, size: int = 128) -> ctk.CTkImage:
        scale = 4
        S = size * scale
        im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)

        pad = int(S * 0.10)
        ring_w = int(S * 0.095)
        d.ellipse([pad, pad, S - pad, S - pad], outline=(34, 38, 48, 255), width=ring_w)

        if pct > 0.3:
            end_ang = -90 + (pct / 100.0) * 360.0
            arc_col = (34, 197, 94, 255) if pct >= 99.5 else (250, 204, 21, 255)
            # Subtle outer glow
            d.arc([pad - 2, pad - 2, S - pad + 2, S - pad + 2], start=-90, end=end_ang, fill=(arc_col[0], arc_col[1], arc_col[2], 70), width=ring_w + 4)
            d.arc([pad, pad, S - pad, S - pad], start=-90, end=end_ang, fill=arc_col, width=ring_w)

        smooth = im.resize((size, size), Image.Resampling.LANCZOS)
        return ctk.CTkImage(light_image=smooth, dark_image=smooth, size=(size, size))

    def _step_marquee_ticker(self):
        try:
            if hasattr(self, "fb_ticker_lbl") and self.active_mode in ("ROM", "KERNEL"):
                txt = self._ticker_full_text
                n = len(txt)
                window_len = 72
                doubled = txt + txt
                chunk = doubled[self._ticker_offset : self._ticker_offset + window_len]
                self.fb_ticker_lbl.configure(text=chunk)
                self._ticker_offset = (self._ticker_offset + 1) % n
        except Exception:
            pass
        self.after(220, self._step_marquee_ticker)

    def _step_smooth_animations(self):
        try:
            # Smooth easing for progress ring
            diff = self.target_progress - self.display_progress
            if abs(diff) > 0.25:
                self.display_progress += diff * 0.22
                self._update_ring_image(self.display_progress, self.progress_subtitle)
            elif abs(diff) > 0.01:
                self.display_progress = self.target_progress
                self._update_ring_image(self.display_progress, self.progress_subtitle)
        except Exception:
            pass
        self.after(45, self._step_smooth_animations)

    # =========================================================================
    # 3-ZONE BENTO LAYOUT (EXACT ORIGINAL ARCHITECTURE)
    # =========================================================================
    def _build_3zone_layout(self):
        self.root_grid = ctk.CTkFrame(self, fg_color="transparent")
        self.root_grid.pack(fill="both", expand=True, padx=16, pady=14)
        self.root_grid.grid_columnconfigure(0, weight=0, minsize=240)
        self.root_grid.grid_columnconfigure(1, weight=1)
        self.root_grid.grid_columnconfigure(2, weight=0, minsize=312)
        self.root_grid.grid_rowconfigure(0, weight=1)

        self.sidebar = ctk.CTkFrame(
            self.root_grid,
            fg_color=UI["bg_sidebar"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
            width=240,
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.sidebar.grid_propagate(False)
        self._build_zone1_sidebar(self.sidebar)

        self.center_zone = ctk.CTkFrame(self.root_grid, fg_color="transparent")
        self.center_zone.grid(row=0, column=1, sticky="nsew", padx=(0, 12))
        self._build_zone2_center(self.center_zone)

        self.right_zone = ctk.CTkFrame(self.root_grid, fg_color="transparent", width=312)
        self.right_zone.grid(row=0, column=2, sticky="nsew")
        self.right_zone.grid_propagate(False)
        self._build_zone3_right_dock(self.right_zone)

    # -------------------------------------------------------------------------
    # ZONE 1: LEFT SIDEBAR (3 Core Tabs + Easy Flow + Power/USB + RAM Cleaner)
    # -------------------------------------------------------------------------
    def _build_zone1_sidebar(self, parent):
        brand_row = ctk.CTkFrame(parent, fg_color="transparent")
        brand_row.pack(fill="x", padx=14, pady=(14, 10))

        logo_img = self._load_asset_image("logo.png", 44, 44)
        ctk.CTkLabel(brand_row, text="", image=logo_img).pack(side="left", padx=(0, 10))

        b_txt = ctk.CTkFrame(brand_row, fg_color="transparent")
        b_txt.pack(side="left")
        ctk.CTkLabel(
            b_txt,
            text="AOSP Flasher v7",
            font=ctk.CTkFont(family="Segoe UI", size=16, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(anchor="w")
        ctk.CTkLabel(
            b_txt,
            text="By xboyrex",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["blue"],
        ).pack(anchor="w")
        ctk.CTkLabel(
            b_txt,
            text="ㅤᏞᴀᴢʏㅤᎷꫝʏᴀɴк まやんく",
            font=ctk.CTkFont(family="Segoe UI", size=8),
            text_color=UI["text_dim"],
        ).pack(anchor="w")

        ctk.CTkLabel(
            parent,
            text="WORKFLOWS",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=UI["text_dim"],
        ).pack(anchor="w", padx=16, pady=(2, 4))

        # ONLY the 3 Tabs from Screenshots (Removed HyperOS and Universal Root)
        self.nav_btns: Dict[str, ctk.CTkButton] = {}
        nav_items = [
            ("ROM", "  Auto ROM Flasher", "rom"),
            ("KERNEL", "  Kernel & Root Lab", "kernel"),
            ("LOGS", "  Live Terminal Logs", "logs"),
        ]
        for key, label, ic_name in nav_items:
            is_act = key == "ROM"
            btn = ctk.CTkButton(
                parent,
                text=label,
                image=self.load_icon(ic_name, 24, (5, 5, 7, 255) if is_act else (250, 204, 21, 255)),
                compound="left",
                anchor="w",
                height=38,
                corner_radius=9,
                fg_color=UI["blue"] if is_act else "transparent",
                hover_color=UI["blue_hover"] if is_act else UI["bg_pill"],
                text_color=UI["btn_text_on_yellow"] if is_act else UI["text_secondary"],
                font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda k=key: self.switch_mode(k),
            )
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_btns[key] = btn

        # EASY FLOW Box (From Screenshots)
        ef_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_recessed"],
            corner_radius=12,
            border_width=1,
            border_color=UI["border"],
        )
        ef_card.pack(fill="x", padx=10, pady=(8, 4))

        ctk.CTkLabel(
            ef_card,
            text="⚙ EASY FLOW",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=UI["blue"],
        ).pack(anchor="w", padx=10, pady=(6, 2))

        ef_txt = (
            "1. Connect phone via USB\n"
            "2. Use Power Menu -> Bootloader\n"
            "3. Select ROM .zip & Start\n"
            "4. Format Data in Recovery\n"
            "5. Start ADB Sideload on phone"
        )
        ctk.CTkLabel(
            ef_card,
            text=ef_txt,
            font=ctk.CTkFont(family="Segoe UI", size=9),
            text_color=UI["text_secondary"],
            justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 6))

        # PERFORMANCE & DRIVERS
        ctk.CTkLabel(
            parent,
            text="PERFORMANCE & TOOLS",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=UI["text_dim"],
        ).pack(anchor="w", padx=16, pady=(6, 3))

        boost_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_recessed"],
            corner_radius=12,
            border_width=1,
            border_color=UI["border"],
        )
        boost_card.pack(fill="x", padx=10, pady=2)

        turbo_row = ctk.CTkFrame(boost_card, fg_color="transparent")
        turbo_row.pack(fill="x", padx=10, pady=(6, 2))
        ctk.CTkLabel(
            turbo_row,
            text="Turbo Mode",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        self.turbo_var = tk.BooleanVar(value=True)
        self.turbo_switch = ctk.CTkSwitch(
            turbo_row,
            text="",
            variable=self.turbo_var,
            command=self._on_toggle_turbo,
            width=38,
            height=20,
            progress_color=UI["blue"],
            button_color=UI["text_primary"],
            button_hover_color=UI["text_primary"],
        )
        self.turbo_switch.pack(side="right")

        # 1-Click Direct In-Place WinMemoryCleaner Button
        self.ram_btn = ctk.CTkButton(
            boost_card,
            text="  RAM Cleaner (Boost)",
            image=self.load_icon("ram", 22),
            compound="left",
            anchor="w",
            height=30,
            corner_radius=8,
            fg_color=UI["bg_pill"],
            hover_color=UI["green_bg"],
            text_color=UI["text_primary"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=self._on_click_ram_boost,
        )
        self.ram_btn.pack(fill="x", padx=8, pady=2)

        # In-Window Driver Status View Button
        self.driver_btn = ctk.CTkButton(
            boost_card,
            text="  Drivers & ADB Ready",
            image=self.load_icon("driver", 22),
            compound="left",
            anchor="w",
            height=30,
            corner_radius=8,
            fg_color=UI["bg_pill"],
            hover_color=UI["bg_pill_hover"],
            text_color=UI["text_primary"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=lambda: self.switch_mode("DRIVERS"),
        )
        self.driver_btn.pack(fill="x", padx=8, pady=2)

        # Power & Reboot Menu + Scan / Refresh USB Buttons (From Screenshots)
        ctk.CTkButton(
            boost_card,
            text="  Power & Reboot Menu",
            image=self.load_icon("power", 22),
            compound="left",
            anchor="w",
            height=30,
            corner_radius=8,
            fg_color=UI["bg_pill"],
            hover_color=UI["bg_pill_hover"],
            border_width=1,
            border_color=UI["blue"],
            text_color=UI["blue"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=self._open_power_menu_dialog,
        ).pack(fill="x", padx=8, pady=2)

        self.btn_scan_usb = ctk.CTkButton(
            boost_card,
            text="  Scan / Refresh USB",
            image=self.load_icon("refresh", 20, (5, 5, 7, 255)),
            compound="left",
            height=30,
            corner_radius=8,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=self._on_click_refresh_device,
        )
        self.btn_scan_usb.pack(fill="x", padx=8, pady=(2, 6))

        # Minimal Official Links Button at Bottom of Sidebar (Single Branding at Top Only!)
        ctk.CTkButton(
            parent,
            text="🌐  Official Links & Support ↗",
            height=30,
            corner_radius=8,
            fg_color=UI["bg_recessed"],
            hover_color=UI["bg_pill"],
            border_width=1,
            border_color=UI["border"],
            text_color=UI["blue"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=lambda: self.switch_mode("LINKS"),
        ).pack(fill="x", side="bottom", padx=10, pady=10)

    # -------------------------------------------------------------------------
    # ZONE 2: CENTER MAIN CONFIGURATION & FASTBOOT CONTROLS
    # -------------------------------------------------------------------------
    def _build_zone2_center(self, parent):
        # Dynamic Next-Step Guidance Banner at Top of Center Zone (From Screenshots)
        self.guidance_banner = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_card"],
            corner_radius=12,
            border_width=1,
            border_color=UI["border"],
            height=34,
        )
        self.guidance_banner.pack(fill="x", pady=(0, 8))
        self.guidance_banner.pack_propagate(False)

        self.guidance_lbl = ctk.CTkLabel(
            self.guidance_banner,
            text="💡 NEXT STEP: Connect your phone via USB cable (Enable USB Debugging or boot into Fastboot/Recovery).",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["blue"],
            anchor="w",
        )
        self.guidance_lbl.pack(side="left", padx=14, fill="x", expand=True)

        self.center_work_wrap = ctk.CTkFrame(parent, fg_color="transparent")
        self.center_work_wrap.pack(fill="both", expand=True)

        self.config_card = ctk.CTkFrame(
            self.center_work_wrap,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        self.config_card.pack(fill="both", expand=True, pady=(0, 8))

        # --- Panel 1: Auto ROM Flasher (Matching Screenshots 33, 30, 31, 32) ---
        self.rom_panel = ctk.CTkFrame(self.config_card, fg_color="transparent")
        self.rom_panel.pack(fill="both", expand=True, padx=22, pady=14)

        hdr1 = ctk.CTkFrame(self.rom_panel, fg_color="transparent")
        hdr1.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(
            hdr1,
            text="1. SELECT ROM PACKAGE (.zip)",
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        self.rom_size_badge = ctk.CTkLabel(
            hdr1,
            text="  Size: --  ",
            fg_color=UI["amber_bg"],
            text_color=UI["blue"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
        )
        self.rom_size_badge.pack(side="right")

        rom_input_bar = ctk.CTkFrame(
            self.rom_panel,
            fg_color=UI["bg_recessed"],
            corner_radius=10,
            border_width=1,
            border_color=UI["border_focus"],
            height=44,
        )
        rom_input_bar.pack(fill="x", pady=(0, 12))
        rom_input_bar.pack_propagate(False)

        ctk.CTkButton(
            rom_input_bar,
            text=" Browse & Load ROM (.zip)",
            image=self.load_icon("folder", 22, (5, 5, 7, 255)),
            compound="left",
            width=185,
            height=32,
            corner_radius=7,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=self._browse_rom_file,
        ).pack(side="right", padx=6, pady=5)

        self.rom_file_lbl = ctk.CTkLabel(
            rom_input_bar,
            text="No ROM package selected (Click 'Browse & Load ROM' to select .zip)",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["text_secondary"],
            anchor="w",
        )
        self.rom_file_lbl.pack(side="left", fill="x", expand=True, padx=(14, 6))

        # Section 2: Fastboot Partitions to Extract + Quick Presets
        part_hdr = ctk.CTkFrame(self.rom_panel, fg_color="transparent")
        part_hdr.pack(fill="x", pady=(0, 6))

        ctk.CTkLabel(
            part_hdr,
            text="2. FASTBOOT PARTITIONS TO EXTRACT",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        preset_row = ctk.CTkFrame(part_hdr, fg_color="transparent")
        preset_row.pack(side="right")

        ctk.CTkLabel(
            preset_row,
            text="Quick Presets:",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=UI["text_dim"],
        ).pack(side="left", padx=(0, 6))

        ctk.CTkButton(
            preset_row,
            text="All (Recommended)",
            width=115,
            height=24,
            corner_radius=6,
            fg_color=UI["amber_bg"],
            hover_color=UI["blue"],
            text_color=UI["blue"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=self._preset_all_partitions,
        ).pack(side="left", padx=2)

        ctk.CTkButton(
            preset_row,
            text="Skip Fastboot Stage",
            width=118,
            height=24,
            corner_radius=6,
            fg_color=UI["bg_pill"],
            hover_color=UI["danger"],
            text_color=UI["text_secondary"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=self._preset_skip_partitions,
        ).pack(side="left", padx=2)

        chk_box = ctk.CTkFrame(
            self.rom_panel,
            fg_color=UI["bg_recessed"],
            corner_radius=12,
            border_width=1,
            border_color=UI["border"],
        )
        chk_box.pack(fill="x", pady=(0, 10))

        chk_inner = ctk.CTkFrame(chk_box, fg_color="transparent")
        chk_inner.pack(fill="x", padx=16, pady=10)
        chk_inner.grid_columnconfigure((0, 1), weight=1, uniform="rom_chk")

        self.partition_vars: Dict[str, tk.BooleanVar] = {}
        part_items = [
            ("boot", "boot (Kernel + Ramdisk)"),
            ("init_boot", "init_boot (Init Ramdisk)"),
            ("vendor_boot", "vendor_boot (Vendor Ramdisk)"),
            ("dtbo", "dtbo (Device Tree)"),
            ("recovery", "recovery (Custom Recovery)"),
        ]
        for idx, (p_name, p_desc) in enumerate(part_items):
            var = tk.BooleanVar(value=True)
            self.partition_vars[p_name] = var
            cb = ctk.CTkCheckBox(
                chk_inner,
                text=p_desc,
                variable=var,
                checkbox_width=20,
                checkbox_height=20,
                corner_radius=6,
                fg_color=UI["blue"],
                hover_color=UI["blue_hover"],
                border_color=UI["border"],
                border_width=2,
                checkmark_color=UI["btn_text_on_yellow"],
                text_color=UI["text_primary"],
                font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=self._sync_checklist_labels,
            )
            cb.grid(row=idx // 2, column=idx % 2, sticky="w", padx=6, pady=5)

        # --- Panel 2: Kernel & Root Lab (Matching Screenshots 29, 35) ---
        self.kernel_panel = ctk.CTkFrame(self.config_card, fg_color="transparent")

        hdr3 = ctk.CTkFrame(self.kernel_panel, fg_color="transparent")
        hdr3.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(
            hdr3,
            text="1. SELECT KERNEL / ANYKERNEL3 (.zip)",
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        self.kernel_size_badge = ctk.CTkLabel(
            hdr3,
            text="  Size: --  ",
            fg_color=UI["amber_bg"],
            text_color=UI["blue"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
        )
        self.kernel_size_badge.pack(side="right")

        krn_input_bar = ctk.CTkFrame(
            self.kernel_panel,
            fg_color=UI["bg_recessed"],
            corner_radius=10,
            border_width=1,
            border_color=UI["border_focus"],
            height=44,
        )
        krn_input_bar.pack(fill="x", pady=(0, 10))
        krn_input_bar.pack_propagate(False)

        ctk.CTkButton(
            krn_input_bar,
            text=" Browse Custom Kernel (.zip)",
            image=self.load_icon("folder", 22, (5, 5, 7, 255)),
            compound="left",
            width=200,
            height=32,
            corner_radius=7,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=self._browse_kernel_file,
        ).pack(side="right", padx=6, pady=5)

        self.kernel_file_lbl = ctk.CTkLabel(
            krn_input_bar,
            text="Reboot device into Recovery Sideload Mode to unlock.",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["text_secondary"],
            anchor="w",
        )
        self.kernel_file_lbl.pack(side="left", fill="x", expand=True, padx=(14, 6))

        # 2. KERNEL EXECUTION CHECKLIST (From Screenshots 29 & 35)
        k_chk_card = ctk.CTkFrame(
            self.kernel_panel,
            fg_color=UI["bg_recessed"],
            corner_radius=12,
            border_width=1,
            border_color=UI["border"],
        )
        k_chk_card.pack(fill="x", pady=(0, 8))

        kc_in = ctk.CTkFrame(k_chk_card, fg_color="transparent")
        kc_in.pack(fill="x", padx=14, pady=8)

        ctk.CTkLabel(
            kc_in,
            text="2. KERNEL EXECUTION CHECKLIST",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(anchor="w", pady=(0, 4))

        ctk.CTkLabel(
            kc_in,
            text="○ Step 1: Enter Recovery ADB Sideload Mode\n○ Step 2: Sideload AnyKernel3 / KSU Package",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["text_secondary"],
            justify="left",
        ).pack(anchor="w")

        ctk.CTkLabel(
            kc_in,
            text="💡 Tip: You can select your Kernel .zip anytime, then use Power Menu -> Recovery to start sideloading.",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=UI["blue"],
            anchor="w",
        ).pack(anchor="w", pady=(4, 0))

        # 3. KERNEL & ROOT GUIDE (KSU / SukiSU) (From Screenshots 29 & 35)
        k_guide_card = ctk.CTkFrame(
            self.kernel_panel,
            fg_color=UI["bg_recessed"],
            corner_radius=12,
            border_width=1,
            border_color=UI["border"],
        )
        k_guide_card.pack(fill="x", pady=(0, 6))

        kg_in = ctk.CTkFrame(k_guide_card, fg_color="transparent")
        kg_in.pack(fill="x", padx=14, pady=8)

        ctk.CTkLabel(
            kg_in,
            text="⚡ KERNEL & ROOT GUIDE (KSU / SukiSU)",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            text_color=UI["blue"],
        ).pack(anchor="w", pady=(0, 3))

        kg_txt = (
            "• Why Custom Kernel: Unlocks kernel-based Root Access, CPU/GPU scheduling optimizations & lower touch latency.\n"
            "• Root Managers (KernelSU / SukiSU): If your kernel integrates KSU or SukiSU, simply install the KSU/SukiSU Manager APK after booting to grant root.\n"
            "• ⚠️ Compatibility Risk: Ensure the kernel matches your exact Android version & KMI (e.g., android14-6.1). Mismatched kernels may cause bootloops!"
        )
        ctk.CTkLabel(
            kg_in,
            text=kg_txt,
            font=ctk.CTkFont(family="Segoe UI", size=9),
            text_color=UI["text_secondary"],
            justify="left",
        ).pack(anchor="w")

        # Primary Action Button
        cta_wrap = ctk.CTkFrame(self.config_card, fg_color="transparent")
        cta_wrap.pack(fill="x", side="bottom", padx=22, pady=(0, 12))

        self.btn_start_flash = ctk.CTkButton(
            cta_wrap,
            text=MODE_CTA_LABELS["ROM"],
            height=44,
            corner_radius=10,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            command=self._on_click_primary_flash_btn,
        )
        self.btn_start_flash.pack(fill="x")

        # Bottom Card: 3. FASTBOOT WIPE & REPAIR TOOLS (Matching Screenshots 31 & 32 + Original Fastboot Card)
        self.fastboot_card = ctk.CTkFrame(
            self.center_work_wrap,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        self.fastboot_card.pack(fill="x")

        fb_inner = ctk.CTkFrame(self.fastboot_card, fg_color="transparent")
        fb_inner.pack(fill="x", padx=20, pady=10)

        fb_top = ctk.CTkFrame(fb_inner, fg_color="transparent")
        fb_top.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(
            fb_top,
            text="3. FASTBOOT WIPE & REPAIR TOOLS",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        ctk.CTkLabel(
            fb_top,
            text="  ⚠️ Requires Fastboot Mode  ",
            fg_color=UI["amber_bg"],
            text_color=UI["amber_fg"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
        ).pack(side="right")

        for b_txt, b_cmd in [
            ("WOF Wake", lambda: self.backend.wake_on_fastboot_or_adb(on_done=lambda ok, m: self.after(0, lambda: self.show_toast(m)))),
            ("Slot B", lambda: self.backend.set_active_slot("b", on_done=lambda ok, m: self.after(0, lambda: self.show_toast(m)))),
            ("Slot A", lambda: self.backend.set_active_slot("a", on_done=lambda ok, m: self.after(0, lambda: self.show_toast(m)))),
        ]:
            ctk.CTkButton(
                fb_top,
                text=b_txt,
                width=62,
                height=24,
                corner_radius=6,
                fg_color=UI["bg_pill"],
                hover_color=UI["blue"],
                text_color=UI["text_primary"],
                font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
                command=b_cmd,
            ).pack(side="right", padx=(0, 5))

        erase_row = ctk.CTkFrame(fb_inner, fg_color="transparent")
        erase_row.pack(fill="x", pady=(0, 6))
        erase_row.grid_columnconfigure((0, 1, 2), weight=1, uniform="er")

        trash_ic = self.load_icon("trash", 20)
        for col_i, (lbl_e, act_e) in enumerate([
            ("Erase FRP", "erase_frp"),
            ("Wipe Metadata", "erase_metadata"),
            ("Format Userdata", "erase_userdata"),
        ]):
            padx = (0, 5) if col_i == 0 else ((5, 0) if col_i == 2 else 5)
            ctk.CTkButton(
                erase_row,
                text=lbl_e,
                image=trash_ic,
                compound="left",
                height=32,
                corner_radius=8,
                fg_color=UI["bg_pill"],
                hover_color=UI["danger"],
                border_width=1,
                border_color=UI["border"],
                text_color=UI["text_primary"],
                font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda a=act_e, l=lbl_e: self._confirm_and_erase(a, l),
            ).grid(row=0, column=col_i, sticky="ew", padx=padx)

        reb_track = ctk.CTkFrame(
            fb_inner,
            fg_color=UI["bg_recessed"],
            corner_radius=10,
            border_width=1,
            border_color=UI["border"],
        )
        reb_track.pack(fill="x", pady=(0, 4))
        reb_track.grid_columnconfigure((0, 1, 2), weight=1, uniform="rb")

        for col_r, (r_lbl, r_target) in enumerate([
            ("Reboot Bootloader", "bootloader"),
            ("Reboot Recovery", "recovery"),
            ("Reboot System", "system"),
        ]):
            ctk.CTkButton(
                reb_track,
                text=r_lbl,
                height=26,
                corner_radius=7,
                fg_color="transparent",
                hover_color=UI["bg_pill"],
                text_color=UI["text_secondary"],
                font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda t=r_target: self.backend.reboot_device(t),
            ).grid(row=0, column=col_r, sticky="ew", padx=4, pady=2)

        # Crisp Static Caution Note (Zero Marquee Ghosting / Tearing!)
        self.fb_ticker_lbl = ctk.CTkLabel(
            fb_inner,
            text="⚠️ FRP: Clears Google FRP lock  •  Metadata: Resets encryption states  •  Userdata: Full factory reset",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color=UI["blue"],
            anchor="w",
        )
        self.fb_ticker_lbl.pack(fill="x", pady=(2, 0))

        # In-Window Panels for Logs, Drivers, and Mayank Droid Official Links
        self.logs_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        self._build_logs_panel(self.logs_card)

        self.drivers_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        self._build_in_window_drivers_panel(self.drivers_card)

        self.links_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        self._build_in_window_links_panel(self.links_card)

    # -------------------------------------------------------------------------
    # IN-WINDOW DRIVERS & OFFICIAL LINKS PANELS
    # -------------------------------------------------------------------------
    def _build_in_window_drivers_panel(self, parent):
        top = ctk.CTkFrame(parent, fg_color="transparent")
        top.pack(fill="x", padx=22, pady=(18, 10))
        ctk.CTkLabel(
            top,
            text="USB Drivers & ADB Environment",
            font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        ctk.CTkButton(
            top,
            text="← Back",
            width=80,
            height=30,
            corner_radius=8,
            fg_color=UI["bg_pill"],
            hover_color=UI["blue"],
            text_color=UI["text_primary"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=lambda: self.switch_mode(self.last_workflow_mode),
        ).pack(side="right")

        ctk.CTkButton(
            top,
            text="⬇ Auto-Download & Install ADB + Drivers",
            width=230,
            height=30,
            corner_radius=8,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=lambda: self.driver_mgr.auto_download_platform_tools_if_missing(
                force=True,
                progress_cb=self._on_backend_progress,
                on_complete=lambda st: self.after(0, lambda: (self.driver_mgr.install_google_usb_driver_pnputil(), self.show_toast("ADB, Fastboot & Google USB Drivers Installed!"))),
            ),
        ).pack(side="right", padx=(0, 8))

        banner = ctk.CTkFrame(parent, fg_color=UI["green_bg"], corner_radius=10)
        banner.pack(fill="x", padx=22, pady=(0, 14))
        ctk.CTkLabel(
            banner,
            text="✓ Everything is fine, you can check out. (ADB, Fastboot & System PATH Configured)",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            text_color=UI["green_fg"],
        ).pack(padx=14, pady=12)

        list_box = ctk.CTkFrame(parent, fg_color=UI["bg_recessed"], corner_radius=12, border_width=1, border_color=UI["border"])
        list_box.pack(fill="both", expand=True, padx=22, pady=(0, 20))

        for name_d, desc_d, url_d in [
            ("Google Android USB Driver", "Official ADB & Fastboot bootloader interface driver", OFFICIAL_LINKS["google_usb_driver"]),
            ("Xiaomi MiFlash USB Drivers", "Official Fastboot & EDL driver pack", OFFICIAL_LINKS["xiaomi_miflash_driver"]),
            ("Qualcomm HS-USB QDLoader 9008", "Snapdragon EDL & low-level flashing driver", OFFICIAL_LINKS["qualcomm_qdloader_driver"]),
            ("MediaTek USB VCOM Driver", "MTK Preloader & Brom USB flashing driver", OFFICIAL_LINKS["mediatek_usb_driver"]),
            ("Universal ADB Driver", "ClockworkMod universal Windows ADB interface", OFFICIAL_LINKS["universal_adb_driver"]),
        ]:
            row = ctk.CTkFrame(list_box, fg_color=UI["bg_card"], corner_radius=10, border_width=1, border_color=UI["border"])
            row.pack(fill="x", padx=14, pady=6)
            ctk.CTkButton(
                row,
                text="Download ↗",
                width=96,
                height=30,
                corner_radius=7,
                fg_color=UI["blue"],
                hover_color=UI["blue_hover"],
                text_color=UI["btn_text_on_yellow"],
                font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda u=url_d: webbrowser.open(u),
            ).pack(side="right", padx=12, pady=10)

            txt_c = ctk.CTkFrame(row, fg_color="transparent")
            txt_c.pack(side="left", fill="x", expand=True, padx=12, pady=8)
            ctk.CTkLabel(txt_c, text=name_d, font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color=UI["text_primary"]).pack(anchor="w")
            ctk.CTkLabel(txt_c, text=desc_d, font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color=UI["text_secondary"]).pack(anchor="w")

    def _build_in_window_links_panel(self, parent):
        top = ctk.CTkFrame(parent, fg_color="transparent")
        top.pack(fill="x", padx=22, pady=(18, 10))
        ctk.CTkLabel(
            top,
            text="Mayank Droid — Official Ecosystem & Services",
            font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        ctk.CTkButton(
            top,
            text="← Back",
            width=80,
            height=30,
            corner_radius=8,
            fg_color=UI["bg_pill"],
            hover_color=UI["blue"],
            text_color=UI["text_primary"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=lambda: self.switch_mode(self.last_workflow_mode),
        ).pack(side="right")

        grid_wrap = ctk.CTkFrame(parent, fg_color="transparent")
        grid_wrap.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        grid_wrap.grid_columnconfigure((0, 1), weight=1, uniform="lnk")

        links_data = [
            ("🌐 Mayank Droid Hub", "Android Tools & Custom ROM Portal", OFFICIAL_LINKS["mayank_droid_hub"]),
            ("🔓 Xiaomi / POCO Mi Unlock", "Instant Bootloader Unlock Assistance", OFFICIAL_LINKS["mi_unlock_service"]),
            ("🤖 Onyx Services", "SMM Panel & Social Media Services", OFFICIAL_LINKS["onyx_services"]),
            ("🎌 Otaku Hub Pro", "Anime Directory & Streaming Hub", OFFICIAL_LINKS["otaku_hub_pro"]),
            ("💼 Portfolio HBO", "Official Developer Portfolio", OFFICIAL_LINKS["portfolio_hbo"]),
            ("📩 Telegram: @RoranoaxZORO", "Direct Support & Bootloader Unlock DM", OFFICIAL_LINKS["telegram_zoro"]),
            ("📢 Telegram: @MayankDroid7", "Official Updates & Releases Channel", OFFICIAL_LINKS["telegram_mayank"]),
            ("▶️ YouTube: @mayankdroid", "Flashing Guides & ROM Reviews", OFFICIAL_LINKS["youtube_mayank"]),
        ]
        for idx, (title_l, sub_l, url_l) in enumerate(links_data):
            card = ctk.CTkFrame(
                grid_wrap,
                fg_color=UI["bg_recessed"],
                corner_radius=12,
                border_width=1,
                border_color=UI["border"],
            )
            card.grid(row=idx // 2, column=idx % 2, sticky="ew", padx=5, pady=5)

            ctk.CTkLabel(card, text=title_l, font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"), text_color=UI["text_primary"]).pack(
                anchor="w", padx=12, pady=(10, 2)
            )
            ctk.CTkLabel(card, text=sub_l, font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"), text_color=UI["text_secondary"]).pack(
                anchor="w", padx=12, pady=(0, 8)
            )
            ctk.CTkButton(
                card,
                text="Open Link ↗",
                height=26,
                corner_radius=6,
                fg_color=UI["blue"],
                hover_color=UI["blue_hover"],
                text_color=UI["btn_text_on_yellow"],
                font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
                command=lambda u=url_l: webbrowser.open(u),
            ).pack(fill="x", padx=12, pady=(0, 10))

    # -------------------------------------------------------------------------
    # ZONE 3: RIGHT DEVICE MOCKUP & PROGRESS DOCK
    # -------------------------------------------------------------------------
    def _build_zone3_right_dock(self, parent):
        dev_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        dev_card.pack(fill="x", pady=(0, 12))

        d_inner = ctk.CTkFrame(dev_card, fg_color="transparent")
        d_inner.pack(fill="x", padx=18, pady=12)

        d_hdr = ctk.CTkFrame(d_inner, fg_color="transparent")
        d_hdr.pack(fill="x")
        ctk.CTkLabel(
            d_hdr,
            text="DEVICE STATUS",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")

        self.btn_refresh_dev = ctk.CTkButton(
            d_hdr,
            text=" Refresh",
            image=self.load_icon("refresh", 20, (5, 5, 7, 255)),
            compound="left",
            width=90,
            height=26,
            corner_radius=6,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            command=self._on_click_refresh_device,
        )
        self.btn_refresh_dev.pack(side="right")

        self.phone_img_idle = self._load_asset_image("ios_phone_idle.png", 115, 170)
        self.phone_img_conn = self._load_asset_image("ios_phone_connected.png", 115, 170)

        self.phone_mockup_lbl = ctk.CTkLabel(d_inner, text="", image=self.phone_img_idle)
        self.phone_mockup_lbl.pack(pady=(6, 6))

        tags_box = ctk.CTkFrame(
            d_inner,
            fg_color=UI["bg_recessed"],
            corner_radius=10,
            border_width=1,
            border_color=UI["border"],
        )
        tags_box.pack(fill="x")

        t_pad = ctk.CTkFrame(tags_box, fg_color="transparent")
        t_pad.pack(fill="x", padx=10, pady=8)

        self.device_state_pill = ctk.CTkLabel(
            t_pad,
            text="  ● Searching for USB Device...  ",
            fg_color=UI["amber_bg"],
            text_color=UI["amber_fg"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
        )
        self.device_state_pill.pack(fill="x", pady=(0, 4))

        self.battery_pill = ctk.CTkLabel(
            t_pad,
            text="  Battery: N/A   •   Slot: --  ",
            fg_color=UI["bg_pill"],
            text_color=UI["text_secondary"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
        )
        self.battery_pill.pack(fill="x", pady=(0, 4))

        self.serial_pill = ctk.CTkLabel(
            t_pad,
            text="  Model: Disconnected   •   ID: --  ",
            fg_color=UI["bg_pill"],
            text_color=UI["blue"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
        )
        self.serial_pill.pack(fill="x")

        # Interactive USB Debugging Authorization Action Banner
        self.unauth_prompt_btn = ctk.CTkButton(
            t_pad,
            text="📱 Tap 'Allow' on Phone (Retry)",
            height=26,
            corner_radius=6,
            fg_color=UI["amber_bg"],
            hover_color=UI["blue"],
            text_color=UI["amber_fg"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=self._on_click_refresh_device,
        )

        prog_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_card"],
            corner_radius=16,
            border_width=1,
            border_color=UI["border"],
        )
        prog_card.pack(fill="both", expand=True)

        p_inner = ctk.CTkFrame(prog_card, fg_color="transparent")
        p_inner.pack(fill="both", expand=True, padx=18, pady=12)

        self.reactor_title_lbl = ctk.CTkLabel(
            p_inner,
            text="AUTOMATED FLASH REACTOR",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            text_color=UI["text_primary"],
        )
        self.reactor_title_lbl.pack(anchor="w", pady=(0, 6))

        # Vertical reactor layout keeps every workflow label visible in narrow docks.
        ring_holder = ctk.CTkFrame(p_inner, fg_color="transparent")
        ring_holder.pack(fill="x", pady=(2, 2))

        self.ring_img_lbl = ctk.CTkLabel(
            ring_holder,
            text="0%",
            font=ctk.CTkFont(family="Segoe UI", size=17, weight="bold"),
            compound="center",
            text_color=UI["blue"],
        )
        self.ring_img_lbl.pack(anchor="center", pady=(0, 2))

        self.progress_status_lbl = ctk.CTkLabel(
            p_inner,
            text="Standby",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["text_secondary"],
            justify="center",
            wraplength=260,
        )
        self.progress_status_lbl.pack(fill="x", pady=(0, 8))

        steps_col = ctk.CTkFrame(p_inner, fg_color=UI["bg_recessed"], corner_radius=10)
        steps_col.pack(fill="x", expand=True, pady=(0, 2))

        self.step_labels: List[ctk.CTkLabel] = []
        for s_txt in [
            "Gathering Images",
            "Flash Fastboot",
            "Wait Sideload",
            "Flash Sideload",
        ]:
            lbl = ctk.CTkLabel(
                steps_col,
                text=f"○ {s_txt}",
                font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
                text_color=UI["text_secondary"],
                anchor="w",
            )
            lbl.pack(fill="x", padx=12, pady=4)
            self.step_labels.append(lbl)


    # -------------------------------------------------------------------------
    # LIVE TERMINAL LOGS PANEL
    # -------------------------------------------------------------------------
    def _build_logs_panel(self, parent):
        top = ctk.CTkFrame(parent, fg_color="transparent")
        top.pack(fill="x", padx=20, pady=(14, 8))

        lbl_f = ctk.CTkFrame(top, fg_color="transparent")
        lbl_f.pack(side="left")
        ctk.CTkLabel(
            lbl_f,
            text="💻 REAL-TIME DIAGNOSTIC TELEMETRY STREAM",
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            text_color=UI["text_primary"],
        ).pack(side="left")
        ctk.CTkLabel(
            lbl_f,
            text="  ● Live Stream  ",
            fg_color=UI["amber_bg"],
            text_color=UI["blue"],
            corner_radius=6,
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
        ).pack(side="left", padx=8)

        # Right Action Buttons
        ctk.CTkButton(
            top,
            text=" Clear Logs",
            image=self.load_icon("trash", 20),
            compound="left",
            width=98,
            height=28,
            corner_radius=7,
            fg_color=UI["bg_pill"],
            hover_color=UI["danger"],
            text_color=UI["text_primary"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=self._clear_console,
        ).pack(side="right", padx=(4, 0))

        ctk.CTkButton(
            top,
            text=" Copy Logs",
            image=self.load_icon("copy", 20),
            compound="left",
            width=105,
            height=28,
            corner_radius=7,
            fg_color=UI["blue"],
            hover_color=UI["blue_hover"],
            text_color=UI["btn_text_on_yellow"],
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            command=self._copy_terminal_logs,
        ).pack(side="right", padx=(4, 0))

        # Strictly Read-Only CTkTextbox
        self.console_box = ctk.CTkTextbox(
            parent,
            fg_color="#050608",
            text_color="#E2E8F0",
            border_width=1,
            border_color=UI["border"],
            font=ctk.CTkFont(family="Consolas", size=11),
            corner_radius=10,
            state="disabled",
        )
        self.console_box.pack(fill="both", expand=True, padx=20, pady=(2, 10))

        # Setup Rich Color Tags on underlying Tk Text Widget
        try:
            tb = self.console_box._textbox
            tb.configure(spacing1=1, spacing3=2)
            tb.tag_config("ts", foreground="#94A3B8")
            tb.tag_config("success", foreground="#22C55E")
            tb.tag_config("info", foreground="#F8FAFC")
            tb.tag_config("warn", foreground="#FACC15")
            tb.tag_config("error", foreground="#EF4444")
            tb.tag_config("turbo", foreground="#FDE047")
            tb.tag_config("device", foreground="#38BDF8")
            tb.tag_config("ram", foreground="#A855F7")
            tb.tag_config("cmd", foreground="#FACC15")
        except Exception:
            pass

        # SAFETY PROTOCOL & SIDELOAD NOTES (From Screenshot 34)
        safety_card = ctk.CTkFrame(
            parent,
            fg_color=UI["bg_recessed"],
            corner_radius=10,
            border_width=1,
            border_color=UI["border"],
        )
        safety_card.pack(fill="x", padx=20, pady=(0, 14))

        ctk.CTkLabel(
            safety_card,
            text="⚠️ SAFETY PROTOCOL & SIDELOAD NOTES",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color=UI["blue"],
        ).pack(anchor="w", padx=12, pady=(6, 2))

        s_notes = (
            "• AOSP 47% Rule: During ADB Sideload, progress naturally finishes around 47% which equals 100% full ROM transfer.\n"
            "• Transfer Lock: USB polling and Windows Sleep are automatically locked during flashing to prevent connection drops on 5GB+ ROMs."
        )
        ctk.CTkLabel(
            safety_card,
            text=s_notes,
            font=ctk.CTkFont(family="Segoe UI", size=9),
            text_color=UI["text_secondary"],
            justify="left",
        ).pack(anchor="w", padx=12, pady=(0, 6))

    def _clear_console(self):
        try:
            self.console_box.configure(state="normal")
            self.console_box.delete("1.0", "end")
            self.console_box.configure(state="disabled")
        except Exception:
            pass

    def _copy_terminal_logs(self):
        txt = self.console_box.get("1.0", "end-1c")
        if txt.strip():
            self.clipboard_clear()
            self.clipboard_append(txt)
            self.append_log("📋 Console logs copied to clipboard!")
            self.show_toast("Console logs copied to clipboard!")

    def _build_toast_overlay(self):
        self.toast_lbl = ctk.CTkLabel(
            self,
            text="Everything is fine, you can check out.",
            fg_color=UI["amber_bg"],
            text_color=UI["blue"],
            corner_radius=8,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            padx=16,
            pady=6,
        )

    def show_toast(self, msg: str, duration_ms: int = 3200):
        self.toast_lbl.configure(text=f"⚡  {msg}")
        self.toast_lbl.place(relx=0.5, rely=0.95, anchor="center")
        self.after(duration_ms, lambda: self.toast_lbl.place_forget())

    # =========================================================================
    # MODE SWITCHING & CHECKLIST SYNC
    # =========================================================================
    def switch_mode(self, mode_key: str):
        self.active_mode = mode_key
        if mode_key in ("ROM", "KERNEL"):
            self.last_workflow_mode = mode_key

        for k, btn in self.nav_btns.items():
            is_act = k == mode_key
            btn.configure(
                fg_color=UI["blue"] if is_act else "transparent",
                hover_color=UI["blue_hover"] if is_act else UI["bg_pill"],
                text_color=UI["btn_text_on_yellow"] if is_act else UI["text_secondary"],
                image=self.load_icon(
                    "rom" if k == "ROM" else ("kernel" if k == "KERNEL" else "logs"),
                    24,
                    (5, 5, 7, 255) if is_act else (250, 204, 21, 255),
                ),
            )

        self.center_work_wrap.pack_forget()
        self.logs_card.pack_forget()
        self.drivers_card.pack_forget()
        self.links_card.pack_forget()

        if mode_key == "LOGS":
            self.logs_card.pack(fill="both", expand=True)
            return
        if mode_key == "DRIVERS":
            self.driver_mgr.auto_download_platform_tools_if_missing()
            self.drivers_card.pack(fill="both", expand=True)
            self.show_toast("Everything is fine, you can check out.")
            return
        if mode_key == "LINKS":
            self.links_card.pack(fill="both", expand=True)
            return

        self.center_work_wrap.pack(fill="both", expand=True)
        self.rom_panel.pack_forget()
        self.kernel_panel.pack_forget()

        if mode_key == "ROM":
            self.rom_panel.pack(fill="both", expand=True, padx=22, pady=14)
            if hasattr(self, "reactor_title_lbl"):
                self.reactor_title_lbl.configure(text="AUTOMATED FLASH REACTOR")
        elif mode_key == "KERNEL":
            self.kernel_panel.pack(fill="both", expand=True, padx=22, pady=14)
            if hasattr(self, "reactor_title_lbl"):
                self.reactor_title_lbl.configure(text="KERNEL SIDELOAD REACTOR")

        if self.backend.is_flashing:
            self.btn_start_flash.configure(
                text="■   STOP FLASHING (ABORT)",
                fg_color=UI["danger"],
                hover_color="#DC2626",
                text_color="#FFFFFF",
            )
        else:
            self.btn_start_flash.configure(
                text=MODE_CTA_LABELS.get(mode_key, "▶   START AUTOMATED FLASH"),
                fg_color=UI["blue"],
                hover_color=UI["blue_hover"],
                text_color=UI["btn_text_on_yellow"],
            )

        self._sync_checklist_labels()

    def _sync_checklist_labels(self):
        if self.backend.is_flashing:
            return
        if self.active_mode == "ROM":
            steps = ["Gathering Images", "Flash Fastboot", "Wait Sideload", "Flash Sideload"]
        else:
            steps = ["Verify Kernel Zip", "Enter Recovery Sideload", "Sideload AnyKernel3/KSU", "Complete"]

        for idx, s_txt in enumerate(steps):
            if idx < len(self.step_labels):
                self.step_labels[idx].configure(text=f"○ {s_txt}", text_color=UI["text_secondary"])

    def _preset_all_partitions(self):
        for v in self.partition_vars.values():
            v.set(True)
        self._sync_checklist_labels()
        self.show_toast("All Recommended Fastboot Partitions Selected!")

    def _preset_skip_partitions(self):
        for v in self.partition_vars.values():
            v.set(False)
        self._sync_checklist_labels()
        self.show_toast("Fastboot Stage Skipped — Will proceed directly to ADB Sideload.")

    def _open_power_menu_dialog(self):
        dlg = ctk.CTkToplevel(self)
        dlg.title("Power & Reboot Menu")
        dlg.geometry("360x340")
        dlg.configure(fg_color=UI["bg_root"])
        dlg.transient(self)
        dlg.grab_set()

        ctk.CTkLabel(
            dlg,
            text="⚡ POWER & REBOOT MENU",
            font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"),
            text_color=UI["blue"],
        ).pack(pady=(16, 10))

        for lbl, target in [
            ("Reboot to System (OS)", "system"),
            ("Reboot to Bootloader (Fastboot)", "bootloader"),
            ("Reboot to Recovery Mode", "recovery"),
            ("Reboot to ADB Sideload Mode", "sideload"),
            ("Reboot to Fastbootd (Userspace)", "fastboot"),
            ("Reboot to EDL Mode (9008)", "edl"),
        ]:
            ctk.CTkButton(
                dlg,
                text=lbl,
                height=34,
                corner_radius=8,
                fg_color=UI["bg_card"],
                hover_color=UI["blue"],
                border_width=1,
                border_color=UI["border"],
                text_color=UI["text_primary"],
                font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
                command=lambda t=target: [self.backend.reboot_device(t), dlg.destroy(), self.show_toast(f"Rebooting to {t}...")],
            ).pack(fill="x", padx=22, pady=3)

    # =========================================================================
    # 1-CLICK IN-PLACE WINMEMORYCLEANER EXECUTION
    # =========================================================================
    def _start_background_startup_tasks(self):
        def _bg_ram():
            try:
                res = self.ram_cleaner.boost_system_memory(
                    startup_mode=True, kill_bloat=False, areas=MemoryAreas(0)
                )
                avail_mb = res["after"]["avail_mb"]
                label = f"  RAM: {avail_mb / 1024.0:.1f}GB Available" if res["after"]["total_mb"] > 0 else "  RAM: Unavailable"
                self.after(0, lambda: self.ram_btn.configure(text=label))
            except Exception as exc:
                self.after(0, lambda err=str(exc): self.ram_btn.configure(text="  RAM: Unavailable"))
                self.append_log(f"[RAM] Memory telemetry unavailable: {exc}")

        threading.Thread(target=_bg_ram, daemon=True).start()
        pass

    def _on_click_ram_boost(self):
        if self._is_ram_cleaning:
            return
        self._is_ram_cleaning = True
        self.ram_btn.configure(text="  Cleaning RAM...", fg_color=UI["amber_bg"])

        def _progress(step_idx: int, area_name: str):
            short_a = area_name[:14]
            self.after(0, lambda: self.ram_btn.configure(text=f"  [{step_idx}/7] {short_a}..."))

        def _run():
            try:
                res = self.ram_cleaner.boost_system_memory(
                    startup_mode=False,
                    areas=MemoryAreas(0),
                    kill_bloat=False,
                    progress_callback=_progress,
                )
                avail_mb = res["after"]["avail_mb"]
                avail_gb = avail_mb / 1024.0
                freed_mb = res["freed_mb"]
                self.after(
                    0,
                    lambda: self.ram_btn.configure(
                        text=(f"  RAM: {avail_gb:.1f}GB Available" if res["after"]["total_mb"] > 0 else "  RAM: Unavailable"),
                        fg_color=UI["bg_pill"],
                    ),
                )
                self.after(
                    0,
                    lambda: self.show_toast(
                        f"Memory refreshed. Available RAM: {avail_gb:.1f} GB (measured change: {freed_mb:.0f} MB)."
                    ),
                )
            except Exception as exc:
                self.after(0, lambda err=str(exc): self.show_toast(f"RAM status failed: {err[:100]}"))
            finally:
                self._is_ram_cleaning = False

        threading.Thread(target=_run, daemon=True).start()

    def _on_toggle_turbo(self):
        on = self.turbo_var.get()
        self.turbo_engine.set_turbo_mode(on)
        self.show_toast("Turbo Mode ON" if on else "Turbo Mode OFF")

    # =========================================================================
    # FILE BROWSERS & FLASHING WITH DEVICE CONNECTION GUARD
    # =========================================================================
    @staticmethod
    def _format_display_filename(path: str, max_chars: int = 44) -> str:
        name = os.path.basename(path)
        if len(name) <= max_chars:
            return name
        return name[: max_chars - 12] + "..." + name[-9:]

    def _browse_rom_file(self):
        p = filedialog.askopenfilename(
            title="Select Custom ROM (.zip) or Partition (.img)",
            filetypes=[("ROM & Image Files", "*.zip *.img *.bin"), ("All Files", "*.*")],
        )
        if p:
            self.selected_rom_path = p
            sz_gb = os.path.getsize(p) / (1024 ** 3)
            fname = os.path.basename(p)
            self.rom_size_badge.configure(text=f"  Size: {sz_gb:.2f} GB  ")
            self.rom_file_lbl.configure(
                text=f"{self._format_display_filename(p, 38)} — Ready to Flash!",
                text_color=UI["green_fg"],
            )
            self.append_log(f"📦 Loaded ROM Package: {fname} ({sz_gb:.2f} GB)")
            # Defer partition extraction until the user starts flashing.
            # This avoids writing several GB of images to disk just by selecting a ROM.
            self.append_log("[STORAGE] ROM selected. Partition images will be extracted only when flashing starts.")

    def _browse_kernel_file(self):
        p = filedialog.askopenfilename(
            title="Select Kernel (.zip) or Recovery/Boot (.img)",
            filetypes=[("Kernel & Recovery", "*.zip *.img"), ("All Files", "*.*")],
        )
        if p:
            self.selected_kernel_path = p
            sz_mb = os.path.getsize(p) / (1024 ** 2)
            fname = os.path.basename(p)
            self.kernel_size_badge.configure(text=f"  Size: {sz_mb:.1f} MB  ")
            if "twrp" in fname.lower() or "orangefox" in fname.lower() or "ofox" in fname.lower() or "recovery" in fname.lower():
                self.kernel_part_var.set("recovery")
            self.kernel_file_lbl.configure(
                text=f"{self._format_display_filename(p, 38)} — Ready to Flash!",
                text_color=UI["green_fg"],
            )
            self.append_log(f"📦 Loaded Kernel Package: {fname} ({sz_mb:.1f} MB)")

    def _confirm_and_erase(self, action_key: str, label: str):
        if self.backend.is_flashing:
            return
        dev_info = self.backend.poll_device_state(force=True)
        if dev_info.get("state") == DeviceState.DISCONNECTED:
            self.show_toast("Connect a device in Fastboot mode first!")
            messagebox.showwarning("No Device Detected", "Please connect your device in Fastboot mode before running erase commands.")
            return
        if messagebox.askyesno("Confirm Action", f"Execute '{label}' on connected Fastboot device?"):
            self.backend.execute_fastboot_utility(
                action_key,
                on_done=lambda ok, msg: self.after(0, lambda: self.show_toast(msg)),
            )

    def _on_click_primary_flash_btn(self):
        # 1. If currently flashing, clicking the red button asks confirmation before Safe Abort!
        if self.backend.is_flashing:
            if not messagebox.askyesno("Stop Flashing", "Are you sure you want to stop the current flashing process?"):
                return
            ok, msg = self.backend.request_abort()
            if not ok:
                messagebox.showwarning("Locked", msg)
            else:
                self._set_flashing_button_state(False)
                self._update_ring_image(0, "Aborted")
                self.show_toast(msg)
            return

        # 2. Check if a file is selected first
        if self.active_mode == "ROM" and not self.selected_rom_path:
            messagebox.showwarning("Select File", "Please click 'Browse & Load ROM (.zip)' first.")
            return
        if self.active_mode == "KERNEL" and not self.selected_kernel_path:
            messagebox.showwarning("Select File", "Please select a Custom Kernel (.zip) or Recovery (.img) first.")
            return

        # 3. Verify a device is actually connected before starting!
        dev_info = self.backend.poll_device_state(force=True)
        self._update_device_ui(dev_info)
        dev_st = dev_info.get("state", DeviceState.DISCONNECTED)
        if dev_st == DeviceState.DISCONNECTED:
            self.show_toast("No device connected! Connect phone via USB first.")
            messagebox.showwarning(
                "No Device Connected",
                "No Android device detected on USB!\n\nPlease connect your phone in Fastboot, ADB, or Recovery Sideload mode and try again.",
            )
            return
        if dev_st == DeviceState.UNAUTHORIZED:
            self.show_toast("⚠️ Action Required: Allow USB Debugging on phone screen!")
            messagebox.showwarning(
                "Allow USB Debugging",
                "Device detected, but USB Debugging permission is pending!\n\nPlease unlock your phone and tap 'Allow' or 'Always allow from this computer'.",
            )
            return

        # 4. Run quick background RAM boost if Turbo Mode is enabled
        if self.turbo_var.get():
            threading.Thread(
                target=lambda: self.ram_cleaner.boost_system_memory(startup_mode=True), daemon=True
            ).start()

        # 5. Engage Red STOP FLASHING button state and start selected workflow
        self._set_flashing_button_state(True)

        if self.active_mode == "ROM":
            parts = [p for p, v in self.partition_vars.items() if v.get()]
            self.backend.start_aosp_rom_flash(
                rom_path=self.selected_rom_path,
                selected_partitions=parts,
                on_finish=lambda ok, msg: self.after(0, lambda: self._on_flash_done(ok, msg)),
            )
        elif self.active_mode == "KERNEL":
            self.backend.start_kernel_or_recovery_flash(
                file_path=self.selected_kernel_path,
                target_partition=self.kernel_part_var.get(),
                action_mode="auto",
                on_finish=lambda ok, msg: self.after(0, lambda: self._on_flash_done(ok, msg)),
            )

    def _set_flashing_button_state(self, active: bool):
        if active:
            self.btn_start_flash.configure(
                text="■   STOP FLASHING (ABORT)",
                fg_color=UI["danger"],
                hover_color="#DC2626",
                text_color="#FFFFFF",
                state="normal",
            )
        else:
            default_lbl = MODE_CTA_LABELS.get(self.active_mode, "▶   START AUTOMATED FLASH")
            self.btn_start_flash.configure(
                text=default_lbl,
                fg_color=UI["blue"],
                hover_color=UI["blue_hover"],
                text_color=UI["btn_text_on_yellow"],
                state="normal",
            )

    def _on_flash_done(self, ok: bool, msg: str):
        self._set_flashing_button_state(False)
        if ok:
            self.target_progress = 100.0
            self.progress_subtitle = "ROM Installed!"
            self._update_ring_image(100, "ROM Installed!")
            self.show_toast("ROM Installed Successfully!")
            messagebox.showinfo("Success", msg)
        else:
            self.target_progress = 0.0
            self.progress_subtitle = "Standby"
            self._update_ring_image(0, "Standby")
            if msg.strip().lower() not in ("cancelled.", "aborted by user."):
                messagebox.showerror("Error", msg)

    def _update_ring_image(self, pct: float, sub: str):
        ring_img = self._render_smooth_progress_ring(pct, size=128)
        if pct >= 99.5:
            short_state = "ROM Installed!" if self.active_mode == "ROM" else "Installed!"
        elif pct > 0.5:
            short_state = sub[:14] if sub else "Flashing..."
        else:
            short_state = "Standby"
        self.ring_img_lbl.configure(
            image=ring_img,
            text=f"{int(round(pct))}%",
            text_color=UI["green_fg"] if pct >= 99.5 else UI["blue"],
        )
        if hasattr(self, "progress_status_lbl"):
            full_status = "ROM Installed Successfully" if pct >= 99.5 else (sub or short_state)
            self.progress_status_lbl.configure(
                text=full_status,
                text_color=UI["green_fg"] if pct >= 99.5 else UI["text_secondary"],
            )

    def _on_backend_progress(self, pct: float, subtitle: str):
        def _upd():
            self.target_progress = pct
            self.progress_subtitle = subtitle
            if self.backend.is_sideload_locked:
                self.btn_start_flash.configure(state="disabled", text="🔒   SIDELOAD LOCKED (DO NOT UNPLUG)")
            elif self.backend.is_flashing:
                self.btn_start_flash.configure(
                    state="normal",
                    text="■   STOP FLASHING (ABORT)",
                    fg_color=UI["danger"],
                    text_color="#FFFFFF",
                )
        self.after(0, _upd)

    def _on_backend_step(self, idx: int, status: str, label: str):
        def _upd():
            if 0 <= idx < len(self.step_labels):
                base_txt = label if label else self.step_labels[idx].cget("text")[2:]
                if len(base_txt) > 25:
                    base_txt = base_txt[:23] + ".."
                if status == "active":
                    self.step_labels[idx].configure(text=f"◉ {base_txt}", text_color=UI["blue"])
                elif status == "done":
                    self.step_labels[idx].configure(text=f"✔ {base_txt}", text_color=UI["green_fg"])
                elif status == "error":
                    self.step_labels[idx].configure(text=f"✖ {base_txt}", text_color=UI["danger"])
        self.after(0, _upd)

    def append_log(self, text: str):
        def _write():
            if not hasattr(self, "console_box"):
                return
            try:
                import datetime
                import re
                # Strip duplicate leading timestamp if backend already added [HH:MM:SS]
                clean_txt = re.sub(r"^\[\d{2}:\d{2}:\d{2}\]\s*(?:»\s*)?", "", text)
                now_str = datetime.datetime.now().strftime("[%H:%M:%S] » ")
                self.console_box.configure(state="normal")
                tb = self.console_box._textbox

                tag = "info"
                t_lower = clean_txt.lower()
                if clean_txt.startswith("[WMC-RAM]") or clean_txt.startswith("[RAM]"):
                    tag = "ram"
                elif "serving:" in t_lower or "total xfer:" in t_lower or "flashing" in t_lower:
                    tag = "cmd"
                elif "[connected]" in t_lower or "✅" in clean_txt or "✔" in clean_txt or "completed successfully" in t_lower:
                    tag = "success"
                elif "❌" in clean_txt or "error" in t_lower or "fail" in t_lower or "disconnected" in t_lower:
                    tag = "error"
                elif "⚠️" in clean_txt or "action required" in t_lower or "===" in clean_txt:
                    tag = "warn"

                tb.insert("end", now_str, "ts")
                tb.insert("end", clean_txt + "\n", tag)
                self.console_box.see("end")
                self.console_box.configure(state="disabled")
            except Exception:
                pass
        try:
            self.after(0, _write)
        except Exception:
            pass

    def _poll_device_loop(self):
        if not self.turbo_engine.active_transfer_lock and not getattr(self, "_is_polling_dev", False):
            self._is_polling_dev = True

            def _bg_poll():
                try:
                    info = self.backend.poll_device_state(force=False)
                    self.after(0, lambda: self._update_device_ui(info))
                finally:
                    self._is_polling_dev = False

            threading.Thread(target=_bg_poll, daemon=True).start()
        self.after(350, self._poll_device_loop)

    def _on_click_refresh_device(self):
        if getattr(self, "_is_refreshing_dev", False):
            return
        self._is_refreshing_dev = True

        buttons = [
            getattr(self, "btn_refresh_dev", None),
            getattr(self, "btn_scan_usb", None),
        ]
        for button in buttons:
            if button is not None:
                button.configure(state="disabled", text="Scanning...")

        self.device_state_pill.configure(
            text="  ● Scanning ADB / Fastboot / Recovery...  ",
            fg_color=UI["amber_bg"],
            text_color=UI["amber_fg"],
        )

        def _do_refresh():
            try:
                # Keep ADB/Fastboot transports alive; never taskkill them during a scan.
                adb_bin = self.driver_mgr.resolve_binary("adb")
                if os.path.isfile(adb_bin):
                    self.backend._run_short_cmd([adb_bin, "start-server"], timeout=2.5)
                info = self.backend.poll_device_state(force=True)
                self.after(0, lambda data=info: self._update_device_ui(data))
                st = info.get("state", DeviceState.DISCONNECTED)
                if st == DeviceState.UNAUTHORIZED:
                    msg = "Device detected. Unlock phone and approve USB debugging."
                elif st != DeviceState.DISCONNECTED:
                    msg = f"Detected: {info.get('model', 'Android device')} · {st}"
                else:
                    msg = "No ADB/Fastboot device found. Check cable, USB mode and driver."
                self.after(0, lambda m=msg: self.show_toast(m))
            except Exception as exc:
                error_text = str(exc)
                self.after(0, lambda e=error_text: self.show_toast(f"USB scan error: {e[:100]}"))
            finally:
                self._is_refreshing_dev = False
                def _restore():
                    for button, label in (
                        (getattr(self, "btn_refresh_dev", None), " Refresh"),
                        (getattr(self, "btn_scan_usb", None), "  Scan / Refresh USB"),
                    ):
                        if button is not None:
                            button.configure(text=label, state="normal")
                try:
                    self.after(0, _restore)
                except Exception:
                    pass

        threading.Thread(target=_do_refresh, name="usb-device-refresh", daemon=True).start()

    def _update_device_ui(self, info: Dict[str, str]):
        st = info.get("state", DeviceState.DISCONNECTED)
        if st == DeviceState.DISCONNECTED:
            if hasattr(self, "unauth_prompt_btn"):
                self.unauth_prompt_btn.pack_forget()
            self.device_state_pill.configure(
                text="  ● Searching for USB Device...  ",
                fg_color=UI["amber_bg"],
                text_color=UI["amber_fg"],
            )
            self.battery_pill.configure(text="  Battery: N/A   •   Slot: --  ")
            self.serial_pill.configure(text="  Model: Disconnected   •   ID: --  ")
            self.phone_mockup_lbl.configure(image=self.phone_img_idle)
            if not self.backend.is_flashing and hasattr(self, "guidance_lbl"):
                self.guidance_lbl.configure(
                    text="💡 NEXT STEP: Connect your phone via USB cable (Enable USB Debugging or boot into Fastboot/Recovery).",
                    text_color=UI["blue"],
                )
        elif st == DeviceState.UNAUTHORIZED:
            self.device_state_pill.configure(
                text="  ⚠️ Unauthorized: Allow on Phone Screen!  ",
                fg_color=UI["amber_bg"],
                text_color=UI["amber_fg"],
            )
            self.battery_pill.configure(text=f"  Serial: {info.get('serial', '-')} • Tap 'Always Allow'  ")
            self.phone_mockup_lbl.configure(image=self.phone_img_conn)
            if hasattr(self, "unauth_prompt_btn"):
                self.unauth_prompt_btn.pack(fill="x", pady=(5, 0))
        else:
            if hasattr(self, "unauth_prompt_btn"):
                self.unauth_prompt_btn.pack_forget()
            model = info.get("model", "Device")
            code = info.get("codename", "-")
            serial = info.get("serial", "--")
            dev_tag = f"{model} ({code})" if (code not in ("-", "") and code.lower() not in model.lower()) else model
            self.device_state_pill.configure(
                text=f"  ● {st.upper()} CONNECTED  ",
                fg_color=UI["green_bg"],
                text_color=UI["green_fg"],
            )
            bat = info.get("battery", "N/A")
            slot = info.get("slot", "--")
            self.battery_pill.configure(text=f"  Battery: {bat}   •   Slot: {slot}  ")
            self.serial_pill.configure(text=f"  Model: {dev_tag[:14]}   •   ID: {serial[:10]}  ")
            self.phone_mockup_lbl.configure(image=self.phone_img_conn)
            if not self.backend.is_flashing and hasattr(self, "guidance_lbl"):
                if not self.selected_rom_path:
                    self.guidance_lbl.configure(
                        text="💡 NEXT STEP: Select your Custom ROM (.zip) package and click 'START AUTOMATED FLASH'!",
                        text_color=UI["blue"],
                    )
                else:
                    self.guidance_lbl.configure(
                        text="🚀 READY TO FLASH: Click 'START AUTOMATED FLASH' to begin!",
                        text_color=UI["green_fg"],
                    )

    def _on_close_request(self):
        if self.backend.is_flashing:
            messagebox.showwarning(
                "Active Flash Protection",
                "Flashing is currently active. Closing the window now is blocked to prevent bricking your device.",
            )
            return
        self.backend.cleanup_on_exit()
        try:
            self.turbo_engine.set_turbo_mode(False)
        except Exception:
            pass
        self.destroy()


def run_app():
    try:
        configure_windows_app_id()
        app = ROMFlasherProApp()
        app.mainloop()
    except Exception as e:
        import traceback
        print("\n" + "=" * 70)
        print("  [FATAL ERROR IN AOSP FLASHER V7]")
        print("=" * 70)
        traceback.print_exc()
        print("=" * 70)
        try:
            input("\nPress Enter to exit...")
        except Exception:
            pass
        sys.exit(1)


if __name__ == "__main__":
    run_app()
