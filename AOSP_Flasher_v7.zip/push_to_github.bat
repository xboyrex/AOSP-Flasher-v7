@echo off
chcp 65001 >nul 2>&1
title AOSP Flasher v7 - GitHub Repository Pusher (By Mayank Droid)
cd /d "%~dp0"

echo ======================================================================
echo   ⚡ AOSP FLASHER v7 - AUTOMATED GITHUB REPOSITORY PUSHER (WINDOWS)
echo   Developed by Mayank Droid (@MayankDroid7)
echo ======================================================================
echo.

where git >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Git is not installed! Please install Git from https://git-scm.com/
    pause
    exit /b 1
)

set /p REPO_URL="Enter GitHub Repository URL (e.g. https://github.com/username/AOSP-Flasher-v7.git): "
if "%REPO_URL%"=="" (
    echo [ERROR] Repository URL cannot be empty!
    pause
    exit /b 1
)

if not exist ".git" (
    git init
)

git branch -M main
git add -A
git commit -m "Release: AOSP Flasher v7 - AMOLED Cyber Yellow Edition" >nul 2>&1

git remote remove origin >nul 2>&1
git remote add origin "%REPO_URL%"

echo [*] Pushing to GitHub...
git push -u origin main --force

echo.
echo ======================================================================
echo   ✅ SUCCESSFULLY PUSHED AOSP FLASHER v7 TO GITHUB!
echo ======================================================================
pause
