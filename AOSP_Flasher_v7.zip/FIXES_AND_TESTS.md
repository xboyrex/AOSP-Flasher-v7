# AOSP Flasher v7 — Payload / Detection Fix Audit

## Changes in this package

- Corrected Android `update_metadata.proto` parsing:
  - `PartitionUpdate.new_partition_info` is field 3.
  - `PartitionUpdate.operations` is field 4.
  - The previous implementation read fields 7 and 8, so valid payload manifests could be parsed as having no partition operations.
- Corrected Android `InstallOperation.Type` values:
  - `ZERO=6`, `DISCARD=7`, `REPLACE_XZ=8`, `REPLACE_ZSTD=14`.
  - The previous enum values were incorrect and could interpret compressed OTA operations incorrectly.
- Added payload header/manifest bounds and truncation checks.
- Added decompressed output-length validation.
- Added extraction fallback that parses `payload.bin` directly from a ROM ZIP stream, including DEFLATED and STORED ZIP members. `payload-dumper-go` is now optional for the built-in OTA extraction path.
- Added controlled destination paths when extracting standalone `.img` files from ZIP archives.
- Added clear diagnostics to the live log callback.
- Added a guard that stops before flashing if any user-selected partition was not extracted. Uncheck partitions that the selected ROM does not contain.
- Re-enabled `DriverAndEnvManager` and `TurboEngine` log callbacks.
- Added regression tests under `tests/test_payload_extraction.py`.

## Validation performed

- Python `compileall` completed successfully.
- Four regression tests passed:
  1. Payload v2 protobuf field parsing and boot image extraction.
  2. `payload.bin` stored in a ZIP_STORED archive.
  3. `payload.bin` stored in a ZIP_DEFLATED archive.
  4. Direct `.img` extraction from a ROM ZIP, plus Android operation enum values.

## Important device / ROM requirements

- The "No Android device detected on USB" dialog is not a payload parser error. It means Windows/ADB/fastboot currently cannot see a connected phone. Connect the phone with a data-capable cable, install the correct OEM/Google USB driver, and use the required ADB or bootloader mode.
- An incremental OTA may contain source-dependent operations and cannot always be reconstructed without the source partition images. Use a **full OTA** or the manufacturer's fastboot ROM for clean partition extraction.
- Some ROMs do not include every partition (for example, `recovery.img` on devices using A/B recovery). Do not select a partition that the ROM does not provide.
- A successful extraction is not a guarantee that a ROM is compatible with the target device. Verify device codename, firmware base, bootloader state, anti-rollback requirements, and slot strategy before flashing.
- No physical Android device or 4.44 GB production ROM was available in this sandbox. The included tests validate parser structure and ZIP paths with synthetic payload fixtures; hardware flashing remains unverified.

## Run tests

From the project root:

```bat
.build_venv\Scripts\python.exe -m unittest discover -s tests -v
```


## UI / device detection hardening

- Reworked the right-side flash reactor into a vertical layout so the progress ring, full status text, and all four workflow steps fit without truncation.
- Separated the percentage from the full status label; "Waiting Sideload" and "Sideloading" are no longer shortened inside the progress ring.
- Replaced refresh behavior that killed ADB/Fastboot processes with a non-destructive ADB server start and parallel ADB/Fastboot probe.
- Added a non-blocking/coalesced device-probe lock for timer scans, with a bounded wait for explicit manual refresh.
- Preserved distinct ADB, unauthorized, recovery, sideload, fastboot, and fastbootd states.
- Made both Scan / Refresh USB and Device Status Refresh share the same guarded scan implementation.
- Changed RAM actions in the UI to report measured available memory and perform app-local cleanup only; no global standby-list or file-cache purges are triggered by the UI.
- Removed fabricated fallback RAM figures; unavailable telemetry is shown as unavailable.
- Re-enabled Turbo and RAM engine log callbacks. Turbo process priority is capped at above-normal and payload-dumper worker fan-out is capped to avoid starving Windows.
- Updated branding to By xboyrex and the requested secondary label.
- The primary Start Automated Flash / Stop Flashing button flow was not changed.

## Additional validation

- Python compileall: passed.
- Payload extraction regression tests: 4 passed.
- Device-state tests: 3 passed (ADB sideload, unauthorized ADB, Fastboot).
- Total automated tests: 9 passed (payload extraction + ADB sideload + unauthorized ADB + recovery + fastboot + fastbootd).
- Physical USB device, OEM driver combinations, and a complete multi-gigabyte ROM flash were not available for hardware validation.


## Disk-space and extraction lifecycle hardening

- Removed eager partition extraction from the ROM-selection event. Selecting a 4.4 GB ROM ZIP no longer writes several GB of extracted images to disk.
- Extraction now begins only after the user starts the flash workflow.
- Fastboot image files are deleted immediately after the selected fastboot partitions have flashed, before the workflow waits for Recovery ADB Sideload.
- Flash working directories are scoped under `%TEMP%\\AOSPFlasher_v7\\session_<PID>_*` instead of being scattered across generic temp folders.
- The session directory is removed after normal application shutdown. On next launch, sessions whose owning process has exited are removed.
- Pre-extraction cache cleanup is deferred until its worker has finished, avoiding deletion while an extractor is writing.
- Added the legacy `aosp_v7_cache_` prefix to conservative stale-temp cleanup.
- Removed `.pytest_cache`, `__pycache__`, and `.pyc` files from the source archive.
- Added `.gitignore` rules for virtual environments, PyInstaller outputs, Python caches, and local logs.

### Latest automated verification

- Python compileall: passed.
- Unit tests: 12 passed.
- Storage session creation and cleanup tests: 3 passed.
- Payload extraction tests: passed.
- Device detection tests: passed.
- Build script and primary Start Automated Flash button flow remain unchanged.
- No physical multi-gigabyte ROM flash or Windows disk-usage test was performed in this environment.
