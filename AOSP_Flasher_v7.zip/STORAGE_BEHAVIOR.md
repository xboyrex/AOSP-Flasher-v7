# Storage behavior — AOSP Flasher v7

## What changed

- Selecting a ROM ZIP no longer starts background extraction.
- Partition images are extracted only after the user starts the fastboot flashing workflow.
- Extracted images are stored under the app-owned temporary session directory:
  `%TEMP%\\AOSPFlasher_v7\\session_<PID>_*`
- After all selected fastboot partitions have flashed successfully, the extracted image cache is deleted before waiting for Recovery ADB Sideload.
- Flash temporary folders are deleted in the worker `finally` block on both success and failure.
- On normal app exit, the app-owned session folder is removed.
- At next launch, session folders belonging to processes that are no longer running are removed.
- The source archive excludes Python bytecode and pytest cache folders.

## What this does not delete

- The original ROM ZIP selected by the user.
- The generated standalone EXE.
- User files or arbitrary folders in `%TEMP%`.
- Other applications' caches.

## Why disk usage can still rise temporarily

Fastboot images must exist on disk while they are being flashed. The peak temporary size depends on the selected partitions and the ROM's compression ratio. For example, a 4.4 GB ROM ZIP can expand into several GB of image files. This is temporary working storage, not a permanent copy.

If the app is forcibly terminated or Windows crashes during extraction, the app-owned session may remain until the next app launch, where orphaned sessions are cleaned. Do not manually delete the active session while a flash is running.
