@echo off
title AOSP Flasher v7 - Standalone EXE Builder (By Mayank Droid)
chcp 65001 >nul 2>&1
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Requesting Administrator Privileges for building Standalone EXE...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs"
    exit /b 0
)

echo ======================================================================
echo   ⚡ AOSP FLASHER v7 - STANDALONE EXE BUILD ENGINE
echo   Developed by Mayank Droid (@MayankDroid7)
echo ======================================================================
echo.

set "PY_CMD="

python -c "import sys; sys.exit(0 if sys.version_info.major == 3 and sys.version_info.minor >= 8 else 1)" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set "PY_CMD=python"
    goto :builder_python_found
)

py -3 -c "import sys; sys.exit(0 if sys.version_info.major == 3 and sys.version_info.minor >= 8 else 1)" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set "PY_CMD=py -3"
    goto :builder_python_found
)

for %%P in (
    "%LocalAppData%\Programs\Python\Python314\python.exe"
    "%LocalAppData%\Programs\Python\Python313\python.exe"
    "%LocalAppData%\Programs\Python\Python312\python.exe"
    "%LocalAppData%\Programs\Python\Python311\python.exe"
    "%LocalAppData%\Programs\Python\Python310\python.exe"
    "%ProgramFiles%\Python314\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python311\python.exe"
    "%ProgramFiles%\Python310\python.exe"
    "C:\Python314\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
) do (
    if exist "%%~P" (
        set "PY_CMD="%%~P""
        goto :builder_python_found
    )
)

echo [ERROR] Python 3.10+ was not found on your system!
echo Please install Python from https://www.python.org/downloads/
pause
exit /b 1

:builder_python_found
echo [1/4] Checking build dependencies (PyInstaller, CustomTkinter, Pillow, psutil)...
%PY_CMD% -m pip install --upgrade pip --quiet
%PY_CMD% -m pip install pyinstaller customtkinter pillow psutil zstandard --quiet

:: Check if adb folder exists and contains binaries
set "DATA_ADB="
if exist "%~dp0adb\adb.exe" (
    echo [2/4] Found local ADB toolkit in %~dp0adb\ - Merging into Standalone EXE...
    set DATA_ADB=--add-data "adb;adb"
) else (
    echo [2/4] Downloading Official Google Android Platform-Tools into adb\...
    if not exist "%~dp0adb" mkdir "%~dp0adb"
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
        "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile '%~dp0adb\pt.zip'; Expand-Archive -Path '%~dp0adb\pt.zip' -DestinationPath '%~dp0adb' -Force; Copy-Item -Path '%~dp0adb\platform-tools\*' -Destination '%~dp0adb\' -Recurse -Force; Remove-Item '%~dp0adb\pt.zip' -Force" >nul 2>&1
    if exist "%~dp0adb\adb.exe" (
        set DATA_ADB=--add-data "adb;adb"
        echo       Platform-tools downloaded and merged into bundle!
    )
)

echo [3/4] Compiling Standalone Single-File EXE with Custom Launcher Icon & UAC Admin Shield...
%PY_CMD% -m PyInstaller --noconfirm --onefile --windowed --uac-admin ^
    --name "AOSP_Flasher_v7_By_Mayank_Droid" ^
    --icon "assets\icon.ico" ^
    --add-data "assets;assets" ^
    --add-data "core;core" ^
    %DATA_ADB% ^
    --collect-all customtkinter ^
    main.py

if exist "dist\AOSP_Flasher_v7_By_Mayank_Droid.exe" (
    copy /Y "dist\AOSP_Flasher_v7_By_Mayank_Droid.exe" "%~dp0AOSP_Flasher_v7_By_Mayank_Droid.exe" >nul
    echo [4/4] Standalone EXE created successfully:
    echo       %~dp0AOSP_Flasher_v7_By_Mayank_Droid.exe
)

:: Create Windows Desktop Shortcut with custom launcher icon
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ws = New-Object -ComObject WScript.Shell; $desk = [Environment]::GetFolderPath('Desktop'); $s = $ws.CreateShortcut(\"$desk\AOSP Flasher v7.lnk\"); $s.TargetPath = '%~dp0AOSP_Flasher_v7_By_Mayank_Droid.exe'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0assets\icon.ico,0'; $s.Description = 'AOSP Flasher v7 - Developed by Mayank Droid'; $s.Save()" >nul 2>&1

:: Clean up build cache
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "AOSP_Flasher_v7_By_Mayank_Droid.spec" del /f /q "AOSP_Flasher_v7_By_Mayank_Droid.spec"

echo.
echo ======================================================================
echo   ✅ BUILD COMPLETED SUCCESSFULLY!
echo   Executable: AOSP_Flasher_v7_By_Mayank_Droid.exe
echo   Desktop Shortcut: AOSP Flasher v7.lnk
echo ======================================================================
pause
